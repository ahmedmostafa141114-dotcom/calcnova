/* ============ CalcNova — Time & Date calculators ============ */
'use strict';

function dateOut(d){ return d.toLocaleDateString(undefined, { weekday:'long', year:'numeric', month:'long', day:'numeric' }); }
function diffDays(a, b){ return Math.round((b - a) / 86400000); }

defCalc({ slug:'age-calculator', name:'Age Calculator', cat:['time','health'],
  desc:'Calculate your exact age in years, months and days from your date of birth.',
  kw:'age,how old,date of birth,exact age,birthday',
  formula:'Full calendar difference between birth date and today (leap-year aware)',
  expl:'Enter your date of birth. The calculator counts full calendar years, months and days — it correctly handles leap years and different month lengths.',
  example:'Born on 15 March 1990? Your age updates daily and your next birthday countdown shows below.',
  fields:[{k:'dob',label:'Date of birth',t:'date'}],
  compute(i){
    const now = new Date(); const dob = i.dob;
    if (dob > now) throw new Error('Date of birth cannot be in the future.');
    let y = now.getFullYear() - dob.getFullYear();
    let m = now.getMonth() - dob.getMonth();
    let d = now.getDate() - dob.getDate();
    if (d < 0){ m--; d += new Date(now.getFullYear(), now.getMonth(), 0).getDate(); }
    if (m < 0){ y--; m += 12; }
    const daysTotal = Math.floor((now - dob)/86400000);
    const next = new Date(now.getFullYear(), dob.getMonth(), dob.getDate());
    if (next <= now) next.setFullYear(next.getFullYear() + 1);
    return { results:[
      {label:'Your age', value: y + ' years, ' + m + ' months, ' + d + ' days', hl:true},
      {label:'Age in total days', value: daysTotal.toLocaleString()},
      {label:'Age in weeks', value: fmt(daysTotal/7,1)},
      {label:'Next birthday in', value: Math.ceil((next - now)/86400000) + ' days'}
    ]};
  }});

defCalc({ slug:'date-difference', name:'Date Difference Calculator', cat:'time',
  desc:'Find the exact number of days, weeks and months between two dates.',
  kw:'days between dates,date difference,how many days,weeks between',
  formula:'Calendar-aware difference; months counted by full calendar periods',
  expl:'Enter two dates. The result shows total days, approximate weeks, and full calendar months and years between them.',
  example:'From January 1 to July 4 there are 184 days (about 26.3 weeks).',
  fields:[{k:'d1',label:'Start date',t:'date'},{k:'d2',label:'End date',t:'date'}],
  compute(i){
    let a = i.d1, b = i.d2;
    if (a > b){ const t = a; a = b; b = t; }
    const days = diffDays(a, b);
    let months = (b.getFullYear() - a.getFullYear())*12 + (b.getMonth() - a.getMonth());
    if (b.getDate() < a.getDate()) months--;
    return { results:[
      {label:'Total days', value: days.toLocaleString(), hl:true},
      {label:'Weeks', value: fmt(days/7,1)},
      {label:'Full months', value: months.toLocaleString()},
      {label:'Years + months', value: fmt(Math.floor(months/12),0) + ' years, ' + (months%12) + ' months'}
    ]};
  }});

defCalc({ slug:'date-add-subtract', name:'Date Add / Subtract Calculator', cat:'time',
  desc:'Add or subtract days, weeks, months and years from any date.',
  kw:'date calculator,add days to date,subtract dates,what date is',
  formula:'Calendar arithmetic — month/year units respect actual month lengths and leap years',
  expl:'Pick a starting date, choose add or subtract, and enter the amounts. Results respect real calendar lengths.',
  example:'90 days after March 1, 2026 is May 30, 2026.',
  fields:[
    {k:'d',label:'Start date',t:'date'},
    {k:'op',label:'Operation',t:'select',def:'add',opts:[{v:'add',l:'Add'},{v:'sub',l:'Subtract'}]},
    {k:'days',label:'Days',t:'number',min:0,def:0},
    {k:'weeks',label:'Weeks',t:'number',min:0,def:0},
    {k:'months',label:'Months',t:'number',min:0,def:0},
    {k:'years',label:'Years',t:'number',min:0,def:0}
  ],
  compute(i){
    const s = i.op === 'add' ? 1 : -1;
    const r = new Date(i.d.getTime());
    r.setFullYear(r.getFullYear() + s*i.years);
    r.setMonth(r.getMonth() + s*i.months);
    r.setDate(r.getDate() + s*(i.days + i.weeks*7));
    return { results:[
      {label:'Result date', value: dateOut(r), hl:true},
      {label:'Days from start', value: diffDays(i.d, r).toLocaleString()}
    ]};
  }});

function timeToMin(str){
  const m = /^(\d{1,2}):(\d{2})$/.exec(String(str||''));
  if (!m) throw new Error('Enter a time in HH:MM format (24-hour).');
  const h = +m[1], min = +m[2];
  if (h > 23 || min > 59) throw new Error('Time must be between 00:00 and 23:59.');
  return h*60 + min;
}

defCalc({ slug:'time-duration', name:'Time Duration Calculator', cat:'time',
  desc:'Calculate the duration between two times, even across midnight.',
  kw:'time duration,elapsed time,hours between times,time difference',
  formula:'duration = end − start (adds 24 h when the end time is the next day)',
  expl:'Enter a start and end time in 24-hour format. If the end is earlier than the start, the calculator assumes it falls on the following day.',
  example:'From 09:15 to 17:45 is 8 hours 30 minutes.',
  fields:[{k:'t1',label:'Start time (HH:MM)',t:'time',def:'09:00'},{k:'t2',label:'End time (HH:MM)',t:'time',def:'17:30'}],
  compute(i){
    let a = timeToMin(i.t1), b = timeToMin(i.t2);
    if (b < a) b += 1440;
    const mins = b - a;
    return { results:[
      {label:'Duration', value: fmt(Math.floor(mins/60),0) + ' hours ' + fmt(mins%60,0) + ' minutes', hl:true},
      {label:'Total minutes', value: mins.toLocaleString()},
      {label:'Total hours', value: fmt(mins/60,2)}
    ]};
  }});

defCalc({ slug:'hours-calculator', name:'Hours Calculator', cat:'time',
  desc:'Calculate hours worked between a start and end time, minus breaks.',
  kw:'hours worked,work hours,timesheet,hours calculator',
  formula:'hours = (end − start − break) ÷ 60',
  expl:'Enter your start time, end time and any unpaid break in minutes. Overnight shifts (end before start) are supported.',
  example:'09:00–17:30 with a 30-minute break = 8 hours worked.',
  fields:[
    {k:'t1',label:'Start time (HH:MM)',t:'time',def:'09:00'},
    {k:'t2',label:'End time (HH:MM)',t:'time',def:'17:00'},
    {k:'brk',label:'Break (minutes)',t:'number',min:0,def:0}
  ],
  compute(i){
    let a = timeToMin(i.t1), b = timeToMin(i.t2);
    if (b < a) b += 1440;
    let mins = b - a - i.brk;
    if (mins < 0) throw new Error('Break is longer than the time between start and end.');
    return { results:[
      {label:'Hours worked', value: fmt(mins/60,2), hl:true},
      {label:'Hours : minutes', value: fmt(Math.floor(mins/60),0) + ' h ' + fmt(mins%60,0) + ' m'}
    ]};
  }});

function rangeCalc(o){
  return defCalc(Object.assign({
    fields:[{k:'d1',label:'Start date',t:'date'},{k:'d2',label:'End date',t:'date'}]
  }, o, { compute(i){
    if (i.d1 > i.d2) throw new Error('Start date must be on or before the end date.');
    return o.compute(i);
  }}));
}
rangeCalc({ slug:'days-calculator', name:'Days Calculator', cat:'time',
  desc:'Count the number of days between two dates (inclusive or exclusive).',
  kw:'days calculator,day count,days between dates',
  formula:'days = end − start (exclusive); inclusive count adds 1',
  expl:'Enter a date range to get the day count. "Inclusive" counts both the start and end dates — useful for bookings and rentals.',
  example:'January 1 to January 10 = 9 days, or 10 days inclusive.',
  compute(i){
    const ex = diffDays(i.d1, i.d2);
    return { results:[
      {label:'Days (exclusive of end)', value: ex.toLocaleString(), hl:true},
      {label:'Days (inclusive of both dates)', value: (ex + 1).toLocaleString()}
    ]};
  }});
rangeCalc({ slug:'weeks-calculator', name:'Weeks Calculator', cat:'time',
  desc:'Convert the time between two dates into weeks and days.',
  kw:'weeks between dates,weeks calculator,how many weeks',
  formula:'weeks = days ÷ 7',
  expl:'Enter a date range to see the length in full weeks plus remaining days, and in decimal weeks.',
  example:'30 days = 4 weeks and 2 days.',
  compute(i){
    const days = diffDays(i.d1, i.d2);
    return { results:[
      {label:'Weeks and days', value: fmt(Math.floor(days/7),0) + ' weeks, ' + fmt(days%7,0) + ' days', hl:true},
      {label:'Decimal weeks', value: fmt(days/7,2)}
    ]};
  }});
rangeCalc({ slug:'months-calculator', name:'Months Calculator', cat:'time',
  desc:'Count full calendar months between two dates.',
  kw:'months between dates,months calculator,how many months',
  formula:'full calendar months between the two dates',
  expl:'Enter a date range. A month counts only when fully elapsed (e.g., Feb 1 → Mar 1 = 1 month).',
  example:'From January 15 to April 14 = 2 full months; to April 15 = 3.',
  compute(i){
    let months = (i.d2.getFullYear() - i.d1.getFullYear())*12 + (i.d2.getMonth() - i.d1.getMonth());
    if (i.d2.getDate() < i.d1.getDate()) months--;
    return { results:[
      {label:'Full months', value: Math.max(months,0).toLocaleString(), hl:true}
    ]};
  }});
rangeCalc({ slug:'workdays-calculator', name:'Workdays Calculator', cat:'time',
  desc:'Count business days between two dates, excluding weekends.',
  kw:'workdays,business days,working days,weekdays count',
  formula:'counts Mon–Fri only; holidays are not included',
  expl:'Enter a date range. The calculator counts Monday–Friday only. Public holidays are not subtracted because they vary by country and year — adjust manually if needed.',
  example:'A full work week Monday–Friday contains 5 workdays.',
  compute(i){
    let wd = 0;
    const cur = new Date(i.d1.getTime());
    while (cur <= i.d2){
      const d = cur.getDay();
      if (d !== 0 && d !== 6) wd++;
      cur.setDate(cur.getDate() + 1);
    }
    const total = diffDays(i.d1, i.d2) + 1;
    return { results:[
      {label:'Workdays (Mon–Fri)', value: wd.toLocaleString(), hl:true},
      {label:'Weekend days', value: (total - wd).toLocaleString()},
      {label:'Total calendar days', value: total.toLocaleString()}
    ]};
  }});

defCalc({ slug:'countdown-calculator', name:'Countdown Calculator', cat:'time',
  desc:'Count down to any future date in days, hours, minutes and seconds.',
  kw:'countdown,days until,time until event,deadline countdown',
  formula:'difference between now and the target date, updated live',
  expl:'Pick a future date. The countdown shows the remaining time and updates every second while the page is open.',
  example:'Set your next vacation date and watch the days tick down.',
  fields:[{k:'d',label:'Target date',t:'date'}],
  compute(i){
    const now = new Date(), target = new Date(i.d.getFullYear(), i.d.getMonth(), i.d.getDate(), 23, 59, 59);
    if (target <= now) throw new Error('Please choose a date in the future.');
    const ms = target - now;
    const days = Math.floor(ms/86400000), hh = Math.floor(ms/3600000)%24, mm = Math.floor(ms/60000)%60, ss = Math.floor(ms/1000)%60;
    return { results:[
      {label:'Time remaining', value: days + ' days, ' + hh + ' hours, ' + mm + ' minutes, ' + ss + ' seconds', hl:true},
      {label:'Total days', value: days.toLocaleString()}
    ], countdown: target };
  }});

const ZONES = [
  {v:'-12',l:'UTC−12:00'},{v:'-11',l:'UTC−11:00'},{v:'-10',l:'UTC−10:00 (Hawaii)'},{v:'-9',l:'UTC−09:00 (Alaska)'},
  {v:'-8',l:'UTC−08:00 (Pacific)'},{v:'-7',l:'UTC−07:00 (Mountain)'},{v:'-6',l:'UTC−06:00 (Central)'},{v:'-5',l:'UTC−05:00 (Eastern)'},
  {v:'-4',l:'UTC−04:00 (Atlantic)'},{v:'-3',l:'UTC−03:00 (Brasília)'},{v:'0',l:'UTC±00:00 (London)'},{v:'1',l:'UTC+01:00 (Berlin/Paris)'},
  {v:'2',l:'UTC+02:00 (Cairo/Joburg)'},{v:'3',l:'UTC+03:00 (Moscow/Nairobi)'},{v:'4',l:'UTC+04:00 (Dubai)'},{v:'5',l:'UTC+05:00 (Karachi)'},
  {v:'5.5',l:'UTC+05:30 (India)'},{v:'7',l:'UTC+07:00 (Bangkok)'},{v:'8',l:'UTC+08:00 (China/Singapore)'},{v:'9',l:'UTC+09:00 (Tokyo)'},
  {v:'10',l:'UTC+10:00 (Sydney)'},{v:'12',l:'UTC+12:00 (Auckland)'}
];
defCalc({ slug:'time-zone-calculator', name:'Time Zone Calculator', cat:'time',
  desc:'Convert a time from one time zone to another (fixed UTC offsets).',
  kw:'time zone converter,UTC,world clock,time difference',
  formula:'target = source − source offset + target offset',
  expl:'Select the time, source zone and target zone using fixed UTC offsets. Note: daylight saving time is not applied — during summer, zones that observe DST shift by one hour.',
  example:'09:00 in New York (UTC−5) is 14:00 in London (UTC+0).',
  fields:[
    {k:'t',label:'Time (HH:MM)',t:'time',def:'12:00'},
    {k:'from',label:'From zone',t:'select',def:'-5',opts:ZONES},
    {k:'to',label:'To zone',t:'select',def:'0',opts:ZONES}
  ],
  compute(i){
    const mins = timeToMin(i.t);
    const conv = ((mins - parseFloat(i.from)*60) + parseFloat(i.to)*60 + 1440) % 1440;
    const hh = String(Math.floor(conv/60)).padStart(2,'0'), mm = String(conv%60).padStart(2,'0');
    const dayShift = Math.round((mins - parseFloat(i.from)*60 + parseFloat(i.to)*60 - conv)/1440);
    return { results:[
      {label:'Converted time', value: hh + ':' + mm, hl:true},
      {label:'Day shift', value: dayShift === 0 ? 'Same day' : dayShift > 0 ? '+' + dayShift + ' day(s)' : dayShift + ' day(s)'}
    ]};
  }});
