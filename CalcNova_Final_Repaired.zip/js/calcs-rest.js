/* ============ CalcNova — Conversion, Real Estate, Investment, Statistics, Education, Tech ============ */
'use strict';

/* ---------- converters ---------- */
converter({ slug:'length-converter', name:'Length Converter', cat:'conversion',
  desc:'Convert between mm, cm, meters, km, inches, feet, yards and miles.',
  kw:'length converter,feet to meters,inches to cm,km to miles',
  from:'m', to:'ft',
  units:{ mm:{l:'Millimeters',f:0.001}, cm:{l:'Centimeters',f:0.01}, m:{l:'Meters',f:1}, km:{l:'Kilometers',f:1000},
          'in':{l:'Inches',f:0.0254}, ft:{l:'Feet',f:0.3048}, yd:{l:'Yards',f:0.9144}, mi:{l:'Miles',f:1609.344} }});

converter({ slug:'weight-converter', name:'Weight Converter', cat:'conversion',
  desc:'Convert between milligrams, grams, kilograms, metric tonnes, ounces and pounds.',
  kw:'weight converter,kg to lbs,pounds to kg,ounces to grams',
  from:'kg', to:'lb',
  units:{ mg:{l:'Milligrams',f:0.000001}, g:{l:'Grams',f:0.001}, kg:{l:'Kilograms',f:1}, t:{l:'Metric tonnes',f:1000},
          oz:{l:'Ounces',f:0.028349523125}, lb:{l:'Pounds',f:0.45359237} }});

converter({ slug:'temperature-converter', name:'Temperature Converter', cat:'conversion', temp:true,
  desc:'Convert between Celsius, Fahrenheit and Kelvin.',
  kw:'temperature converter,celsius to fahrenheit,fahrenheit to celsius,kelvin',
  from:'c', to:'f',
  formula:'°F = °C × 9/5 + 32 · K = °C + 273.15',
  units:{ c:{l:'Celsius (°C)', toC:x=>x, fromC:x=>x},
          f:{l:'Fahrenheit (°F)', toC:x=>(x-32)*5/9, fromC:x=>x*9/5+32},
          k:{l:'Kelvin (K)', toC:x=>x-273.15, fromC:x=>x+273.15} }});

converter({ slug:'area-converter', name:'Area Converter', cat:'conversion',
  desc:'Convert between square meters, hectares, acres, square feet and more.',
  kw:'area converter,square feet to square meters,acre to hectare',
  from:'m2', to:'ft2',
  units:{ 'm2':{l:'Square meters',f:1}, 'km2':{l:'Square kilometers',f:1e6}, 'cm2':{l:'Square centimeters',f:0.0001},
          'ft2':{l:'Square feet',f:0.09290304}, 'yd2':{l:'Square yards',f:0.83612736}, 'mi2':{l:'Square miles',f:2589988.110336},
          ha:{l:'Hectares',f:10000}, ac:{l:'Acres',f:4046.8564224} }});

converter({ slug:'volume-converter', name:'Volume Converter', cat:'conversion',
  desc:'Convert between liters, milliliters, cubic meters, gallons, cups and more.',
  kw:'volume converter,liters to gallons,ml to oz,cups to liters',
  from:'l', to:'gal',
  units:{ ml:{l:'Milliliters',f:0.001}, l:{l:'Liters',f:1}, 'm3':{l:'Cubic meters',f:1000},
          'floz':{l:'Fluid ounces (US)',f:0.0295735295625}, cup:{l:'Cups (US)',f:0.2365882365},
          pt:{l:'Pints (US)',f:0.473176473}, qt:{l:'Quarts (US)',f:0.946352946}, gal:{l:'Gallons (US)',f:3.785411784} }});

converter({ slug:'speed-converter', name:'Speed Converter', cat:'conversion',
  desc:'Convert between km/h, mph, m/s, feet per second and knots.',
  kw:'speed converter,kmh to mph,mph to kmh,meters per second,knots',
  from:'kmh', to:'mph',
  units:{ 'ms':{l:'Meters per second',f:1}, 'kmh':{l:'Kilometers per hour',f:1/3.6}, 'mph':{l:'Miles per hour',f:0.44704},
          'fts':{l:'Feet per second',f:0.3048}, kn:{l:'Knots',f:0.514444} }});

converter({ slug:'data-storage-converter', name:'Data Storage Converter', cat:['conversion','technology'],
  desc:'Convert between bytes, KB, MB, GB, TB and PB (decimal units).',
  kw:'data converter,GB to MB,bytes to megabytes,terabyte',
  from:'gb', to:'mb',
  expl:'Uses decimal (SI) units where 1 KB = 1,000 bytes. Operating systems often display binary (KiB) units — a 500 GB drive shows as about 465 GiB.',
  example:'1 GB = 1,000 MB = 8,000,000,000 bits.',
  units:{ b:{l:'Bytes',f:1}, kb:{l:'Kilobytes (KB)',f:1e3}, mb:{l:'Megabytes (MB)',f:1e6}, gb:{l:'Gigabytes (GB)',f:1e9},
          tb:{l:'Terabytes (TB)',f:1e12}, pb:{l:'Petabytes (PB)',f:1e15} }});

/* ---------- technology ---------- */
defCalc({ slug:'download-time-calculator', name:'Download Time Calculator', cat:'technology',
  desc:'Estimate how long a download will take at your connection speed.',
  kw:'download time,how long to download,internet speed,download calculator',
  formula:'time = file size ÷ (speed ÷ 8) — bits vs bytes accounted for',
  expl:'Enter the file size and your connection speed. Speeds are quoted in bits per second (Mbps), file sizes in bytes — the calculator handles the 8× difference.',
  example:'A 5 GB file on a 100 Mbps connection takes about 6 minutes 40 seconds.',
  fields:[
    {k:'size',label:'File size',t:'number',min:0,nonzero:true,def:5},
    {k:'sunit',label:'Size unit',t:'select',def:'gb',opts:[{v:'mb',l:'MB'},{v:'gb',l:'GB'},{v:'tb',l:'TB'}]},
    {k:'speed',label:'Download speed',t:'number',min:0,nonzero:true,def:100},
    {k:'spunit',label:'Speed unit',t:'select',def:'mbps',opts:[{v:'kbps',l:'Kbps'},{v:'mbps',l:'Mbps'},{v:'gbps',l:'Gbps'}]}
  ],
  compute(i){
    const sizes = { mb: 8e6, gb: 8e9, tb: 8e12 };
    const speeds = { kbps: 1e3, mbps: 1e6, gbps: 1e9 };
    const seconds = i.size*sizes[i.sunit]/i.speed/speeds[i.spunit];
    if (!isFinite(seconds)) throw new Error('Result is too large.');
    if (seconds < 1) return { results:[{label:'Download time', value: fmt(seconds*1000,0) + ' ms', hl:true}] };
    const h = Math.floor(seconds/3600), m = Math.floor(seconds%3600/60), s = Math.round(seconds%60);
    return { results:[
      {label:'Download time', value: (h ? h + ' h ' : '') + m + ' min ' + s + ' s', hl:true},
      {label:'In seconds', value: fmt(seconds,1)}
    ]};
  }});

defCalc({ slug:'upload-time-calculator', name:'Upload Time Calculator', cat:'technology',
  desc:'Estimate how long an upload will take at your upload speed.',
  kw:'upload time,how long to upload,upload speed,sending files',
  formula:'time = file size ÷ (upload speed ÷ 8)',
  expl:'Upload speeds are usually much lower than download speeds — check your plan. Protocol overhead makes real times ~5–10% longer.',
  example:'A 2 GB video at 10 Mbps upload takes about 27 minutes.',
  fields:[
    {k:'size',label:'File size',t:'number',min:0,nonzero:true,def:2},
    {k:'sunit',label:'Size unit',t:'select',def:'gb',opts:[{v:'mb',l:'MB'},{v:'gb',l:'GB'},{v:'tb',l:'TB'}]},
    {k:'speed',label:'Upload speed',t:'number',min:0,nonzero:true,def:10},
    {k:'spunit',label:'Speed unit',t:'select',def:'mbps',opts:[{v:'kbps',l:'Kbps'},{v:'mbps',l:'Mbps'},{v:'gbps',l:'Gbps'}]}
  ],
  compute(i){
    const sizes = { mb: 8e6, gb: 8e9, tb: 8e12 };
    const speeds = { kbps: 1e3, mbps: 1e6, gbps: 1e9 };
    const seconds = i.size*sizes[i.sunit]/i.speed/speeds[i.spunit];
    const h = Math.floor(seconds/3600), m = Math.floor(seconds%3600/60), s = Math.round(seconds%60);
    return { results:[
      {label:'Upload time', value: (h ? h + ' h ' : '') + m + ' min ' + s + ' s', hl:true},
      {label:'In seconds', value: fmt(seconds,1)}
    ]};
  }});

defCalc({ slug:'internet-speed-calculator', name:'Internet Speed Calculator', cat:'technology',
  desc:'Work out your real transfer speed from file size and elapsed time.',
  kw:'internet speed test,bandwidth calculator,transfer rate',
  formula:'speed = file size (bits) ÷ time (seconds)',
  expl:'Enter the file size you transferred and how long it took to get your effective speed in Mbps.',
  example:'A 1 GB file in 80 seconds ≈ 100 Mbps effective throughput.',
  fields:[
    {k:'size',label:'File size',t:'number',min:0,nonzero:true,def:1},
    {k:'sunit',label:'Size unit',t:'select',def:'gb',opts:[{v:'mb',l:'MB'},{v:'gb',l:'GB'}]},
    {k:'sec',label:'Time taken (seconds)',t:'number',min:0,nonzero:true,def:80}
  ],
  compute(i){
    const bits = i.size*(i.sunit === 'gb' ? 8e9 : 8e6);
    const mbps = bits/i.sec/1e6;
    return { results:[
      {label:'Effective speed', value: fmt(mbps,1) + ' Mbps', hl:true},
      {label:'In megabytes per second', value: fmt(mbps/8,2) + ' MB/s'}
    ]};
  }});

defCalc({ slug:'binary-decimal-converter', name:'Binary / Decimal Converter', cat:'technology',
  desc:'Convert integers between decimal, binary, octal and hexadecimal.',
  kw:'binary to decimal,decimal to binary,hex converter,octal',
  formula:'repeated division by 2 (or place values of powers of 2)',
  expl:'Enter a non-negative whole number. Outputs show the same value in binary, octal and hexadecimal.',
  example:'Decimal 255 = binary 11111111 = hex FF.',
  fields:[{k:'n',label:'Decimal number',t:'number',min:0,def:255}],
  compute(i){
    let n = Math.round(i.n);
    if (n > 1e15) throw new Error('Number too large.');
    return { results:[
      {label:'Binary', value: n.toString(2), hl:true},
      {label:'Octal', value: n.toString(8)},
      {label:'Hexadecimal', value: n.toString(16).toUpperCase()}
    ]};
  }});

defCalc({ slug:'aspect-ratio-calculator', name:'Screen Aspect Ratio Calculator', cat:'technology',
  desc:'Find the simplified aspect ratio of any screen resolution.',
  kw:'aspect ratio,screen resolution,16:9,4:3,video resolution',
  formula:'divide width and height by their greatest common divisor',
  expl:'Enter the width and height in pixels to get the simplified ratio and the number of megapixels.',
  example:'1920 × 1080 simplifies to 16:9.',
  fields:[
    {k:'w',label:'Width (px)',t:'number',min:0,nonzero:true,def:1920},
    {k:'h',label:'Height (px)',t:'number',min:0,nonzero:true,def:1080}
  ],
  compute(i){
    const g = gcd2(i.w, i.h);
    return { results:[
      {label:'Aspect ratio', value: (i.w/g) + ' : ' + (i.h/g), hl:true},
      {label:'Megapixels', value: fmt(i.w*i.h/1e6,2) + ' MP'},
      {label:'Diagonal (px)', value: fmt(Math.sqrt(i.w*i.w + i.h*i.h),0)}
    ]};
  }});

/* ---------- real estate ---------- */
defCalc({ slug:'rent-vs-buy', name:'Rent vs Buy Calculator', cat:['real-estate','finance'],
  desc:'Compare the 5-year cost of renting versus buying a home.',
  kw:'rent vs buy,rent or buy,should I buy a house,buying vs renting',
  formula:'renting cost = monthly rent × 60 · buying cost = mortgage payments + down payment + costs − equity built',
  note: 'Simplified comparison: assumes fixed rates, ignores maintenance, transaction costs on sale, and home price changes affect equity only through principal paydown. Not financial advice.',
  expl:'Enter your rent, the home price, mortgage terms and annual costs. The calculator totals each option over five years; buying gets credit for the principal you pay down (your equity).',
  example:'Renting at $1,800/month vs buying a $350,000 home at 6.5% — renting often wins short-term, buying wins long-term.',
  fields:[
    {k:'rent',label:'Monthly rent ($)',t:'number',min:0,nonzero:true},
    {k:'price',label:'Home price ($)',t:'number',min:0,nonzero:true},
    {k:'down',label:'Down payment (%)',t:'number',min:0,max:100,def:20},
    {k:'rate',label:'Mortgage rate (%)',t:'number',min:0,def:6.5},
    {k:'years',label:'Mortgage term (years)',t:'number',min:0,nonzero:true,def:30},
    {k:'tax',label:'Annual property tax ($)',t:'number',min:0,def:4200},
    {k:'ins',label:'Annual insurance ($)',t:'number',min:0,def:1600}
  ],
  compute(i){
    const months = 60;
    const principal = i.price*(1 - i.down/100);
    const r = i.rate/100/12, n = monthsFromYears(i.years);
    const m = pmt(principal, r, n);
    const balAfter = r === 0 ? principal - m*months : principal*Math.pow(1+r,months) - m*(Math.pow(1+r,months)-1)/r;
    const equity = principal - balAfter;
    const rentCost = i.rent*months;
    const buyCost = i.price*i.down/100 + m*months + (i.tax + i.ins)*5 - equity;
    return { results:[
      {label:'5-year renting cost', value: fmtMoney(rentCost), hl:true},
      {label:'5-year buying cost', value: fmtMoney(buyCost), hl:true},
      {label:'Cheaper option', value: rentCost < buyCost ? 'Renting (by ' + fmtMoney(buyCost - rentCost) + ')' : 'Buying (by ' + fmtMoney(rentCost - buyCost) + ')'},
      {label:'Equity built in 5 years', value: fmtMoney(equity)}
    ]};
  }});

defCalc({ slug:'home-affordability', name:'Home Affordability Calculator', cat:'real-estate',
  desc:'Estimate how much house you can afford using the 28/36 rule.',
  kw:'how much house can I afford,affordable home price,mortgage qualification',
  formula:'28% rule: housing ≤ 28% of gross income; 36% rule: total debt ≤ 36%',
  note: 'Lender criteria vary. This is an estimate, not a loan qualification.',
  expl:'Enter your gross income and monthly debts. The calculator applies the classic 28/36 guideline: monthly housing costs under 28% of income and all debts under 36%, then converts the lower figure into a loan amount at your rate.',
  example:'$90,000 income with $400/month debts at 6.5% → roughly a $300,000 home with 20% down.',
  fields:[
    {k:'inc',label:'Annual gross income ($)',t:'number',min:0,nonzero:true},
    {k:'debts',label:'Monthly debt payments ($)',t:'number',min:0,def:0},
    {k:'rate',label:'Mortgage rate (%)',t:'number',min:0,def:6.5},
    {k:'years',label:'Loan term (years)',t:'number',min:0,nonzero:true,def:30},
    {k:'down',label:'Down payment ($)',t:'number',min:0,def:60000}
  ],
  compute(i){
    const incM = i.inc/12;
    const h28 = incM*0.28;
    const d36 = incM*0.36 - i.debts;
    const budget = Math.max(Math.min(h28, d36), 0);
    const r = i.rate/100/12, n = monthsFromYears(i.years);
    const loan = r === 0 ? budget*n : budget*(1 - Math.pow(1+r,-n))/r;
    return { results:[
      {label:'Max monthly housing budget', value: fmtMoney(budget), hl:true},
      {label:'Max loan amount', value: fmtMoney(loan)},
      {label:'Estimated affordable home price', value: fmtMoney(loan + i.down), hl:true}
    ]};
  }});

defCalc({ slug:'property-tax-calculator', name:'Property Tax Calculator', cat:'real-estate',
  desc:'Calculate annual and monthly property tax from home value and tax rate.',
  kw:'property tax,real estate tax,mill rate,home tax',
  formula:'tax = assessed value × tax rate',
  expl:'Enter your home\'s assessed value and the local tax rate (find it on your county assessor\'s website).',
  example:'A $400,000 home at 1.1% pays $4,400/year.',
  fields:[
    {k:'val',label:'Assessed value ($)',t:'number',min:0},
    {k:'rate',label:'Property tax rate (%)',t:'number',min:0}
  ],
  compute(i){
    const t = i.val*i.rate/100;
    return { results:[
      {label:'Annual property tax', value: fmtMoney(t), hl:true},
      {label:'Monthly', value: fmtMoney(t/12)}
    ]};
  }});

defCalc({ slug:'rental-yield-calculator', name:'Rental Yield Calculator', cat:'real-estate',
  desc:'Calculate gross and net rental yield on a property.',
  kw:'rental yield,cap rate,investment property,rental return',
  formula:'gross yield = annual rent ÷ property price · net yield = (rent − annual costs) ÷ price',
  note: 'Real estate estimates only — actual returns depend on vacancies, repairs and market conditions.',
  expl:'Enter the property price, monthly rent and annual costs (maintenance, tax, insurance). Gross yield ignores costs; net yield subtracts them.',
  example:'A $250,000 property renting for $1,500/month with $4,000 costs: gross 7.2%, net 5.6%.',
  fields:[
    {k:'price',label:'Property price ($)',t:'number',min:0,nonzero:true},
    {k:'rent',label:'Monthly rent ($)',t:'number',min:0},
    {k:'costs',label:'Annual costs ($)',t:'number',min:0,def:0}
  ],
  compute(i){
    const annual = i.rent*12;
    return { results:[
      {label:'Gross rental yield', value: fmt(annual/i.price*100) + '%', hl:true},
      {label:'Net rental yield', value: fmt((annual - i.costs)/i.price*100) + '%', hl:true},
      {label:'Annual cash flow before mortgage', value: fmtMoney(annual - i.costs)}
    ]};
  }});

defCalc({ slug:'down-payment-calculator', name:'Down Payment Calculator', cat:'real-estate',
  desc:'Calculate the down payment and loan amount for a home purchase.',
  kw:'down payment,house down payment,20 percent down,loan amount',
  formula:'down = price × percentage · loan = price − down',
  expl:'Enter the home price and down payment percentage. A 20% down payment typically avoids private mortgage insurance (PMI).',
  example:'A $300,000 home with 20% down: $60,000 down, $240,000 loan.',
  fields:[
    {k:'price',label:'Home price ($)',t:'number',min:0,nonzero:true},
    {k:'pct',label:'Down payment (%)',t:'number',min:0,max:100,def:20}
  ],
  compute(i){
    const d = i.price*i.pct/100;
    return { results:[
      {label:'Down payment', value: fmtMoney(d), hl:true},
      {label:'Loan amount', value: fmtMoney(i.price - d), hl:true},
      {label:'PMI needed?', value: i.pct < 20 ? 'Usually yes (below 20%)' : 'Usually no'}
    ]};
  }});

defCalc({ slug:'closing-cost-calculator', name:'Closing Cost Calculator', cat:'real-estate',
  desc:'Estimate closing costs when buying a home.',
  kw:'closing costs,buying a house costs,escrow fees,title insurance',
  formula:'closing costs ≈ price × rate%, typically 2–5% of purchase price',
  note: 'Estimate only — actual costs vary by location, lender and negotiation.',
  expl:'Enter the home price and an estimated closing cost percentage (2–5% is typical in the US), split into loan-related and title/escrow portions for reference.',
  example:'A $350,000 home at 3% closing costs ≈ $10,500.',
  fields:[
    {k:'price',label:'Home price ($)',t:'number',min:0,nonzero:true},
    {k:'pct',label:'Closing cost estimate (%)',t:'number',min:0,max:10,def:3}
  ],
  compute(i){
    const c = i.price*i.pct/100;
    return { results:[
      {label:'Estimated closing costs', value: fmtMoney(c), hl:true},
      {label:'Loan-related portion (~60%)', value: fmtMoney(c*0.6)},
      {label:'Title, escrow & other (~40%)', value: fmtMoney(c*0.4)},
      {label:'Total cash needed with 20% down', value: fmtMoney(i.price*0.2 + c)}
    ]};
  }});

defCalc({ slug:'loan-to-value', name:'Loan-to-Value Calculator', cat:'real-estate',
  desc:'Calculate the loan-to-value (LTV) ratio of a mortgage.',
  kw:'LTV,loan to value,mortgage ratio,equity',
  formula:'LTV = loan amount ÷ property value × 100',
  expl:'Enter the loan amount and property value. LTV below 80% typically avoids PMI and gets better rates.',
  example:'A $240,000 loan on a $300,000 home = 80% LTV.',
  fields:[
    {k:'loan',label:'Loan amount ($)',t:'number',min:0},
    {k:'val',label:'Property value ($)',t:'number',min:0,nonzero:true}
  ],
  compute(i){
    const ltv = i.loan/i.val*100;
    return { results:[
      {label:'LTV ratio', value: fmt(ltv) + '%', hl:true},
      {label:'Equity', value: fmt(100 - ltv) + '%'},
      {label:'PMI typically required?', value: ltv > 80 ? 'Yes' : 'No'}
    ]};
  }});

/* ---------- investment extras ---------- */
defCalc({ slug:'periodic-investment', name:'Periodic Investment Calculator', cat:'investment',
  desc:'Project the growth of a fixed monthly investment.',
  kw:'dollar cost averaging,monthly investing,systematic investment,SIP',
  formula:'FV = PMT × (((1+r)^n − 1) ÷ r), r = annual return ÷ 12',
  note: F_DISCLAIMER,
  expl:'Enter the amount you invest each month, the expected annual return and the duration. Compounding monthly.',
  example:'$250/month at 8% for 15 years grows to about $86,600.',
  fields:[
    {k:'pmt',label:'Monthly investment ($)',t:'number',min:0,nonzero:true},
    {k:'r',label:'Annual return (%) — nominal, compounded monthly',t:'number',def:8},
    {k:'t',label:'Years',t:'number',min:0,nonzero:true}
  ],
  compute(i){
    const rm = i.r/100/12, n = Math.round(i.t*12);
    const fv = rm === 0 ? i.pmt*n : i.pmt*(Math.pow(1+rm,n)-1)/rm;
    return { results:[
      {label:'Final value', value: fmtMoney(fv), hl:true},
      {label:'Total invested', value: fmtMoney(i.pmt*n)},
      {label:'Growth', value: fmtMoney(fv - i.pmt*n)}
    ]};
  }});

defCalc({ slug:'investment-return', name:'Investment Return Calculator', cat:'investment',
  desc:'Calculate total and annualized returns on any investment.',
  kw:'investment return,rate of return,annualized gain',
  formula:'total return = (end − begin − contributions) ÷ begin · annualized = CAGR',
  note: F_DISCLAIMER,
  expl:'Enter what you put in, what you have now, any extra contributions along the way and the holding period.',
  example:'$5,000 growing to $8,000 in 4 years = 60% total, ~12.5% annualized.',
  fields:[
    {k:'begin',label:'Initial investment ($)',t:'number',min:0},
    {k:'add',label:'Total additional contributions ($)',t:'number',min:0,def:0},
    {k:'end',label:'Current value ($)',t:'number',min:0},
    {k:'years',label:'Holding period (years)',t:'number',min:0,nonzero:true}
  ],
  compute(i){
    const invested = i.begin + i.add;
    if (invested <= 0) throw new Error('Please enter an initial investment or contributions.');
    const gain = i.end - invested;
    const roi = gain/invested*100;
    const cagr = i.end > 0 && i.begin > 0 ? (Math.pow(i.end/i.begin, 1/i.years) - 1)*100 : null;
    const out = [
      {label:'Total gain / loss', value: fmtMoney(gain), hl:true},
      {label:'Total return (ROI)', value: fmt(roi) + '%', hl:true}
    ];
    if (cagr !== null) out.push({label:'Annualized (CAGR)', value: fmt(cagr) + '%'});
    return { results: out };
  }});

defCalc({ slug:'savings-growth', name:'Savings Growth Calculator', cat:['investment','finance'],
  desc:'Watch a lump sum grow with compound interest over time.',
  kw:'savings growth,compound growth,lump sum investment',
  formula:'FV = P(1 + r/n)^(nt)',
  note: F_DISCLAIMER,
  expl:'Enter a starting lump sum, interest rate, compounding frequency and time. No contributions — for monthly deposits use the Savings Calculator.',
  example:'$10,000 at 4.5% compounded monthly for 10 years → about $15,640.',
  fields:[
    {k:'p',label:'Starting amount ($)',t:'number',min:0},
    {k:'r',label:'Annual rate (%)',t:'number',min:0,def:4.5},
    {k:'n',label:'Compounds per year',t:'select',def:'12',opts:[{v:'1',l:'Annually'},{v:'4',l:'Quarterly'},{v:'12',l:'Monthly'},{v:'365',l:'Daily'}]},
    {k:'t',label:'Years',t:'number',min:0,nonzero:true}
  ],
  compute(i){
    const n = parseInt(i.n,10);
    const fv = i.p*Math.pow(1 + i.r/100/n, n*i.t);
    return { results:[
      {label:'Final balance', value: fmtMoney(fv), hl:true},
      {label:'Interest earned', value: fmtMoney(fv - i.p)}
    ]};
  }});

/* ---------- statistics ---------- */
defCalc({ slug:'standard-deviation', name:'Standard Deviation Calculator', cat:'statistics',
  desc:'Calculate population and sample standard deviation of a dataset.',
  kw:'standard deviation,sigma,spread,dispersion',
  formula:'σ = √(Σ(x − μ)² ÷ N) · s = √(Σ(x − μ)² ÷ (N−1))',
  expl:'Enter your data. Population standard deviation (σ) divides by N; sample standard deviation (s) divides by N−1 and is the right choice for samples of a larger group.',
  example:'For 2, 4, 4, 4, 5, 5, 7, 9: σ = 2, s ≈ 2.14.',
  fields:[{k:'list',label:'Numbers (comma or space separated)',t:'list'}],
  compute(i){
    const a = i.list, n = a.length;
    if (n < 2) throw new Error('Standard deviation requires at least 2 numbers.');
    const mean = a.reduce((x,y)=>x+y,0)/n;
    const ss = a.reduce((x,y)=>x + (y-mean)*(y-mean), 0);
    return { results:[
      {label:'Population σ', value: fmt(Math.sqrt(ss/n)), hl:true},
      {label:'Sample s', value: fmt(Math.sqrt(ss/(n-1))), hl:true},
      {label:'Mean', value: fmt(mean)},
      {label:'Variance (population)', value: fmt(ss/n)}
    ]};
  }});

defCalc({ slug:'variance-calculator', name:'Variance Calculator', cat:'statistics',
  desc:'Calculate population and sample variance of a dataset.',
  kw:'variance,σ²,sample variance,statistical variance',
  formula:'σ² = Σ(x − μ)² ÷ N · s² = Σ(x − μ)² ÷ (N−1)',
  expl:'Variance is the average squared distance from the mean — standard deviation squared.',
  example:'For 2, 4, 4, 4, 5, 5, 7, 9: σ² = 4, s² ≈ 4.57.',
  fields:[{k:'list',label:'Numbers (comma or space separated)',t:'list'}],
  compute(i){
    const a = i.list, n = a.length;
    if (n < 2) throw new Error('Variance requires at least 2 numbers.');
    const mean = a.reduce((x,y)=>x+y,0)/n;
    const ss = a.reduce((x,y)=>x + (y-mean)*(y-mean), 0);
    return { results:[
      {label:'Population variance σ²', value: fmt(ss/n), hl:true},
      {label:'Sample variance s²', value: fmt(ss/(n-1)), hl:true}
    ]};
  }});

defCalc({ slug:'probability-calculator', name:'Probability Calculator', cat:'statistics',
  desc:'Calculate probability and odds of a single event.',
  kw:'probability,odds,chance,likelihood',
  formula:'P = favorable outcomes ÷ total outcomes · odds = favorable : unfavorable',
  expl:'Enter the number of favorable outcomes and the total number of equally likely outcomes.',
  example:'Rolling a 3 on a die: 1 favorable out of 6 → P = 16.67%.',
  fields:[
    {k:'fav',label:'Favorable outcomes',t:'number',min:0},
    {k:'tot',label:'Total outcomes',t:'number',min:0,nonzero:true}
  ],
  compute(i){
    if (i.fav > i.tot) throw new Error('Favorable outcomes cannot exceed total outcomes.');
    const p = i.fav/i.tot;
    const g = gcd2(i.fav, i.tot - i.fav);
    return { results:[
      {label:'Probability', value: fmt(p*100) + '% (' + fmt(p,6) + ')', hl:true},
      {label:'Odds in favor', value: (i.fav/g) + ' : ' + ((i.tot-i.fav)/g)},
      {label:'Odds against', value: ((i.tot-i.fav)/g) + ' : ' + (i.fav/g)}
    ]};
  }});

defCalc({ slug:'permutation-calculator', name:'Permutation Calculator', cat:'statistics',
  desc:'Calculate the number of ordered arrangements (nPr).',
  kw:'permutation,nPr,arrangements,ordering',
  formula:'nPr = n! ÷ (n − r)!',
  expl:'Permutations count ways to arrange r items out of n when order matters.',
  example:'Arranging 3 of 5 books on a shelf: ₅P₃ = 60 ways.',
  fields:[{k:'n',label:'n (total items)',t:'number',min:0},{k:'r',label:'r (items chosen)',t:'number',min:0}],
  compute(i){
    let n = Math.round(i.n), r = Math.round(i.r);
    if (r > n) throw new Error('r cannot exceed n.');
    if (n > 170) throw new Error('n is too large (max 170).');
    let res = 1; for (let k = 0; k < r; k++) res *= (n - k);
    return { results:[{label:'nPr', value: res.toLocaleString(), hl:true}] };
  }});

defCalc({ slug:'combination-calculator', name:'Combination Calculator', cat:'statistics',
  desc:'Calculate the number of unordered selections (nCr).',
  kw:'combination,nCr,choose,selections',
  formula:'nCr = n! ÷ (r! × (n − r)!)',
  expl:'Combinations count ways to choose r items out of n when order does not matter.',
  example:'Choosing 2 of 4 toppings: ₄C₂ = 6 possibilities.',
  fields:[{k:'n',label:'n (total items)',t:'number',min:0},{k:'r',label:'r (items chosen)',t:'number',min:0}],
  compute(i){
    let n = Math.round(i.n), r = Math.round(i.r);
    if (r > n) throw new Error('r cannot exceed n.');
    if (n > 170) throw new Error('n is too large (max 170).');
    r = Math.min(r, n - r);
    let res = 1; for (let k = 1; k <= r; k++) res = res*(n - r + k)/k;
    return { results:[{label:'nCr', value: fmt(Math.round(res),0), hl:true}] };
  }});

defCalc({ slug:'z-score-calculator', name:'Z-Score Calculator', cat:'statistics',
  desc:'Calculate the z-score of a value and its percentile.',
  kw:'z-score,standard score,percentile,normal distribution',
  formula:'z = (x − μ) ÷ σ',
  expl:'The z-score measures how many standard deviations a value sits from the mean. A percentile (via the normal CDF) tells you what share of data falls below it.',
  example:'A score of 85 with μ = 70, σ = 10 → z = 1.5 → ~93rd percentile.',
  fields:[
    {k:'x',label:'Value (x)',t:'number'},
    {k:'mu',label:'Mean (μ)',t:'number'},
    {k:'sd',label:'Standard deviation (σ)',t:'number',min:0,nonzero:true}
  ],
  compute(i){
    const z = (i.x - i.mu)/i.sd;
    const pct = 0.5*(1 + erf(z/Math.SQRT2))*100;
    return { results:[
      {label:'Z-score', value: fmt(z), hl:true},
      {label:'Percentile', value: fmt(pct,1) + '%', hl:true}
    ]};
  }});

defCalc({ slug:'percentage-change', name:'Percentage Change Calculator', cat:['statistics','math'],
  desc:'Calculate percent increase or decrease between any two values.',
  kw:'percent change,growth rate,decline percentage,difference percent',
  formula:'change = (new − old) ÷ |old| × 100',
  expl:'Enter the before and after values. Positive results indicate growth; negative results indicate decline.',
  example:'Sales rising from $8,000 to $10,000 = +25%.',
  fields:[{k:'old',label:'Original value',t:'number',nonzero:true},{k:'new',label:'New value',t:'number'}],
  compute(i){
    const c = (i.new - i.old)/Math.abs(i.old)*100;
    return { results:[
      {label:'Percentage change', value: fmt(c) + '%', hl:true},
      {label:'Direction', value: c > 0 ? 'Increase' : c < 0 ? 'Decrease' : 'No change'},
      {label:'Absolute difference', value: fmt(i.new - i.old)}
    ]};
  }});

/* ---------- education ---------- */
defCalc({ slug:'gpa-calculator', name:'GPA Calculator', cat:'education',
  desc:'Calculate weighted GPA from course grades and credits.',
  kw:'GPA,grade point average,college GPA,semester GPA',
  formula:'GPA = Σ(grade points × credits) ÷ Σ credits',
  expl:'Enter each course\'s grade points (e.g., A = 4.0, A− = 3.7, B+ = 3.3) and its credit hours, separated by commas. Lists must be the same length.',
  example:'Grades 4.0, 3.3, 3.7 with credits 3, 4, 3 → GPA = 3.64.',
  fields:[
    {k:'grades',label:'Grade points (comma separated)',t:'list',placeholder:'e.g. 4.0, 3.3, 3.7'},
    {k:'credits',label:'Credits (comma separated)',t:'list',placeholder:'e.g. 3, 4, 3'}
  ],
  compute(i){
    if (i.grades.length !== i.credits.length) throw new Error('Enter the same number of grades and credits.');
    const pts = i.grades.reduce((a,g,ix)=>a + g*i.credits[ix], 0);
    const cr = i.credits.reduce((a,b)=>a+b,0);
    if (cr <= 0) throw new Error('Total credits must be positive.');
    return { results:[
      {label:'Your GPA', value: fmt(pts/cr,2), hl:true},
      {label:'Total credits', value: fmt(cr,0)}
    ]};
  }});

defCalc({ slug:'grade-calculator', name:'Grade Calculator', cat:'education',
  desc:'Convert points earned into a percentage and letter grade.',
  kw:'grade calculator,letter grade,percentage grade,test grade',
  formula:'grade = points earned ÷ points possible × 100',
  expl:'Enter the points you earned and the total possible. Letter bands follow the common US scale: A ≥ 90%, B ≥ 80%, C ≥ 70%, D ≥ 60%.',
  example:'87 of 100 points = 87% = B+.',
  fields:[
    {k:'earned',label:'Points earned',t:'number',min:0},
    {k:'possible',label:'Points possible',t:'number',min:0,nonzero:true}
  ],
  compute(i){
    if (i.earned > i.possible) throw new Error('Earned points cannot exceed possible points.');
    const pct = i.earned/i.possible*100;
    const L = pct >= 90 ? 'A' : pct >= 80 ? 'B' : pct >= 70 ? 'C' : pct >= 60 ? 'D' : 'F';
    return { results:[
      {label:'Percentage', value: fmt(pct,1) + '%', hl:true},
      {label:'Letter grade', value: L, hl:true}
    ]};
  }});

defCalc({ slug:'final-grade-calculator', name:'Final Grade Calculator', cat:'education',
  desc:'Find the exam score you need to reach your target course grade.',
  kw:'final grade,what do I need on the final,exam needed,grade needed',
  formula:'needed = (target − current × (1 − w)) ÷ w, where w = final weight',
  expl:'Enter your current grade, its share of the course (the rest is the final), your target and the final\'s weight.',
  example:'Current 88% worth 60%, final worth 40%, target 90% → you need 93% on the final.',
  fields:[
    {k:'cur',label:'Current grade (%)',t:'number',min:0,max:120},
    {k:'curw',label:'Current portion weight (%)',t:'number',min:0,max:100,def:60},
    {k:'target',label:'Target grade (%)',t:'number',min:0,max:120,def:90},
    {k:'finw',label:'Final exam weight (%)',t:'number',min:0,max:100,def:40}
  ],
  compute(i){
    if (Math.abs(i.curw + i.finw - 100) > 0.01) throw new Error('Weights must add up to 100%.');
    if (i.finw === 0) throw new Error('Final weight cannot be 0.');
    const need = (i.target - i.cur*(i.curw/100))/(i.finw/100);
    return { results:[
      {label:'Score needed on the final', value: fmt(need,1) + '%', hl:true},
      {label:'Feasibility', value: need > 100 ? 'Above 100% — target may be out of reach' : need < 0 ? 'You can even lose points' : 'Achievable'}
    ]};
  }});

defCalc({ slug:'exam-score-calculator', name:'Exam Score Calculator', cat:'education',
  desc:'Turn correct answers into an exam percentage and letter grade.',
  kw:'exam score,test score,how many correct,exam percentage',
  formula:'score = correct ÷ total × 100',
  expl:'Enter how many questions you answered correctly and the total number of questions.',
  example:'44 of 50 correct = 88% = B+.',
  fields:[
    {k:'corr',label:'Correct answers',t:'number',min:0},
    {k:'tot',label:'Total questions',t:'number',min:0,nonzero:true}
  ],
  compute(i){
    if (i.corr > i.tot) throw new Error('Correct answers cannot exceed total questions.');
    const pct = i.corr/i.tot*100;
    const L = pct >= 90 ? 'A' : pct >= 80 ? 'B' : pct >= 70 ? 'C' : pct >= 60 ? 'D' : 'F';
    return { results:[
      {label:'Exam score', value: fmt(pct,1) + '%', hl:true},
      {label:'Letter grade', value: L},
      {label:'Wrong answers', value: fmt(i.tot - i.corr,0)}
    ]};
  }});
