/* ============ CalcNova — UI: router, pages, components ============ */
'use strict';

const SITE_URL = 'https://calcnova.cc';
const app = () => $('#app');
function esc(s){ return String(s == null ? '' : s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }

let __timer = null;
function clearTimer(){ if (__timer){ clearInterval(__timer); __timer = null; } }

/* ---------- SEO ---------- */
function setSEO(title, desc, ld){
  document.title = title;
  let md = document.querySelector('meta[name="description"]');
  if (md) md.setAttribute('content', desc);
  const cp = currentPath().split('?')[0];
  const canonical = SITE_URL + (cp === '/' ? '/' : cp);
  let ou = document.querySelector('meta[property="og:url"]');
  if (ou) ou.setAttribute('content', canonical);
  let lc = document.querySelector('link[rel="canonical"]');
  if (lc) lc.setAttribute('href', canonical);
  let og = document.querySelector('meta[property="og:title"]');
  if (og) og.setAttribute('content', title);
  let od = document.querySelector('meta[property="og:description"]');
  if (od) od.setAttribute('content', desc);
  const old = document.getElementById('ld-json');
  if (old) old.remove();
  if (ld){
    const s = document.createElement('script');
    s.type = 'application/ld+json'; s.id = 'ld-json';
    s.textContent = JSON.stringify(ld);
    document.head.appendChild(s);
  }
}
function breadcrumbLD(items){
  return { '@context':'https://schema.org', '@type':'BreadcrumbList',
    itemListElement: items.map((it, ix) => ({ '@type':'ListItem', position: ix+1, name: it[0], item: SITE_URL + (it[1] === '/' ? '/' : it[1]) })) };
}
function faqLD(faqs){
  return { '@context':'https://schema.org', '@type':'FAQPage',
    mainEntity: faqs.map(f => ({ '@type':'Question', name: f.q, acceptedAnswer: { '@type':'Answer', text: f.a } })) };
}

/* ---------- shared components ---------- */
function adSlot(kind){
  const cls = kind === 'rect' ? 'ad-box ad-rect' : 'ad-box ad-leaderboard';
  const label = kind === 'rect' ? '300 × 250' : '970 × 110 / responsive';
  return '<div class="ad-slot"><!-- AdSense-ready: replace the inner placeholder with your official responsive <ins class="adsbygoogle"> unit (no publisher ID is hard-coded) --><div class="' + cls + '" role="complementary" aria-label="Advertisement"><span>Ad space · ' + label + '</span></div></div>';
}
function crumbs(items){
  return '<nav class="crumbs" aria-label="Breadcrumb">' +
    items.map((it, ix) => ix === items.length - 1
      ? '<span aria-current="page">' + esc(it[0]) + '</span>'
      : '<a href="#' + it[1] + '">' + esc(it[0]) + '</a><span class="sep">›</span>').join('') + '</nav>';
}
function defaultFAQ(c){
  return [
    { q: 'Is the ' + c.name + ' free?', a: 'Yes. Every calculator on CalcNova is completely free, with no sign-up, no limits and no hidden charges.' },
    { q: 'How accurate is it?', a: 'The calculator applies standard, widely accepted formulas and performs all math locally in your browser. Rounding may cause tiny differences from professional software.' },
    { q: 'Does CalcNova store my inputs?', a: 'No. All calculations run entirely in your browser — nothing you type is sent to or stored on any server.' }
  ];
}
function faqHTML(faqs){
  return '<section class="faq"><h2>Frequently Asked Questions</h2>' +
    faqs.map(f => '<details><summary>' + esc(f.q) + '</summary><div class="faq-a">' + esc(f.a) + '</div></details>').join('') + '</section>';
}
function catName(slug){ const c = getCat(slug); return c ? c.name : slug; }
function calcTile(c){
  return '<a class="calc-tile" href="#/calc/' + c.slug + '"><b>' + esc(c.name) + '</b><span>' + esc(c.desc) + '</span></a>';
}
function relatedHTML(c){
  const rel = relatedFor(c);
  if (!rel.length) return '';
  return '<section><h2>Related Calculators</h2><div class="grid grid-3">' +
    rel.map(x => '<a class="card" href="#/calc/' + x.slug + '"><h3>' + esc(x.name) + '</h3><p>' + esc(x.desc) + '</p></a>').join('') + '</div></section>';
}

/* ---------- form fields & validation ---------- */
function fieldHTML(f){
  let inner = '';
  if (f.t === 'select'){
    inner = '<select id="f_' + f.k + '" name="' + f.k + '">' +
      f.opts.map(o => '<option value="' + esc(o.v) + '"' + (String(o.v) === String(f.def) ? ' selected' : '') + '>' + esc(o.l) + '</option>').join('') + '</select>';
  } else if (f.t === 'date'){
    inner = '<input type="date" id="f_' + f.k + '" name="' + f.k + '"' + (f.def ? ' value="' + f.def + '"' : '') + '>';
  } else if (f.t === 'time'){
    inner = '<input type="time" id="f_' + f.k + '" name="' + f.k + '"' + (f.def ? ' value="' + f.def + '"' : '') + '>';
  } else if (f.t === 'list'){
    inner = '<input type="text" id="f_' + f.k + '" name="' + f.k + '" inputmode="decimal" placeholder="' + esc(f.placeholder || '') + '"' + (f.def != null ? ' value="' + f.def + '"' : '') + '>';
  } else {
    inner = '<input type="number" id="f_' + f.k + '" name="' + f.k + '" inputmode="decimal" step="any"' +
      (f.def != null ? ' value="' + f.def + '"' : '') + (f.min !== undefined ? ' min="' + f.min + '"' : '') + (f.max !== undefined ? ' max="' + f.max + '"' : '') + '>';
  }
  const hint = f.hint ? ' <span class="hint">' + esc(f.hint) + '</span>' : '';
  return '<div class="field" data-k="' + f.k + '"><label for="f_' + f.k + '">' + esc(f.label) + hint + '</label>' + inner + '<span class="f-err" id="e_' + f.k + '" aria-live="polite"></span></div>';
}
function setFieldErr(k, msg){
  const el = $('#e_' + k);
  if (el) el.textContent = msg || '';
}
function validateCalc(c){
  const inp = {};
  let firstErr = null;
  for (const f of c.fields){
    const el = $('#f_' + f.k);
    const raw = el ? el.value : '';
    setFieldErr(f.k, '');
    if (f.t === 'number'){
      const n = pnum(raw);
      if (n === null){
        if (f.optional){ inp[f.k] = null; continue; }
        setFieldErr(f.k, 'Please enter a valid number.'); if (!firstErr) firstErr = f.label + ': please enter a valid number.';
        continue;
      }
      if (f.min !== undefined && n < f.min){ setFieldErr(f.k, 'Must be at least ' + f.min + '.'); if (!firstErr) firstErr = f.label + ' must be at least ' + f.min + '.'; continue; }
      if (f.max !== undefined && n > f.max){ setFieldErr(f.k, 'Must be at most ' + f.max + '.'); if (!firstErr) firstErr = f.label + ' must be at most ' + f.max + '.'; continue; }
      if (f.nonzero && n === 0){ setFieldErr(f.k, 'Cannot be zero.'); if (!firstErr) firstErr = f.label + ' cannot be zero.'; continue; }
      inp[f.k] = n;
    } else if (f.t === 'select'){
      inp[f.k] = raw;
    } else if (f.t === 'date'){
      const d = new Date(raw + 'T00:00:00');
      if (!raw || isNaN(d.getTime())){ setFieldErr(f.k, 'Please choose a valid date.'); if (!firstErr) firstErr = f.label + ': please choose a valid date.'; continue; }
      inp[f.k] = d;
    } else if (f.t === 'time'){
      if (!/^([01]?\d|2[0-3]):[0-5]\d$/.test(raw)){ setFieldErr(f.k, 'Enter a valid time (HH:MM).'); if (!firstErr) firstErr = f.label + ': enter a valid time.'; continue; }
      inp[f.k] = raw;
    } else if (f.t === 'list'){
      try { inp[f.k] = parseList(raw); }
      catch(e){ setFieldErr(f.k, e.message); if (!firstErr) firstErr = f.label + ': ' + e.message; }
    }
  }
  if (firstErr) throw new Error(firstErr);
  return inp;
}
function resultsHTML(res){
  const rows = res.results.map(r =>
    '<tr' + (r.hl ? ' class="hl"' : '') + '><td>' + esc(r.label) + '</td><td class="v">' + esc(r.value) + '</td></tr>').join('');
  return '<div class="results show" id="results" aria-live="polite"><div class="results-header">Results</div><table>' + rows + '</table>' +
    (res.note ? '<div class="results-note">' + esc(res.note) + '</div>' : '') + '</div>';
}

/* ---------- generic calculator page ---------- */
function renderCalcPage(c){
  const cat = c.cats[0];
  const faqs = (c.faq && c.faq.length) ? c.faq : defaultFAQ(c);
  const isHealth = c.cats.indexOf('health') >= 0;
  const isMoney  = c.cats.some(k => ['finance','investment','business','real-estate'].indexOf(k) >= 0);
  const fields = c.fields ? c.fields.map(fieldHTML).join('') : '';
  const cols2 = c.fields && c.fields.length > 2 ? ' cols-2' : '';

  let mainCalc;
  if (c.custom === 'basic') mainCalc = basicCalcHTML();
  else if (c.custom === 'scientific') mainCalc = sciCalcHTML();
  else mainCalc =
    '<form class="calc-form' + cols2 + '" id="calc-form" novalidate>' + fields +
    '<div class="form-actions"><button type="submit" class="btn btn-primary">Calculate</button>' +
    '<button type="reset" class="btn btn-ghost">Reset</button></div></form>' +
    '<div class="calc-error" id="calc-error" role="alert" aria-live="assertive"></div><div id="calc-results"></div>';

  const html =
    crumbs([['Home','/'],['Calculators','/calculators'],[catName(cat),'/category/' + cat],[c.name,'/calc/' + c.slug]]) +
    '<h1>' + esc(c.name) + '</h1>' +
    '<p class="page-intro">' + esc(c.desc) + '</p>' +
    adSlot('leaderboard') +
    '<div class="calc-shell"><div class="calc-card-main">' + mainCalc +
    (isMoney ? '<div class="disclaimer">📋 Financial estimates only — not personalized financial advice. Actual rates, fees and taxes vary.</div>' : '') +
    (isHealth ? '<div class="disclaimer">⚕️ Health estimates only — not medical advice. Consult a qualified healthcare professional.</div>' : '') +
    '</div><aside class="side-col"><div class="ad-box ad-rect" role="complementary" aria-label="Advertisement"><span>Ad space · 300 × 250</span></div>' +
    '<div><h3 style="margin-top:0">Quick links</h3>' + relatedFor(c).slice(0,5).map(x => '<p style="margin:6px 0"><a href="#/calc/' + x.slug + '">' + esc(x.name) + '</a></p>').join('') + '</div></aside></div>' +
    (c.expl ? '<div class="explain-box"><h2>How it works</h2><p>' + esc(c.expl) + '</p></div>' : '') +
    (c.formula ? '<div class="formula-box"><h2>Formula</h2><code>' + esc(c.formula) + '</code></div>' : '') +
    (c.example ? '<div class="example-box"><h2>Worked example</h2><p>' + esc(c.example) + '</p></div>' : '') +
    (c.note ? '<div class="note-box warn"><strong>Important notes:</strong><p>' + esc(c.note) + '</p></div>' : '') +
    faqHTML(faqs) +
    relatedHTML(c) +
    adSlot('leaderboard');

  app().innerHTML = html;
  setSEO(c.name + ' — CalcNova', c.desc + ' Free, fast and private — all calculations run in your browser.', [breadcrumbLD([['Home','/'],['Calculators','/calculators'],[catName(cat),'/category/' + cat],[c.name,'/calc/' + c.slug]]), faqLD(faqs)]);

  if (c.custom === 'basic') initBasicCalc();
  else if (c.custom === 'scientific') initSciCalc();
  else if (c.fields){
    $('#calc-form').addEventListener('submit', function(e){
      e.preventDefault();
      clearTimer();
      const errBox = $('#calc-error'), resBox = $('#calc-results');
      errBox.classList.remove('show'); resBox.innerHTML = '';
      try {
        const inp = validateCalc(c);
        const res = c.compute(inp);
        resBox.innerHTML = resultsHTML(res);
        const r = $('#results'); if (r) r.scrollIntoView({ behavior:'smooth', block:'nearest' });
        if (res.countdown){
          const target = res.countdown;
          __timer = setInterval(() => {
            const ms = target - new Date();
            if (ms <= 0){ clearTimer(); return; }
            const d = Math.floor(ms/86400000), hh = Math.floor(ms/3600000)%24, mm = Math.floor(ms/60000)%60, ss = Math.floor(ms/1000)%60;
            const cell = $('#results tr.hl .v');
            if (cell) cell.textContent = d + ' days, ' + hh + ' hours, ' + mm + ' minutes, ' + ss + ' seconds';
          }, 1000);
        }
      } catch(err){
        errBox.textContent = err.message || 'Something went wrong. Please check your inputs.';
        errBox.classList.add('show');
      }
    });
    $('#calc-form').addEventListener('reset', () => {
      $$('.f-err').forEach(e => e.textContent = '');
      $('#calc-error').classList.remove('show');
      $('#calc-results').innerHTML = '';
      clearTimer();
    });
  }
}

/* ---------- basic calculator ---------- */
function basicCalcHTML(){
  const keys = ['C','⌫','%','÷','7','8','9','×','4','5','6','−','1','2','3','+','±','0','.','='];
  return '<div class="calc-widget"><div class="calc-display" aria-live="polite"><div class="calc-expr" id="bc-expr">&nbsp;</div><div class="calc-result" id="bc-result">0</div></div>' +
    '<div class="calc-pad" role="group" aria-label="Calculator keypad">' +
    keys.map(k => {
      let cls = '';
      if ('÷×−+'.indexOf(k) >= 0) cls = ' class="op"';
      else if (k === '=') cls = ' class="eq"';
      else if (k === 'C' || k === '⌫') cls = ' class="danger"';
      return '<button type="button" data-key="' + k + '"' + cls + '>' + k + '</button>';
    }).join('') + '</div>' +
    '<p class="small muted" style="text-align:center;margin:12px 0 0">Keyboard supported · % converts the last number to a percent</p></div>';
}
function initBasicCalc(){
  let expr = '', justEq = false;
  const exEl = $('#bc-expr'), rEl = $('#bc-result');
  const show = (e, r) => { exEl.textContent = e || ' '; rEl.textContent = r; };
  const lastNum = () => /(\d*\.?\d+)$/.exec(expr);
  /* FIX: never show "Error" for incomplete expressions while typing (e.g. "5 ×", "(") */
  const isIncomplete = e => {
    if (!e) return true;
    if (/[÷×−+^.(]$/.test(e)) return true;
    const o = (e.match(/\(/g) || []).length, c = (e.match(/\)/g) || []).length;
    return o !== c;
  };
  const evaluate = live => {
    if (!expr) return '0';
    if (live && isIncomplete(expr)) return '…';
    try { const v = evalExpr(expr); return fmt(v, Math.abs(v) < 1e-4 && v !== 0 ? 6 : 4); }
    catch(e){
      return live ? '…' : (e.message === 'Division by zero.' ? 'Cannot divide by zero' : 'Error');
    }
  };
  const press = k => {
    if (k === 'C'){ expr = ''; justEq = false; show('', '0'); return; }
    if (k === '⌫'){ expr = expr.slice(0, -1); justEq = false; show(expr, evaluate(true)); return; }
    if (k === '='){
      const r = evaluate(false);
      show(expr + ' =', r);
      if (r !== 'Error' && r !== 'Cannot divide by zero' && r !== '…' && r.indexOf('e') < 0) expr = r.replace(/,/g, '');
      else expr = '';
      justEq = true; return;
    }
    if (k === '±'){ const m = lastNum(); if (m){ expr = expr.slice(0, m.index) + '(' + (m[1].startsWith('-') ? m[1].slice(1) : '-' + m[1]) + ')'; } show(expr, evaluate(true)); return; }
    if (k === '%'){ const m = lastNum(); if (m){ expr = expr.slice(0, m.index) + '(' + (parseFloat(m[1])/100) + ')'; } show(expr, evaluate(true)); return; }
    if (justEq && /[0-9.]/.test(k)){ expr = ''; }
    justEq = false;
    if ('÷×−+'.indexOf(k) >= 0){
      if (!expr){ if (k === '−') expr = '-'; show(expr, evaluate()); return; }
      const lastC = expr.slice(-1);
      if ('÷×−+'.indexOf(lastC) >= 0){ expr = expr.slice(0, -1) + k; }
      else expr += k;
    } else {
      if (expr.replace(/[^0-9]/g, '').length > 15) return;
      expr += k;
    }
    show(expr, evaluate(true));
  };
  $$('#bc-expr, #bc-result'); // noop
  $$('.calc-pad button').forEach(b => b.addEventListener('click', () => press(b.getAttribute('data-key'))));
  window.__bcKeyHandler = e => {
    const map = { '*': '×', '/': '÷', '-': '−', '+': '+', '.': '.', '%': '%', Enter: '=', '=': '=', Backspace: '⌫', Escape: 'C' };
    if (/^[0-9]$/.test(e.key)) press(e.key);
    else if (map[e.key] !== undefined){ e.preventDefault(); press(map[e.key]); }
  };
  document.addEventListener('keydown', window.__bcKeyHandler);
  show('', '0');
}
function removeBasicKeyHandler(){
  if (window.__bcKeyHandler){ document.removeEventListener('keydown', window.__bcKeyHandler); window.__bcKeyHandler = null; }
}

/* ---------- scientific calculator ---------- */
function sciCalcHTML(){
  const keys = ['sin(','cos(','tan(','(',')','⌫','ln(','log(','sqrt(','^','!','C','asin(','acos(','atan(','π','e','.','abs(','exp(','1','2','3','÷','4','5','6','×','7','8','9','−','0','%','+','='];
  return '<div class="calc-widget" style="max-width:520px"><div class="calc-display" aria-live="polite"><div class="calc-expr" id="sc-expr">&nbsp;</div><div class="calc-result" id="sc-result">0</div></div>' +
    '<div class="sci-pad" role="group" aria-label="Scientific keypad">' +
    keys.map(k => '<button type="button" data-key="' + esc(k) + '">' + esc(k) + '</button>').join('') + '</div>' +
    '<p class="small muted" style="text-align:center;margin:12px 0 0">Angles in radians · ^ for powers · ! for factorial</p></div>';
}
function initSciCalc(){
  let expr = '';
  const exEl = $('#sc-expr'), rEl = $('#sc-result');
  const show = (e, r) => { exEl.textContent = e || ' '; rEl.textContent = r; };
  /* FIX: same incomplete-expression guard as the basic calculator */
  const isIncomplete = e => {
    if (!e) return true;
    if (/[+\-*/^.(]$/.test(e)) return true;
    const o = (e.match(/\(/g) || []).length, c = (e.match(/\)/g) || []).length;
    return o !== c;
  };
  const evaluate = live => {
    if (!expr) return '0';
    if (live && isIncomplete(expr)) return '…';
    try { const v = evalExpr(expr); return fmt(v, Math.abs(v) < 1e-4 && v !== 0 ? 6 : 4); }
    catch(e){ return live ? '…' : (e.message || 'Error'); }
  };
  $$('.sci-pad button').forEach(b => b.addEventListener('click', () => {
    const k = b.getAttribute('data-key');
    if (k === 'C'){ expr = ''; show('', '0'); return; }
    if (k === '⌫'){ expr = expr.slice(0, -1); show(expr, evaluate(true)); return; }
    if (k === '='){ show(expr + ' =', evaluate(false)); expr = ''; return; }
    if (k === 'π'){ expr += 'pi'; }
    else expr += k;
    show(expr, evaluate(true));
  }));
}

/* ---------- homepage ---------- */
const POPULAR = ['basic-calculator','percentage-calculator','savings-calculator','zakat-calculator','bmi-calculator','age-calculator','tip-calculator','length-converter'];
function renderHome(){
  const popular = POPULAR.map(getCalc).filter(Boolean);
  const html =
  '<section class="hero"><div class="container"><span class="badge">' + CALCS.length + '+ free calculators</span>' +
  '<h1>Smart Calculators for Everyday Life</h1>' +
  '<p class="lead">Fast, accurate, and easy-to-use calculators for finance, math, health, business, conversions, time, and more.</p>' +
  '<a class="btn btn-primary btn-lg" href="#/calculators">Explore All Calculators</a></div></section>' +

  adSlot('leaderboard') + /* FIX: AdSense-ready top placement — below hero/header, above the primary calculator */

  '<section class="section"><div class="container"><div class="section-head"><h2>Quick Calculator</h2><p>Need a fast answer? Use the calculator below — it supports your keyboard too.</p></div>' +
  basicCalcHTML() + '</div></section>' +

  adSlot('leaderboard') +

  '<section class="section section-alt"><div class="container"><div class="section-head"><h2>Calculator Categories</h2><p>Eleven categories covering the calculations people need most.</p></div>' +
  '<div class="grid grid-3">' + CATS.map(c =>
    '<a class="card" href="#/category/' + c.slug + '"><div class="cat-icon">' + c.icon + '</div><span class="count">' + calcsByCat(c.slug).length + ' calculators</span><h3>' + esc(c.name) + '</h3><p>' + esc(c.desc) + '</p></a>').join('') +
  '</div></div></section>' +

  '<section class="section"><div class="container"><div class="section-head"><h2>Popular Calculators</h2><p>The tools visitors use most, one click away.</p></div>' +
  '<div class="pop-grid">' + popular.map(calcTile).join('') + '</div>' +
  '<p style="text-align:center;margin-top:22px"><a class="btn btn-ghost" href="#/calculators">Browse all calculators →</a></p></div></section>' +

  '<section class="section section-alt"><div class="container"><div class="section-head"><h2>Why Choose CalcNova</h2></div><div class="grid grid-3">' +
  [['⚡','Fast & lightweight','Pages load instantly and calculations run locally in your browser — no waiting on servers.'],
   ['🔒','Private by design','Your inputs never leave your device. No accounts, no tracking of what you calculate.'],
   ['✓','Mathematically correct','Every calculator uses standard, verifiable formulas with careful input validation.'],
   ['📱','Works everywhere','Fully responsive — phone, tablet, laptop or desktop, the layout adapts cleanly.'],
   ['📚', CALCS.length + '+ calculators', 'From zakat to BMI to time zones — one site covers everyday math for work and life.'],
   ['🌙','Light & dark mode','A professional dark theme that follows your preference and is easy on the eyes.']].map(f =>
    '<div class="feature-card"><div class="fi">' + f[0] + '</div><h3>' + f[1] + '</h3><p class="muted">' + f[2] + '</p></div>').join('') +
  '</div></div></section>' +

  '<section class="section"><div class="container"><div class="section-head"><h2>How It Works</h2></div><div class="grid grid-3">' +
  [['1','Find your calculator','Search or browse the categories to find the right tool.'],
   ['2','Enter your numbers','Fill in the fields — invalid input is caught and explained clearly.'],
   ['3','Get instant results','See the answer, the formula and a worked example immediately.']].map(s =>
    '<div class="feature-card steps"><div class="step-num">' + s[0] + '</div><h3>' + s[1] + '</h3><p class="muted">' + s[2] + '</p></div>').join('') +
  '</div></div></section>' +

  '<section class="section"><div class="container" style="max-width:760px">' +
  faqHTML([
    { q:'Are all CalcNova calculators really free?', a:'Yes — every calculator is 100% free with no usage limits, no sign-up and no paywalls.' },
    { q:'Is my data safe?', a:'All calculations happen locally in your browser. CalcNova does not collect, transmit or store the numbers you enter.' },
    { q:'How accurate are the results?', a:'Each calculator implements widely accepted formulas (such as Mifflin-St Jeor for BMR or standard percentage arithmetic) and validates every input before computing.' },
    { q:'Can I use the calculators on my phone?', a:'Absolutely. The entire site is responsive and the calculators are designed for touch screens first.' },
    { q:'Does CalcNova give financial or medical advice?', a:'No. Calculators are informational tools only. For decisions about money or health, consult a qualified professional.' }
  ]) + '</div></section>' +

  '<section class="section"><div class="container"><div class="cta-band"><h2>Get answers in seconds</h2>' +
  '<p>Join thousands of people who use CalcNova for quick, reliable everyday calculations — free, private, and fast.</p>' +
  '<a class="btn btn-lg" href="#/calculators">Start Calculating</a></div></div></section>' +

  adSlot('leaderboard');

  app().innerHTML = html;
  setSEO('CalcNova — Smart Calculators for Everyday Life',
    'Free online calculators for finance, math, health, business, conversions, time and more. Fast, accurate and private — no sign-up required.');
  initBasicCalc();
}

/* ---------- category / calculators index ---------- */
function renderCategories(){
  const html = crumbs([['Home','/'],['Categories','/categories']]) +
    '<h1>All Calculator Categories</h1><p class="page-intro">Eleven categories, ' + CALCS.length + ' calculators — all free.</p>' +
    '<div class="grid grid-3" style="margin-top:22px">' + CATS.map(c =>
      '<a class="card" href="#/category/' + c.slug + '"><div class="cat-icon">' + c.icon + '</div><span class="count">' + calcsByCat(c.slug).length + ' calculators</span><h3>' + esc(c.name) + '</h3><p>' + esc(c.desc) + '</p></a>').join('') + '</div>';
  app().innerHTML = html;
  setSEO('Calculator Categories — CalcNova', 'Browse all CalcNova calculator categories: math, finance, health, time, conversion, business, investment, real estate, statistics, education and technology.');
}
function renderCategory(slug){
  const cat = getCat(slug);
  if (!cat){ render404(); return; }
  const list = calcsByCat(slug);
  const related = CATS.filter(c => c.slug !== slug).slice(0, 4);
  const html = crumbs([['Home','/'],['Categories','/categories'],[cat.name,'/category/' + slug]]) +
    '<h1>' + esc(cat.name) + '</h1><p class="page-intro">' + esc(cat.desc) + '</p>' +
    adSlot('leaderboard') +
    '<div class="field" style="max-width:420px;margin:18px 0"><label for="cat-filter">Filter ' + list.length + ' calculators</label>' +
    '<input type="search" id="cat-filter" placeholder="Type to filter…" autocomplete="off"></div>' +
    '<div class="grid grid-2" id="cat-grid">' + list.map(calcTile).join('') + '</div>' +
    '<p class="muted" id="cat-empty" style="display:none">No calculators match your filter.</p>' +
    '<section style="margin-top:40px"><h2>Related Categories</h2><div class="grid grid-4">' +
    related.map(c => '<a class="card" href="#/category/' + c.slug + '"><h3>' + esc(c.name) + '</h3><p>' + esc(c.desc) + '</p></a>').join('') + '</div></section>' +
    adSlot('leaderboard');
  app().innerHTML = html;
  setSEO(cat.name + ' — CalcNova', cat.desc + ' Free, fast and mobile-friendly.', breadcrumbLD([['Home','/'],['Categories','/categories'],[cat.name,'/category/' + slug]]));
  const inp = $('#cat-filter'), grid = $('#cat-grid');
  inp.addEventListener('input', () => {
    const q = inp.value.trim().toLowerCase();
    let visible = 0;
    $$('.calc-tile', grid).forEach(t => {
      const hit = t.textContent.toLowerCase().indexOf(q) >= 0;
      t.style.display = hit ? '' : 'none';
      if (hit) visible++;
    });
    $('#cat-empty').style.display = visible ? 'none' : '';
  });
  inp.focus();
}
function renderCalcIndex(){
  const html = crumbs([['Home','/'],['Calculators','/calculators']]) +
    '<h1>All Calculators</h1><p class="page-intro">' + CALCS.length + ' free calculators. Search by name or keyword.</p>' +
    '<div class="field" style="max-width:460px;margin:18px 0"><label for="all-filter">Search calculators</label>' +
    '<input type="search" id="all-filter" placeholder="e.g. loan, BMI, days, percent…" autocomplete="off"></div>' +
    '<div class="grid grid-3" id="all-grid">' + CALCS.map(calcTile).join('') + '</div>' +
    '<p class="muted" id="all-empty" style="display:none">No calculators match your search. Try a different keyword.</p>';
  app().innerHTML = html;
  setSEO('All Calculators A–Z — CalcNova', 'The complete list of ' + CALCS.length + ' free CalcNova calculators, searchable by name, category and keyword.');
  const inp = $('#all-filter'), grid = $('#all-grid');
  inp.addEventListener('input', () => {
    const q = inp.value.trim().toLowerCase();
    let visible = 0;
    $$('.calc-tile', grid).forEach(t => {
      const hit = t.textContent.toLowerCase().indexOf(q) >= 0;
      t.style.display = hit ? '' : 'none';
      if (hit) visible++;
    });
    $('#all-empty').style.display = visible ? 'none' : '';
  });
  inp.focus();
}

/* ---------- search ---------- */
function searchCalcs(q){
  q = q.trim().toLowerCase();
  if (!q) return [];
  return CALCS.map(c => {
    let score = 0;
    const name = c.name.toLowerCase();
    if (name === q) score = 100;
    else if (name.indexOf(q) === 0) score = 80;
    else if (name.indexOf(q) >= 0) score = 60;
    const hay = (c.kw + ' ' + c.desc + ' ' + c.cats.map(catName).join(' ')).toLowerCase();
    if (score === 0 && hay.indexOf(q) >= 0) score = 30;
    return { c: c, score: score };
  }).filter(x => x.score > 0).sort((a, b) => b.score - a.score).map(x => x.c);
}
function searchResultItem(c){
  return '<a class="sr-item" href="#/calc/' + c.slug + '"><span class="sr-cat">' + esc(catName(c.cats[0])) + '</span><span class="sr-name">' + esc(c.name) + '</span><span class="sr-desc">' + esc(c.desc) + '</span></a>';
}
function initHeaderSearch(){
  const inp = $('#site-search'), drop = $('#search-drop');
  let deb = null;
  inp.addEventListener('input', () => {
    clearTimeout(deb);
    deb = setTimeout(() => {
      const q = inp.value.trim();
      if (q.length < 2){ drop.classList.remove('open'); drop.innerHTML = ''; return; }
      const res = searchCalcs(q).slice(0, 8);
      drop.innerHTML = res.length
        ? res.map(searchResultItem).join('')
        : '<div class="sr-empty">No results found for "' + esc(q) + '"<br><a href="#/calculators">Browse all calculators</a></div>';
      drop.classList.add('open');
    }, 160);
  });
  inp.addEventListener('keydown', e => {
    if (e.key === 'Enter'){ e.preventDefault(); const q = inp.value.trim(); if (q) navigate('/search?q=' + encodeURIComponent(q)); drop.classList.remove('open'); }
    if (e.key === 'Escape'){ drop.classList.remove('open'); inp.blur(); }
  });
  document.addEventListener('click', e => {
    if (!e.target.closest('.search-wrap')) drop.classList.remove('open');
  });
}
function renderSearch(q){
  const res = searchCalcs(q || '');
  const html = crumbs([['Home','/'],['Search','/search']]) +
    '<h1>Search Results</h1>' +
    '<div class="field" style="max-width:460px;margin:14px 0 22px"><label for="search-page-q">Search ' + CALCS.length + ' calculators</label>' +
    '<input type="search" id="search-page-q" value="' + esc(q || '') + '" autocomplete="off"></div>' +
    (res.length
      ? '<p class="muted">' + res.length + ' result' + (res.length > 1 ? 's' : '') + ' for "' + esc(q) + '"</p><div class="grid grid-3">' + res.map(calcTile).join('') + '</div>'
      : '<div class="note-box"><h3>No results found</h3><p>We couldn\'t find a calculator matching "<strong>' + esc(q) + '</strong>". Try a simpler keyword such as "loan", "percent", "days" or "weight" — or browse the categories below.</p></div>' +
        '<div class="grid grid-4" style="margin-top:20px">' + CATS.map(c => '<a class="card" href="#/category/' + c.slug + '"><h3>' + esc(c.name) + '</h3></a>').join('') + '</div>');
  app().innerHTML = html;
  setSEO('Search: ' + (q || '') + ' — CalcNova', 'Search results for calculators on CalcNova.');
  const inp = $('#search-page-q');
  inp.addEventListener('keydown', e => { if (e.key === 'Enter'){ const v = inp.value.trim(); if (v) navigate('/search?q=' + encodeURIComponent(v)); } });
  inp.focus();
}

/* ---------- static pages ---------- */
function pageShell(title, body, seodesc){
  app().innerHTML = crumbs([['Home','/'],[title,'/' + title.toLowerCase().replace(/\s+/g,'-')]]) + '<div class="legal-page">' + body + '</div>';
  setSEO(title + ' — CalcNova', seodesc);
}
function renderAbout(){
  pageShell('About Us',
    '<h1>About CalcNova</h1>' +
    '<p>CalcNova is an independent project built around a simple idea: everyday math should be fast, accurate and free. We provide a growing library of carefully built calculators covering finance, mathematics, health, business, time, conversions, statistics, education and technology.</p>' +
    '<h2>What we believe</h2>' +
    '<p><strong>Accuracy first.</strong> Every calculator implements standard, verifiable formulas — from zakat arithmetic to the Mifflin-St Jeor equation — and every input is validated so you never get a silently wrong answer.</p>' +
    '<p><strong>Privacy by design.</strong> All calculations run entirely in your browser. We never see, transmit or store the numbers you type.</p>' +
    '<p><strong>No clutter.</strong> A clean interface, clearly separated advertising space, and no dark patterns. The tool is the point.</p>' +
    '<h2>What CalcNova is not</h2>' +
    '<p>CalcNova is not a bank, financial institution, medical provider or financial adviser. Our calculators produce estimates for informational purposes. For decisions about loans, investments or health, please consult a qualified professional.</p>' +
    '<h2>Contact</h2><p>Feedback and suggestions are welcome — use the <a href="#/contact">contact page</a>.</p>',
    'Learn about CalcNova — a free, private, browser-based calculator platform covering finance, math, health, business and more.');
}
function renderContact(){
  pageShell('Contact',
    '<h1>Contact Us</h1>' +
    '<p class="muted">Have a suggestion for a new calculator, found a bug, or want to report an error? Send us a message below.</p>' +
    '<form class="calc-form contact-form" id="contact-form" novalidate style="margin-top:18px">' +
    fieldHTML({k:'name',label:'Name',t:'text'}) +
    fieldHTML({k:'email',label:'Email',t:'email'}) +
    fieldHTML({k:'subject',label:'Subject',t:'text'}) +
    '<div class="field"><label for="f_message">Message</label><textarea id="f_message" rows="5"></textarea><span class="f-err" id="e_message"></span></div>' +
    '<div class="form-actions"><button class="btn btn-primary" type="submit">Send Message</button></div>' +
    '<div class="calc-error" id="calc-error" role="alert"></div>' +
    '<div class="results" id="contact-ok" style="display:none"><div class="results-header">Message prepared</div><div class="results-note">Thanks for reaching out. Please note: this form currently validates your input locally only — CalcNova does not send or store messages because no backend service is connected yet. You can reach the project team by noting your feedback for the next update.</div></div>' +
    '</form>' +
    '<p class="small muted">We aim to review all feedback. Please do not include passwords or sensitive personal information.</p>',
    'Contact CalcNova with suggestions, corrections or bug reports.');
  $('#contact-form').addEventListener('submit', e => {
    e.preventDefault();
    const err = $('#calc-error');
    err.classList.remove('show');
    const name = $('#f_name').value.trim(), email = $('#f_email').value.trim(),
          subj = $('#f_subject').value.trim(), msg = $('#f_message').value.trim();
    let bad = null;
    if (name.length < 2) bad = 'Please enter your name.';
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) bad = 'Please enter a valid email address.';
    else if (subj.length < 3) bad = 'Please enter a subject.';
    else if (msg.length < 10) bad = 'Please enter a message (at least 10 characters).';
    if (bad){ err.textContent = bad; err.classList.add('show'); return; }
    $('#contact-ok').style.display = 'block';
    e.target.reset();
  });
}
function renderLegal(slug){
  const pages = {
    'privacy-policy': ['Privacy Policy',
      '<p class="muted">Last updated: January 2026</p>' +
      '<h2>1. Overview</h2><p>CalcNova ("we", "the site") is a static website providing free online calculators. This policy explains what information is handled when you use the site.</p>' +
      '<h2>2. Information we do not collect</h2><p>All calculations are performed locally in your browser. We do not operate user accounts, and the numbers you enter into any calculator are never transmitted to or stored on our servers.</p>' +
      '<h2>3. Information stored on your device</h2><p>We store your theme preference (light or dark mode) in your browser\'s local storage so the site remembers your choice. This stays on your device and is never sent anywhere.</p>' +
      '<h2>4. Advertising</h2><p>The site reserves clearly labeled spaces for advertising. If advertising is enabled in the future, ad partners may use cookies or similar technologies to measure performance, subject to their own privacy policies. No advertising cookies are set by the site today.</p>' +
      '<h2>5. Analytics</h2><p>The site currently uses no analytics services.</p>' +
      '<h2>6. Changes</h2><p>We may update this policy as the site evolves. Material changes will be reflected on this page.</p>',
      'CalcNova privacy policy: what data is handled (almost none) when you use our free calculators.'],
    'terms': ['Terms of Use',
      '<p class="muted">Last updated: January 2026</p>' +
      '<h2>1. Acceptance</h2><p>By using CalcNova you agree to these terms. If you do not agree, please do not use the site.</p>' +
      '<h2>2. The service</h2><p>CalcNova provides free online calculators for informational purposes. The site is provided "as is" and "as available".</p>' +
      '<h2>3. No professional advice</h2><p>Calculator outputs are estimates based on the inputs you provide and standard formulas. They do not constitute financial, medical, legal, tax or other professional advice. Always verify important calculations and consult a qualified professional before making decisions.</p>' +
      '<h2>4. Accuracy</h2><p>We work hard to keep formulas correct and inputs validated, but we do not warrant that results are error-free or fit for any particular purpose.</p>' +
      '<h2>5. Limitation of liability</h2><p>To the maximum extent permitted by law, CalcNova is not liable for any damages or losses arising from use of, or reliance on, the site or its results.</p>' +
      '<h2>6. Intellectual property</h2><p>The CalcNova name, design and original content belong to the project. You may link to any page freely.</p>',
      'CalcNova terms of use: free calculators provided as-is, for informational purposes only.'],
    'disclaimer': ['Disclaimer',
      '<p class="muted">Last updated: January 2026</p>' +
      '<h2>General</h2><p>All calculators on CalcNova produce estimates for informational and educational purposes only. Results depend entirely on the accuracy of your inputs and the simplifying assumptions documented on each calculator page.</p>' +
      '<h2>Financial calculators</h2><p>Savings, zakat, budgeting, retirement and tax-related calculators do not account for every fee, market movement or tax rule, and they are <strong>not personalized financial or religious advice</strong>. Consult a qualified professional before making financial decisions. Zakat and Islamic-finance tools are educational mathematical calculators — verify important religious decisions with a qualified scholar.</p>' +
      '<h2>Health calculators</h2><p>BMI, BMR, calorie, body-fat and related calculators use population-level formulas. They cannot diagnose, treat or prevent any condition and are <strong>not medical advice</strong>. Consult a qualified healthcare provider about your health.</p>' +
      '<h2>External factors</h2><p>Interest rates, tax rules, market returns and medical guidelines change over time. Always verify current figures with an official source.</p>',
      'CalcNova disclaimer: calculator results are informational estimates, not financial or medical advice.'],
    'cookie-policy': ['Cookie Policy',
      '<p class="muted">Last updated: January 2026</p>' +
      '<h2>1. What are cookies?</h2><p>Cookies are small text files websites store in your browser. This policy explains how CalcNova uses them.</p>' +
      '<h2>2. Current use</h2><p>Today, CalcNova sets <strong>no cookies</strong>. Your theme preference (light/dark mode) is stored in browser local storage — not a cookie — and never leaves your device.</p>' +
      '<h2>3. Future advertising</h2><p>Clearly labeled advertisement spaces exist on the site. If advertising is activated later, third-party ad partners may set cookies for measurement and fraud prevention, governed by their own policies. We will update this page if that happens.</p>' +
      '<h2>4. Managing cookies</h2><p>You can block or delete cookies at any time in your browser settings. Blocking cookies will not affect calculator functionality.</p>',
      'CalcNova cookie policy: the site currently sets no cookies; only a local theme preference is stored.']
  };
  const p = pages[slug];
  if (!p){ render404(); return; }
  pageShell(p[0], p[1], p[2]);
}
function render404(){
  app().innerHTML = '<div class="error-page container"><h1>404 — Page Not Found</h1>' +
    '<p class="muted">The page you are looking for does not exist or has moved.</p>' +
    '<p style="margin-top:18px"><a class="btn btn-primary" href="#/">Go to Homepage</a> <a class="btn btn-ghost" href="#/calculators">Browse Calculators</a></p></div>';
  setSEO('Page Not Found (404) — CalcNova', 'The page you requested could not be found on CalcNova.');
}

/* ---------- router ---------- */
function currentPath(){
  /* Prefer real (history-API) paths for indexable URLs; fall back to hash routes for old bookmarks. */
  let p = location.pathname || '/';
  if (p.length > 1 && p.charAt(p.length - 1) === '/') p = p.slice(0, -1);
  if (p !== '/' && p !== '/index.html' && p !== '') return p + location.search;
  const h = location.hash.replace(/^#/, '');
  return h || '/';
}
function navigate(path){ history.pushState({}, '', path); route(); window.scrollTo(0, 0); }
function route(){
  clearTimer(); removeBasicKeyHandler();
  $$('.f-err').forEach(e => e.textContent = '');
  const path = currentPath();
  const pathOnly = path.split('?')[0];
  const parts = pathOnly.split('/').filter(Boolean);
  const q = (() => { const m = /[?&]q=([^&]*)/.exec(path); return m ? decodeURIComponent(m[1].replace(/\+/g, ' ')) : ''; })();
  if (pathOnly === '/' || pathOnly === '') renderHome();
  else if (parts[0] === 'calc' && parts[1]){ const c = getCalc(parts[1]); if (c) renderCalcPage(c); else render404(); }
  else if (parts[0] === 'category' && parts[1]) renderCategory(parts[1]);
  else if (parts[0] === 'categories') renderCategories();
  else if (parts[0] === 'calculators') renderCalcIndex();
  else if (parts[0] === 'search') renderSearch(q);
  else if (parts[0] === 'about') renderAbout();
  else if (parts[0] === 'contact') renderContact();
  else if (['privacy-policy','terms','disclaimer','cookie-policy'].indexOf(parts[0]) >= 0) renderLegal(parts[0]);
  else render404();
  window.scrollTo(0, 0);
  const mn = $('#mobile-nav'); if (mn) mn.classList.remove('open');
}

/* ---------- boot ---------- */
document.addEventListener('DOMContentLoaded', () => {
  const saved = localStorage.getItem('cn-theme');
  if (saved === 'dark' || (!saved && window.matchMedia('(prefers-color-scheme: dark)').matches)){
    document.documentElement.setAttribute('data-theme', 'dark');
  }
  $('#theme-toggle').addEventListener('click', () => {
    const dark = document.documentElement.getAttribute('data-theme') === 'dark';
    if (dark){ document.documentElement.removeAttribute('data-theme'); localStorage.setItem('cn-theme', 'light'); }
    else { document.documentElement.setAttribute('data-theme', 'dark'); localStorage.setItem('cn-theme', 'dark'); }
  });
  $('#hamburger').addEventListener('click', () => $('#mobile-nav').classList.toggle('open'));
  $$('#mobile-nav a').forEach(a => a.addEventListener('click', () => $('#mobile-nav').classList.remove('open')));
  initHeaderSearch();
  /* Upgrade in-page #/ links to clean history-API URLs (back/forward and refresh work via popstate/currentPath). */
  document.addEventListener('click', (e) => {
    const a = e.target && e.target.closest ? e.target.closest('a[href^="#/"]') : null;
    if (!a) return;
    if (e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || e.button !== 0) return;
    if (a.target && a.target !== '_self') return;
    e.preventDefault();
    navigate(a.getAttribute('href').slice(1));
  });
  window.addEventListener('popstate', route);
  window.addEventListener('hashchange', route);
  route();
});
