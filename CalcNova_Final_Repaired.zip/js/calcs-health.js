/* ============ CalcNova — Health & Fitness calculators ============ */
'use strict';
const H_DISCLAIMER = 'This calculator provides general estimates for informational purposes only. It is not medical advice and cannot diagnose any condition. Consult a qualified healthcare professional before changing your diet, exercise or treatment.';

defCalc({ slug:'bmi-calculator', name:'BMI Calculator', cat:'health',
  desc:'Calculate your Body Mass Index and see the standard weight categories.',
  kw:'BMI,body mass index,weight category,healthy weight',
  formula:'BMI = weight (kg) ÷ height (m)²',
  note: H_DISCLAIMER,
  expl:'Enter your height and weight. BMI categories: below 18.5 underweight, 18.5–24.9 healthy, 25–29.9 overweight, 30+ obese. BMI does not account for muscle mass, age or body composition.',
  example:'A person 175 cm tall weighing 70 kg has a BMI of 22.9 — in the healthy range.',
  fields:[{k:'h',label:'Height (cm)',t:'number',min:0,nonzero:true},{k:'w',label:'Weight (kg)',t:'number',min:0,nonzero:true}],
  compute(i){
    const bmi = i.w / Math.pow(i.h/100, 2);
    const cat = bmi < 18.5 ? 'Underweight' : bmi < 25 ? 'Healthy weight' : bmi < 30 ? 'Overweight' : 'Obese';
    return { results:[
      {label:'Your BMI', value: fmt(bmi,1), hl:true},
      {label:'Category', value: cat, hl:true},
      {label:'Healthy weight range for your height', value: fmt(18.5*Math.pow(i.h/100,2),1) + ' – ' + fmt(24.9*Math.pow(i.h/100,2),1) + ' kg'}
    ]};
  }});

function bmrFields(){
  return [
    {k:'gender',label:'Biological sex (used by the formula)',t:'select',def:'m',opts:[{v:'m',l:'Male'},{v:'f',l:'Female'}]},
    {k:'age',label:'Age (years)',t:'number',min:0,max:120,def:30},
    {k:'h',label:'Height (cm)',t:'number',min:0,nonzero:true},
    {k:'w',label:'Weight (kg)',t:'number',min:0,nonzero:true}
  ];
}
function mifflin(i){
  return 10*i.w + 6.25*i.h - 5*i.age + (i.gender === 'm' ? 5 : -161);
}
const ACTIVITY = [
  {v:'1.2',l:'Sedentary (little or no exercise)'},
  {v:'1.375',l:'Light (exercise 1–3 days/week)'},
  {v:'1.55',l:'Moderate (exercise 3–5 days/week)'},
  {v:'1.725',l:'Active (exercise 6–7 days/week)'},
  {v:'1.9',l:'Very active (physical job or 2× daily training)'}
];

defCalc({ slug:'bmr-calculator', name:'BMR Calculator', cat:'health',
  desc:'Calculate your basal metabolic rate — calories burned at complete rest.',
  kw:'BMR,basal metabolic rate,metabolism,calories at rest',
  formula:'Mifflin-St Jeor: BMR = 10W + 6.25H − 5A + s (s = +5 male, −161 female)',
  note: H_DISCLAIMER,
  expl:'BMR estimates the energy your body needs for basic functions at rest, based on the Mifflin-St Jeor equation — the formula currently recommended by most nutrition bodies.',
  example:'A 30-year-old male, 180 cm, 80 kg: BMR ≈ 1,780 kcal/day.',
  fields: bmrFields(),
  compute(i){
    const b = mifflin(i);
    return { results:[{label:'Your BMR', value: fmt(b,0) + ' kcal/day', hl:true}] };
  }});

defCalc({ slug:'tdee-calculator', name:'TDEE Calculator', cat:'health',
  desc:'Calculate your total daily energy expenditure from BMR and activity level.',
  kw:'TDEE,total daily energy expenditure,maintenance calories,calorie burn',
  formula:'TDEE = BMR × activity factor',
  note: H_DISCLAIMER,
  expl:'Your TDEE is the estimated number of calories you burn per day including all activity. Eat around this amount to maintain your current weight.',
  example:'BMR 1,780 with moderate activity (×1.55): TDEE ≈ 2,759 kcal/day.',
  fields: bmrFields().concat([{k:'act',label:'Activity level',t:'select',def:'1.375',opts:ACTIVITY}]),
  compute(i){
    const t = mifflin(i) * parseFloat(i.act);
    return { results:[
      {label:'Your TDEE', value: fmt(t,0) + ' kcal/day', hl:true},
      {label:'Your BMR', value: fmt(mifflin(i),0) + ' kcal/day'}
    ]};
  }});

defCalc({ slug:'calorie-calculator', name:'Calorie Calculator', cat:'health',
  desc:'Estimate daily calories for losing, maintaining or gaining weight.',
  kw:'calorie calculator,calories to lose weight,maintenance calories,bulk calories',
  formula:'Target = TDEE ± goal adjustment (±500 kcal ≈ ±0.5 kg per week)',
  note: H_DISCLAIMER,
  expl:'The calculator first estimates your TDEE, then adjusts it for your goal: roughly −500 kcal/day to lose about 0.5 kg (1 lb) per week, +500 to gain at a similar rate.',
  example:'TDEE 2,600 kcal with a "lose" goal → target ≈ 2,100 kcal/day.',
  fields: bmrFields().concat([
    {k:'act',label:'Activity level',t:'select',def:'1.375',opts:ACTIVITY},
    {k:'goal',label:'Goal',t:'select',def:'lose',opts:[{v:'lose',l:'Lose weight (−500 kcal)'},{v:'maintain',l:'Maintain weight'},{v:'gain',l:'Gain weight (+500 kcal)'}]}
  ]),
  compute(i){
    const t = mifflin(i) * parseFloat(i.act);
    const adj = i.goal === 'lose' ? -500 : i.goal === 'gain' ? 500 : 0;
    return { results:[
      {label:'Daily calories to ' + i.goal.replace('weight',' weight'), value: fmt(Math.max(t + adj, 1200),0) + ' kcal/day', hl:true},
      {label:'Maintenance (TDEE)', value: fmt(t,0) + ' kcal/day'}
    ]};
  }});

defCalc({ slug:'body-fat-calculator', name:'Body Fat Calculator', cat:'health',
  desc:'Estimate body fat percentage using the U.S. Navy circumference method.',
  kw:'body fat,body fat percentage,Navy method,lean mass',
  formula:'U.S. Navy equations using height, neck, waist (and hip for women)',
  note: H_DISCLAIMER + ' Circumference methods typically carry a ±3–4% error margin.',
  expl:'Take measurements with a tape measure: neck just below the larynx, waist at the navel, and hip at the widest point (women only). The Navy method estimates body fat to within a few percent of lab methods.',
  example:'Male, 180 cm, neck 38 cm, waist 84 cm → about 15% body fat.',
  fields:[
    {k:'gender',label:'Biological sex (used by the formula)',t:'select',def:'m',opts:[{v:'m',l:'Male'},{v:'f',l:'Female'}]},
    {k:'h',label:'Height (cm)',t:'number',min:0,nonzero:true},
    {k:'neck',label:'Neck (cm)',t:'number',min:0,nonzero:true},
    {k:'waist',label:'Waist at navel (cm)',t:'number',min:0,nonzero:true},
    {k:'hip',label:'Hip (cm) — women only',t:'number',min:0,optional:true}
  ],
  compute(i){
    const log10 = Math.log10;
    let bf;
    if (i.gender === 'm'){
      bf = 495/(1.0324 - 0.19077*log10(i.waist - i.neck) + 0.15456*log10(i.h)) - 450;
    } else {
      if (i.hip === null) throw new Error('Please enter your hip measurement.');
      bf = 495/(1.29579 - 0.35004*log10(i.waist + i.hip - i.neck) + 0.22100*log10(i.h)) - 450;
    }
    if (!(bf > 2 && bf < 70)) throw new Error('Measurements look inconsistent — please check them and try again.');
    const cat = i.gender === 'm'
      ? (bf < 6 ? 'Essential fat' : bf < 14 ? 'Athletes' : bf < 18 ? 'Fitness' : bf < 25 ? 'Average' : 'Obese')
      : (bf < 14 ? 'Essential fat' : bf < 21 ? 'Athletes' : bf < 25 ? 'Fitness' : bf < 32 ? 'Average' : 'Obese');
    return { results:[
      {label:'Body fat', value: fmt(bf,1) + '%', hl:true},
      {label:'Category', value: cat},
      {label:'Lean body mass', value: fmt(i.w ? i.w*(1-bf/100) : 0,1) + ' kg'}
    ]};
  }});

defCalc({ slug:'ideal-weight-calculator', name:'Ideal Weight Calculator', cat:'health',
  desc:'See ideal weight estimates from the Devine, Robinson and Miller formulas.',
  kw:'ideal weight,healthy weight,Devine formula,perfect weight',
  formula:'Devine: 50 kg + 2.3 kg per inch over 5 ft (men); 45.5 kg + 2.3 kg per inch (women)',
  note: H_DISCLAIMER,
  expl:'"Ideal weight" formulas are population estimates with wide individual variation. They do not account for muscle mass, bone density or body composition — treat them as rough reference points.',
  example:'A 175 cm male: Devine ≈ 66.5 kg, Robinson ≈ 65.8 kg, Miller ≈ 66.1 kg.',
  fields:[
    {k:'gender',label:'Biological sex (used by the formulas)',t:'select',def:'m',opts:[{v:'m',l:'Male'},{v:'f',l:'Female'}]},
    {k:'h',label:'Height (cm)',t:'number',min:0,nonzero:true}
  ],
  compute(i){
    const inch = i.h/2.54, over = Math.max(inch - 60, 0);
    const dev = (i.gender === 'm' ? 50 : 45.5) + 2.3*over;
    const rob = (i.gender === 'm' ? 52 : 49) + 1.9*over;
    const mil = (i.gender === 'm' ? 56.2 : 53.1) + 1.41*over;
    return { results:[
      {label:'Devine formula', value: fmt(dev,1) + ' kg'},
      {label:'Robinson formula', value: fmt(rob,1) + ' kg'},
      {label:'Miller formula', value: fmt(mil,1) + ' kg'},
      {label:'BMI 18.5–24.9 range', value: fmt(18.5*Math.pow(i.h/100,2),1) + ' – ' + fmt(24.9*Math.pow(i.h/100,2),1) + ' kg', hl:true}
    ]};
  }});

defCalc({ slug:'macro-calculator', name:'Macronutrient Calculator', cat:'health',
  desc:'Split your daily calories into protein, fat and carbohydrate grams.',
  kw:'macros,macronutrients,protein carbs fat,macro split',
  formula:'grams = (calories × percentage) ÷ calories per gram (protein 4, carbs 4, fat 9)',
  note: H_DISCLAIMER,
  expl:'Choose a calorie target and a split preset. Protein and carbs provide ~4 kcal per gram; fat provides ~9 kcal per gram.',
  example:'2,000 kcal balanced → 150 g protein, 67 g fat, 250 g carbs.',
  fields:[
    {k:'cal',label:'Daily calories (kcal)',t:'number',min:0,nonzero:true,def:2000},
    {k:'split',label:'Preset',t:'select',def:'balanced',opts:[
      {v:'balanced',l:'Balanced (30P/25F/45C)'},
      {v:'lowcarb',l:'Low carb (35P/40F/25C)'},
      {v:'highprotein',l:'High protein (40P/20F/40C)'},
      {v:'keto',l:'Keto (25P/70F/5C)'}
    ]}
  ],
  compute(i){
    const splits = { balanced:[30,25,45], lowcarb:[35,40,25], highprotein:[40,20,40], keto:[25,70,5] };
    const s = splits[i.split];
    return { results:[
      {label:'Protein', value: fmt(i.cal*s[0]/100/4,0) + ' g/day', hl:true},
      {label:'Fat', value: fmt(i.cal*s[1]/100/9,0) + ' g/day', hl:true},
      {label:'Carbohydrates', value: fmt(i.cal*s[2]/100/4,0) + ' g/day', hl:true}
    ]};
  }});

defCalc({ slug:'protein-calculator', name:'Protein Calculator', cat:'health',
  desc:'Estimate your daily protein needs based on weight and activity.',
  kw:'protein intake,protein needs,grams of protein,how much protein',
  formula:'grams = weight (kg) × g-per-kg factor for your activity level',
  note: H_DISCLAIMER,
  expl:'Sedentary adults need about 0.8 g/kg; active people 1.2–2.0 g/kg depending on training intensity. Higher targets suit strength athletes and muscle gain phases.',
  example:'A 75 kg person training regularly: about 90–150 g/day.',
  fields:[
    {k:'w',label:'Weight (kg)',t:'number',min:0,nonzero:true},
    {k:'lvl',label:'Activity level',t:'select',def:'1.2',opts:[
      {v:'0.8',l:'Sedentary (0.8 g/kg)'},
      {v:'1.2',l:'Active / endurance (1.2 g/kg)'},
      {v:'1.6',l:'Strength training (1.6 g/kg)'},
      {v:'2.0',l:'Muscle gain / athlete (2.0 g/kg)'}
    ]}
  ],
  compute(i){
    const f = parseFloat(i.lvl);
    return { results:[
      {label:'Daily protein', value: fmt(i.w*f,0) + ' g/day', hl:true},
      {label:'Per meal (4 meals)', value: fmt(i.w*f/4,0) + ' g'}
    ]};
  }});

defCalc({ slug:'water-intake-calculator', name:'Water Intake Calculator', cat:'health',
  desc:'Estimate how much water you should drink each day.',
  kw:'water intake,hydration,how much water,drink water',
  formula:'base = weight (kg) × 0.035 L, plus 0.35 L per 30 min of exercise',
  note: H_DISCLAIMER,
  expl:'Needs vary with climate, diet and health conditions. This gives a sensible baseline for healthy adults; drink more in heat or during intense exercise.',
  example:'A 70 kg person exercising 30 min/day: about 2.8 L/day.',
  fields:[
    {k:'w',label:'Weight (kg)',t:'number',min:0,nonzero:true},
    {k:'ex',label:'Daily exercise (minutes)',t:'number',min:0,def:0}
  ],
  compute(i){
    const L = i.w*0.035 + i.ex/30*0.35;
    return { results:[
      {label:'Daily water intake', value: fmt(L,1) + ' liters (' + fmt(L*33.814,0) + ' fl oz)', hl:true},
      {label:'Glasses (250 ml each)', value: fmt(L/0.25,0)}
    ]};
  }});

defCalc({ slug:'running-pace-calculator', name:'Running Pace Calculator', cat:'health',
  desc:'Calculate your running pace per km or mile from distance and time.',
  kw:'running pace,min per km,pace calculator,running speed',
  formula:'pace = time ÷ distance',
  note: H_DISCLAIMER,
  expl:'Enter the distance you ran and your total time to get pace per kilometer/mile and equivalent speed.',
  example:'10 km in 50 minutes = 5:00 per km (12 km/h).',
  fields:[
    {k:'dist',label:'Distance (km)',t:'number',min:0,nonzero:true,def:10},
    {k:'hh',label:'Hours',t:'number',min:0,def:0},
    {k:'mm',label:'Minutes',t:'number',min:0,max:59,def:50},
    {k:'ss',label:'Seconds',t:'number',min:0,max:59,def:0}
  ],
  compute(i){
    const totalMin = i.hh*60 + i.mm + i.ss/60;
    const pace = totalMin / i.dist;
    const pm = Math.floor(pace), ps = Math.round((pace - pm)*60);
    return { results:[
      {label:'Pace per km', value: pm + ':' + String(ps).padStart(2,'0') + ' min/km', hl:true},
      {label:'Pace per mile', value: fmt(pace*1.60934,2).replace('.',':') + ' min/mi'},
      {label:'Speed', value: fmt(i.dist/(totalMin/60),2) + ' km/h (' + fmt(i.dist/(totalMin/60)*0.621371,2) + ' mph)'}
    ]};
  }});

defCalc({ slug:'running-calories-calculator', name:'Running Calories Calculator', cat:'health',
  desc:'Estimate calories burned during a run from your weight and distance.',
  kw:'running calories,calories burned running,jogging burn',
  formula:'net kcal ≈ weight (kg) × distance (km)',
  note: H_DISCLAIMER,
  expl:'Running costs roughly 1 kcal per kg of body weight per kilometer (gross burn is a bit higher). Terrain, pace and fitness shift the real number.',
  example:'A 70 kg runner covering 8 km burns about 560–640 kcal.',
  fields:[
    {k:'w',label:'Weight (kg)',t:'number',min:0,nonzero:true},
    {k:'d',label:'Distance (km)',t:'number',min:0},
    {k:'p',label:'Average pace (min per km, optional)',t:'number',min:0,optional:true}
  ],
  compute(i){
    const gross = i.w*i.d;
    return { results:[
      {label:'Estimated calories burned', value: fmt(gross,0) + ' kcal', hl:true},
      {label:'Per kilometer', value: fmt(gross/Math.max(i.d,0.001),0) + ' kcal/km'}
    ]};
  }});

defCalc({ slug:'pregnancy-due-date', name:'Pregnancy Due Date Calculator', cat:'health',
  desc:'Estimate your due date from the first day of your last period.',
  kw:'due date,pregnancy calculator,expected delivery,conception date',
  formula:'Due date ≈ first day of last period + 280 days, adjusted for cycle length',
  note: 'This is an estimate — only about 4% of babies arrive on their exact due date. Always confirm with your healthcare provider.',
  expl:'The calculator adds 280 days (40 weeks) to your last menstrual period, then adjusts by your cycle length (longer cycles shift the date later).',
  example:'Last period on January 1 with a 28-day cycle → due date around October 8.',
  fields:[
    {k:'lmp',label:'First day of last period',t:'date'},
    {k:'cycle',label:'Average cycle length (days)',t:'number',min:20,max:45,def:28}
  ],
  compute(i){
    const due = new Date(i.lmp.getTime());
    due.setDate(due.getDate() + 280 + (i.cycle - 28));
    const conc = new Date(i.lmp.getTime()); conc.setDate(conc.getDate() + i.cycle - 14);
    const opt = { year:'numeric', month:'long', day:'numeric' };
    return { results:[
      {label:'Estimated due date', value: due.toLocaleDateString(undefined, opt), hl:true},
      {label:'Estimated conception window', value: conc.toLocaleDateString(undefined, opt) + ' ± 3 days'}
    ]};
  }});
