/* ============ CalcNova — Math calculators ============ */
'use strict';

/* --- Basic & scientific are custom components; still registered for search/SEO --- */
defCalc({ slug:'basic-calculator', name:'Basic Calculator', cat:'math', custom:'basic',
  desc:'A fast, keyboard-friendly basic calculator with addition, subtraction, multiplication, division, percentages and decimals.',
  kw:'calculator,add,subtract,multiply,divide,percent,calculator online',
  formula:'Standard arithmetic operations (+, −, ×, ÷, %)',
  expl:'Enter numbers and operators with the on-screen pad or your keyboard. The calculator follows standard operator precedence and protects against division by zero.',
  example:'For example, type 125 + 75 × 2 = and the result is 275, because multiplication is evaluated before addition.' });

defCalc({ slug:'scientific-calculator', name:'Scientific Calculator', cat:['math','education'], custom:'scientific',
  desc:'A full scientific calculator with trigonometry, logarithms, roots, powers, factorials, π and e.',
  kw:'scientific calculator,sin,cos,tan,log,ln,sqrt,power,factorial',
  formula:'Supports + − × ÷ ^ % ! ( ) and functions sin cos tan asin acos atan ln log sqrt abs exp with constants π and e',
  expl:'Type an expression or use the keypad. The calculator safely evaluates expressions with correct operator precedence. Angles for trigonometric functions are in radians.',
  example:'sin(pi/2) = 1, sqrt(144) = 12, 5! = 120, 2^10 = 1024.' });

defCalc({ slug:'percentage-calculator', name:'Percentage Calculator', cat:['math','education','finance'],
  desc:'Calculate what a percentage of a number is, what percentage one number is of another, and percentage increases.',
  kw:'percent,percentage,percent of,percent increase,percent change',
  formula:'percentage = (part ÷ whole) × 100',
  expl:'Enter the part and the whole. The calculator shows what percent the part is of the whole, plus the remaining percentage and the ratio between the two numbers.',
  example:'If you scored 45 points out of 60, enter 45 and 60 — you scored 75%.',
  fields:[{k:'part',label:'Part (value)',t:'number'},{k:'whole',label:'Whole (total)',t:'number',nonzero:true}],
  compute(i){
    const p = i.part / i.whole * 100;
    return { results:[
      {label:'Percentage', value: fmt(p) + '%', hl:true},
      {label:'Remaining percentage', value: fmt(100 - p) + '%'},
      {label:'Ratio (part : whole)', value: fmt(i.part / i.whole, 6)},
      {label:'100% of the whole equals', value: fmt(i.whole)}
    ]};
  }});

defCalc({ slug:'percentage-increase', name:'Percentage Increase / Decrease', cat:'math',
  desc:'Calculate the percentage change between two values — increases and decreases.',
  kw:'percent increase,percent decrease,percent change,growth rate',
  formula:'change = ((new − old) ÷ |old|) × 100',
  expl:'Enter the starting and ending values. A positive result means growth, a negative result means decline.',
  example:'A price rising from $80 to $100 is a 25% increase.',
  fields:[{k:'old',label:'Starting value',t:'number',nonzero:true},{k:'new',label:'Ending value',t:'number'}],
  compute(i){
    const c = (i.new - i.old) / Math.abs(i.old) * 100;
    return { results:[
      {label:'Percentage change', value: fmt(c) + '%', hl:true},
      {label:'Direction', value: c > 0 ? 'Increase' : (c < 0 ? 'Decrease' : 'No change')},
      {label:'Absolute difference', value: fmt(i.new - i.old)}
    ]};
  }});

defCalc({ slug:'fraction-calculator', name:'Fraction Calculator', cat:['math','education'],
  desc:'Add, subtract, multiply and divide fractions, with automatic simplification.',
  kw:'fractions,add fractions,divide fractions,simplify fraction',
  formula:'a/b + c/d = (ad + bc)/bd — result is reduced by the GCD',
  expl:'Enter two fractions and choose an operation. Results are always reduced to lowest terms and also shown as a decimal.',
  example:'1/2 + 1/3 = 5/6 ≈ 0.8333.',
  fields:[
    {k:'n1',label:'First numerator',t:'number'},{k:'d1',label:'First denominator',t:'number',nonzero:true},
    {k:'op',label:'Operation',t:'select',opts:[{v:'+',l:'Add (+)'},{v:'-',l:'Subtract (−)'},{v:'*',l:'Multiply (×)'},{v:'/',l:'Divide (÷)'}]},
    {k:'n2',label:'Second numerator',t:'number'},{k:'d2',label:'Second denominator',t:'number',nonzero:true}
  ],
  compute(i){
    let n, d;
    if (i.op === '+'){ n = i.n1*i.d2 + i.n2*i.d1; d = i.d1*i.d2; }
    else if (i.op === '-'){ n = i.n1*i.d2 - i.n2*i.d1; d = i.d1*i.d2; }
    else if (i.op === '*'){ n = i.n1*i.n2; d = i.d1*i.d2; }
    else { n = i.n1*i.d2; d = i.d1*i.n2; }
    if (d === 0) throw new Error('The resulting denominator is zero.');
    const g = gcd2(n, d); n /= g; d /= g;
    if (d < 0){ n = -n; d = -d; }
    return { results:[
      {label:'Result (fraction)', value: n + ' / ' + d, hl:true},
      {label:'Result (decimal)', value: fmt(n/d)},
      {label:'Whole + remainder', value: (Math.abs(n) >= d ? Math.trunc(n/d) + ' and ' + Math.abs(n % d) + '/' + d : 'n/a')}
    ]};
  }});

defCalc({ slug:'ratio-calculator', name:'Ratio Calculator', cat:'math',
  desc:'Simplify ratios to their lowest terms and express them as a single number.',
  kw:'ratio,simplify ratio,proportion,a to b',
  formula:'divide both terms by their greatest common divisor',
  expl:'Enter two quantities. The calculator reduces the ratio a:b to simplest form and shows the multiplier used.',
  example:'The ratio 18:24 simplifies to 3:4.',
  fields:[{k:'a',label:'First term (a)',t:'number',nonzero:true},{k:'b',label:'Second term (b)',t:'number',nonzero:true}],
  compute(i){
    const g = gcd2(i.a, i.b);
    return { results:[
      {label:'Simplified ratio', value: (i.a/g) + ' : ' + (i.b/g), hl:true},
      {label:'Ratio as number', value: fmt(i.a / i.b, 6)},
      {label:'Greatest common divisor', value: fmt(g)}
    ]};
  }});

defCalc({ slug:'proportion-calculator', name:'Proportion Calculator', cat:'math',
  desc:'Solve proportions of the form a/b = c/d for the missing value.',
  kw:'proportion,cross multiplication,solve for x,rule of three',
  formula:'if a/b = c/d then d = (b × c) ÷ a',
  expl:'Enter three of the four values and the calculator solves for the fourth using cross-multiplication.',
  example:'If 2/5 = 6/d, then d = (5 × 6) ÷ 2 = 15.',
  fields:[{k:'a',label:'a',t:'number',nonzero:true},{k:'b',label:'b',t:'number'},{k:'c',label:'c',t:'number'}],
  compute(i){
    const d = i.b * i.c / i.a;
    return { results:[
      {label:'Missing value d', value: fmt(d), hl:true},
      {label:'Check: a/b', value: fmt(i.a/i.b, 6)},
      {label:'Check: c/d', value: fmt(i.c/d, 6)}
    ]};
  }});

function listCalc(o){
  return defCalc(Object.assign({
    fields:[{k:'list',label:'Numbers (comma or space separated)',t:'list',placeholder:'e.g. 4, 8, 15, 16, 23, 42'}]
  }, o));
}
listCalc({ slug:'average-calculator', name:'Average Calculator', cat:['math','education','statistics'],
  desc:'Calculate the arithmetic mean (average) of any list of numbers.',
  kw:'average,mean,arithmetic mean,average of numbers',
  formula:'mean = (sum of all values) ÷ (count of values)',
  expl:'Enter your numbers separated by commas or spaces. The calculator returns the sum, the count and the average.',
  example:'The average of 10, 20 and 30 is (10+20+30)/3 = 20.',
  compute(i){
    const s = i.list.reduce((a,b)=>a+b,0);
    return { results:[
      {label:'Average (mean)', value: fmt(s / i.list.length), hl:true},
      {label:'Sum', value: fmt(s)},
      {label:'Count', value: fmt(i.list.length, 0)}
    ]};
  }});

listCalc({ slug:'mean-median-mode', name:'Mean Median Mode Calculator', cat:['math','statistics'],
  desc:'Find the mean, median, mode, range and other summary statistics of a dataset.',
  kw:'mean,median,mode,range,statistics,summary statistics',
  formula:'mean = Σx/n · median = middle value of sorted data · mode = most frequent value',
  expl:'Enter a list of numbers. The calculator sorts the data and reports the mean, median, mode (if one exists), range, minimum and maximum.',
  example:'For 1, 2, 2, 3: mean = 2, median = 2, mode = 2, range = 2.',
  compute(i){
    const a = i.list.slice().sort((x,y)=>x-y);
    const n = a.length, s = a.reduce((x,y)=>x+y,0);
    const mid = n % 2 ? a[(n-1)/2] : (a[n/2-1]+a[n/2])/2;
    const freq = {};
    a.forEach(x => freq[x] = (freq[x]||0)+1);
    const maxF = Math.max.apply(null, Object.keys(freq).map(k=>freq[k]));
    const modes = Object.keys(freq).filter(k=>freq[k]===maxF).map(Number).sort((x,y)=>x-y);
    return { results:[
      {label:'Mean', value: fmt(s/n), hl:true},
      {label:'Median', value: fmt(mid)},
      {label:'Mode', value: maxF > 1 ? modes.map(m=>fmt(m)).join(', ') : 'No mode (all values unique)'},
      {label:'Range', value: fmt(a[n-1]-a[0])},
      {label:'Minimum / Maximum', value: fmt(a[0]) + ' / ' + fmt(a[n-1])}
    ]};
  }});

defCalc({ slug:'exponent-calculator', name:'Exponent Calculator', cat:'math',
  desc:'Raise any number to any power, with support for negative exponents.',
  kw:'power,exponent,raised to,square,cube',
  formula:'base^exponent — a negative exponent means 1/(base^|exponent|)',
  expl:'Enter a base and an exponent. Very large results are shown in scientific notation.',
  example:'2^10 = 1024 and 10^-2 = 0.01.',
  fields:[{k:'base',label:'Base',t:'number'},{k:'exp',label:'Exponent',t:'number'}],
  compute(i){
    const r = Math.pow(i.base, i.exp);
    if (!isFinite(r)) throw new Error('Result is too large to represent.');
    return { results:[{label:'Result', value: fmt(r), hl:true},{label:'Base × exponent (for reference)', value: fmt(i.base * i.exp)}]};
  }});

defCalc({ slug:'square-root-calculator', name:'Square Root Calculator', cat:'math',
  desc:'Calculate square roots, cube roots and higher-order roots of a number.',
  kw:'square root,cube root,root,radical,sqrt',
  formula:'ⁿ√x = x^(1/n)',
  expl:'Enter a non-negative number and choose the root degree. You also get the square of the number for reference.',
  example:'√144 = 12 and ³√27 = 3.',
  fields:[{k:'x',label:'Number',t:'number',min:0},{k:'n',label:'Root degree',t:'number',def:2,min:2}],
  compute(i){
    const r = Math.pow(i.x, 1/i.n);
    return { results:[
      {label:i.n + 'th root', value: fmt(r), hl:true},
      {label:'Square of number', value: fmt(i.x*i.x)},
      {label:'Root × root degree', value: fmt(r*i.n)}
    ]};
  }});

defCalc({ slug:'logarithm-calculator', name:'Logarithm Calculator', cat:'math',
  desc:'Calculate logarithms of any base, plus natural log and log base 10.',
  kw:'logarithm,log,ln,log base,log calculator',
  formula:'log_b(x) = ln(x) ÷ ln(b)',
  expl:'Enter a positive number and a base. The base must be positive and not equal to 1.',
  example:'log₂(8) = 3 because 2³ = 8.',
  fields:[{k:'x',label:'Number (x)',t:'number',min:0,nonzero:true},{k:'b',label:'Base (b)',t:'number',def:10,min:0}],
  compute(i){
    if (i.b === 1) throw new Error('The base cannot be 1.');
    return { results:[
      {label:'log base ' + fmt(i.b,4), value: fmt(Math.log(i.x)/Math.log(i.b)), hl:true},
      {label:'Natural log (ln)', value: fmt(Math.log(i.x))},
      {label:'Log base 10', value: fmt(Math.log10(i.x))}
    ]};
  }});

defCalc({ slug:'quadratic-equation', name:'Quadratic Equation Calculator', cat:'math',
  desc:'Solve any quadratic equation ax² + bx + c = 0, including complex roots.',
  kw:'quadratic formula,solve equation,x squared,roots,discriminant',
  formula:'x = (−b ± √(b² − 4ac)) ÷ 2a',
  expl:'Enter the coefficients a, b and c. The discriminant b² − 4ac tells you how many real roots exist: positive means two, zero means one, negative means two complex roots.',
  example:'For x² − 5x + 6 = 0 the roots are x = 2 and x = 3.',
  fields:[{k:'a',label:'a (coefficient of x²)',t:'number',nonzero:true},{k:'b',label:'b (coefficient of x)',t:'number'},{k:'c',label:'c (constant)',t:'number'}],
  compute(i){
    const d = i.b*i.b - 4*i.a*i.c;
    const out = [{label:'Discriminant (b² − 4ac)', value: fmt(d)}];
    if (d > 0){
      const r1 = (-i.b + Math.sqrt(d))/(2*i.a), r2 = (-i.b - Math.sqrt(d))/(2*i.a);
      out.push({label:'Root 1 (x₁)', value: fmt(r1), hl:true},{label:'Root 2 (x₂)', value: fmt(r2), hl:true});
    } else if (d === 0){
      out.push({label:'Double root (x)', value: fmt(-i.b/(2*i.a)), hl:true});
    } else {
      const re = -i.b/(2*i.a), im = Math.sqrt(-d)/(2*i.a);
      out.push({label:'Complex root 1', value: fmt(re) + ' + ' + fmt(im) + 'i', hl:true});
      out.push({label:'Complex root 2', value: fmt(re) + ' − ' + fmt(im) + 'i', hl:true});
    }
    const vx = -i.b/(2*i.a), vy = i.a*vx*vx + i.b*vx + i.c;
    out.push({label:'Vertex (x, y)', value: fmt(vx) + ', ' + fmt(vy)});
    return { results: out };
  }});

defCalc({ slug:'random-number-generator', name:'Random Number Generator', cat:'math',
  desc:'Generate one or more random integers within any range you choose.',
  kw:'random number,random integer,rng,random picker',
  formula:'cryptographically secure integers uniformly distributed between min and max',
  expl:'Enter the minimum, maximum and how many numbers you need. Numbers are generated using your browser\'s cryptographic random source.',
  example:'Generating 5 numbers between 1 and 100 might give 42, 7, 89, 13, 66.',
  fields:[{k:'min',label:'Minimum',t:'number',def:1},{k:'max',label:'Maximum',t:'number',def:100},{k:'count',label:'How many numbers',t:'number',def:1,min:1}],
  compute(i){
    if (i.max < i.min) throw new Error('Maximum must be greater than or equal to the minimum.');
    if (i.count > 1000) throw new Error('Please generate at most 1,000 numbers at once.');
    const lo = Math.ceil(i.min), hi = Math.floor(i.max);
    if (hi < lo) throw new Error('The range contains no integers.');
    const buf = new Uint32Array(i.count);
    crypto.getRandomValues(buf);
    const range = hi - lo + 1;
    const nums = Array.from(buf, x => lo + (x % range));
    return { results:[
      {label:'Random number' + (i.count > 1 ? 's' : ''), value: nums.join(', '), hl:true},
      {label:'Range used', value: lo + ' to ' + hi}
    ]};
  }});

defCalc({ slug:'prime-number', name:'Prime Number Calculator', cat:'math',
  desc:'Check whether a number is prime, find its factors, and locate the nearest primes.',
  kw:'prime,prime number,is prime,factors,prime check',
  formula:'trial division up to √n',
  expl:'Enter a whole number. The calculator tests primality, lists all factors and finds the closest primes below and above.',
  example:'29 is prime. Its only factors are 1 and 29.',
  fields:[{k:'n',label:'Number',t:'number',min:0}],
  compute(i){
    let n = Math.round(i.n);
    if (n > 1e12) throw new Error('Please enter a number up to 1,000,000,000,000.');
    const isP = n => { if (n < 2) return false; if (n % 2 === 0) return n === 2; for (let d = 3; d*d <= n; d += 2) if (n % d === 0) return false; return true; };
    const factors = [];
    for (let d = 1; d*d <= n; d++) if (n % d === 0){ factors.push(d); if (d !== n/d) factors.push(n/d); }
    factors.sort((a,b)=>a-b);
    let below = null, above = null;
    if (n > 2){ for (let m = Math.max(2, n-1); m >= 2; m--){ if (isP(m)){ below = m; break; } } }
    for (let m = Math.max(2, n+1); ; m++){ if (isP(m)){ above = m; break; } if (m > n + 10000) break; }
    return { results:[
      {label:'Is prime?', value: isP(n) ? 'Yes' : 'No', hl:true},
      {label:'All factors', value: factors.join(', ')},
      {label:'Previous prime', value: below === null ? 'None' : fmt(below)},
      {label:'Next prime', value: above === null ? '—' : fmt(above)}
    ]};
  }});

defCalc({ slug:'gcf-calculator', name:'GCF Calculator', cat:'math',
  desc:'Find the greatest common factor (GCD) of two or more numbers.',
  kw:'gcf,gcd,greatest common factor,greatest common divisor',
  formula:'Euclidean algorithm applied iteratively to the list',
  expl:'Enter two or more whole numbers separated by commas or spaces.',
  example:'GCF of 12 and 18 is 6.',
  fields:[{k:'list',label:'Numbers (comma or space separated)',t:'list'}],
  compute(i){
    const g = gcdList(i.list.map(Math.round));
    return { results:[{label:'Greatest common factor', value: fmt(g), hl:true},{label:'Count of numbers', value: fmt(i.list.length,0)}]};
  }});

defCalc({ slug:'lcm-calculator', name:'LCM Calculator', cat:'math',
  desc:'Find the least common multiple of two or more numbers.',
  kw:'lcm,least common multiple,lowest common multiple',
  formula:'LCM(a,b) = |a × b| ÷ GCF(a,b), applied iteratively',
  expl:'Enter two or more whole numbers separated by commas or spaces.',
  example:'LCM of 4 and 6 is 12.',
  fields:[{k:'list',label:'Numbers (comma or space separated)',t:'list'}],
  compute(i){
    const l = lcmList(i.list.map(Math.round));
    return { results:[{label:'Least common multiple', value: fmt(l), hl:true}]};
  }});

defCalc({ slug:'factorial-calculator', name:'Factorial Calculator', cat:'math',
  desc:'Calculate n! (factorial) and count its digits.',
  kw:'factorial,n!,factorial calculator,permutation count',
  formula:'n! = n × (n−1) × … × 2 × 1',
  expl:'Enter a non-negative whole number up to 170. Larger factorials exceed the range of standard numbers.',
  example:'5! = 5 × 4 × 3 × 2 × 1 = 120.',
  fields:[{k:'n',label:'n',t:'number',min:0}],
  compute(i){
    const r = factorial(i.n);
    return { results:[
      {label:i.n + '!', value: r.toLocaleString(), hl:true},
      {label:'Number of digits', value: String(r).length}
    ]};
  }});

/* ---------- geometry ---------- */
const SHAPES_2D = {
  square:    { l:'Square',     fields:['side'],            area: i => i.side*i.side,              peri: i => 4*i.side },
  rectangle: { l:'Rectangle',  fields:['len','wid'],       area: i => i.len*i.wid,                peri: i => 2*(i.len+i.wid) },
  circle:    { l:'Circle',     fields:['radius'],          area: i => Math.PI*i.radius*i.radius,  peri: i => 2*Math.PI*i.radius },
  triangle:  { l:'Triangle (base & height)', fields:['base','height'], area: i => i.base*i.height/2, peri: null },
  trapezoid: { l:'Trapezoid',  fields:['a','b','height'],  area: i => (i.a+i.b)/2*i.height,       peri: null }
};
defCalc({ slug:'area-calculator', name:'Area Calculator', cat:'math',
  desc:'Calculate the area of squares, rectangles, circles, triangles and trapezoids.',
  kw:'area,square area,circle area,triangle area,rectangle area',
  formula:'Depends on shape — e.g. circle: A = πr², triangle: A = ½ × base × height',
  expl:'Choose a shape and fill in its dimensions. Fields not used by the selected shape are ignored.',
  example:'A circle with radius 5 has an area of about 78.54 square units.',
  fields:[
    {k:'shape',label:'Shape',t:'select',def:'rectangle',opts:Object.keys(SHAPES_2D).map(k=>({v:k,l:SHAPES_2D[k].l}))},
    {k:'side',label:'Side length',t:'number',min:0,optional:true},
    {k:'len',label:'Length',t:'number',min:0,optional:true},
    {k:'wid',label:'Width',t:'number',min:0,optional:true},
    {k:'radius',label:'Radius',t:'number',min:0,optional:true},
    {k:'base',label:'Base',t:'number',min:0,optional:true},
    {k:'height',label:'Height',t:'number',min:0,optional:true},
    {k:'a',label:'Side a (parallel)',t:'number',min:0,optional:true},
    {k:'b',label:'Side b (parallel)',t:'number',min:0,optional:true}
  ],
  compute(i){
    const sh = SHAPES_2D[i.shape];
    for (const f of sh.fields) if (i[f] === null) throw new Error('Please fill in "' + sh.l + '" dimensions (missing: ' + f + ').');
    const out = [{label:'Area', value: fmt(sh.area(i)) + ' square units', hl:true}];
    if (sh.peri) out.push({label:'Perimeter', value: fmt(sh.peri(i)) + ' units'});
    return { results: out };
  }});

const SHAPES_3D = {
  cube:   { l:'Cube',             fields:['side'],                vol: i => Math.pow(i.side,3) },
  sphere: { l:'Sphere',           fields:['radius'],              vol: i => 4/3*Math.PI*Math.pow(i.radius,3) },
  cylinder:{l:'Cylinder',         fields:['radius','height'],     vol: i => Math.PI*i.radius*i.radius*i.height },
  cone:   { l:'Cone',             fields:['radius','height'],     vol: i => Math.PI*i.radius*i.radius*i.height/3 },
  prism:  { l:'Rectangular prism',fields:['len','wid','height'],  vol: i => i.len*i.wid*i.height }
};
defCalc({ slug:'volume-calculator', name:'Volume Calculator', cat:'math',
  desc:'Calculate the volume of cubes, spheres, cylinders, cones and rectangular prisms.',
  kw:'volume,sphere volume,cylinder volume,cube volume,cone volume',
  formula:'Depends on solid — e.g. sphere: V = 4/3 πr³, cylinder: V = πr²h',
  expl:'Choose a solid and fill in its dimensions. Unused fields are ignored.',
  example:'A sphere with radius 3 has a volume of about 113.1 cubic units.',
  fields:[
    {k:'shape',label:'Solid',t:'select',def:'cylinder',opts:Object.keys(SHAPES_3D).map(k=>({v:k,l:SHAPES_3D[k].l}))},
    {k:'side',label:'Side length',t:'number',min:0,optional:true},
    {k:'radius',label:'Radius',t:'number',min:0,optional:true},
    {k:'len',label:'Length',t:'number',min:0,optional:true},
    {k:'wid',label:'Width',t:'number',min:0,optional:true},
    {k:'height',label:'Height',t:'number',min:0,optional:true}
  ],
  compute(i){
    const sh = SHAPES_3D[i.shape];
    for (const f of sh.fields) if (i[f] === null) throw new Error('Please fill in "' + sh.l + '" dimensions (missing: ' + f + ').');
    return { results:[{label:'Volume', value: fmt(sh.vol(i)) + ' cubic units', hl:true}] };
  }});

defCalc({ slug:'perimeter-calculator', name:'Perimeter Calculator', cat:'math',
  desc:'Calculate the perimeter of squares, rectangles, circles (circumference) and triangles.',
  kw:'perimeter,circumference,rectangle perimeter,triangle perimeter',
  formula:'Sum of all side lengths; circle: C = 2πr',
  expl:'Choose a shape and enter its side lengths. For circles, enter the radius.',
  example:'A rectangle 10 by 4 has a perimeter of 2 × (10 + 4) = 28.',
  fields:[
    {k:'shape',label:'Shape',t:'select',def:'rectangle',opts:[{v:'square',l:'Square'},{v:'rectangle',l:'Rectangle'},{v:'circle',l:'Circle (circumference)'},{v:'triangle',l:'Triangle (3 sides)'}]},
    {k:'side',label:'Side length',t:'number',min:0,optional:true},
    {k:'len',label:'Length',t:'number',min:0,optional:true},
    {k:'wid',label:'Width',t:'number',min:0,optional:true},
    {k:'radius',label:'Radius',t:'number',min:0,optional:true},
    {k:'s1',label:'Side 1',t:'number',min:0,optional:true},
    {k:'s2',label:'Side 2',t:'number',min:0,optional:true},
    {k:'s3',label:'Side 3',t:'number',min:0,optional:true}
  ],
  compute(i){
    let p;
    if (i.shape === 'square'){ if(i.side===null) throw new Error('Please enter the side length.'); p = 4*i.side; }
    else if (i.shape === 'rectangle'){ if(i.len===null||i.wid===null) throw new Error('Please enter length and width.'); p = 2*(i.len+i.wid); }
    else if (i.shape === 'circle'){ if(i.radius===null) throw new Error('Please enter the radius.'); p = 2*Math.PI*i.radius; }
    else { if(i.s1===null||i.s2===null||i.s3===null) throw new Error('Please enter all three sides.'); p = i.s1+i.s2+i.s3; }
    return { results:[{label:i.shape==='circle'?'Circumference':'Perimeter', value: fmt(p) + ' units', hl:true}] };
  }});

defCalc({ slug:'triangle-calculator', name:'Triangle Calculator', cat:'math',
  desc:'Solve a triangle from its three sides: area (Heron), perimeter and all angles.',
  kw:'triangle,heron,angles of triangle,scalene triangle,law of cosines',
  formula:'Area = √(s(s−a)(s−b)(s−c)) with s = (a+b+c)/2 · angles via the law of cosines',
  expl:'Enter the lengths of the three sides. The calculator verifies the triangle inequality, computes the area using Heron\'s formula, and finds each angle with the law of cosines.',
  example:'Sides 3, 4, 5 give an area of 6 and angles of about 36.87°, 53.13° and 90°.',
  fields:[{k:'a',label:'Side a',t:'number',min:0,nonzero:true},{k:'b',label:'Side b',t:'number',min:0,nonzero:true},{k:'c',label:'Side c',t:'number',min:0,nonzero:true}],
  compute(i){
    const {a,b,c} = i;
    if (a + b <= c || a + c <= b || b + c <= a) throw new Error('These sides cannot form a triangle (triangle inequality).');
    const s = (a+b+c)/2;
    const area = Math.sqrt(s*(s-a)*(s-b)*(s-c));
    const ang = (x,y,z) => Math.acos((y*y+z*z-x*x)/(2*y*z)) * 180/Math.PI;
    return { results:[
      {label:'Area', value: fmt(area) + ' square units', hl:true},
      {label:'Perimeter', value: fmt(a+b+c) + ' units'},
      {label:'Angle A', value: fmt(ang(a,b,c)) + '°'},
      {label:'Angle B', value: fmt(ang(b,a,c)) + '°'},
      {label:'Angle C', value: fmt(ang(c,a,b)) + '°'}
    ]};
  }});

defCalc({ slug:'circle-calculator', name:'Circle Calculator', cat:'math',
  desc:'Calculate circle area, circumference and diameter from the radius.',
  kw:'circle,circumference,area of circle,diameter,radius',
  formula:'A = πr² · C = 2πr · d = 2r',
  expl:'Enter the radius of the circle to get its area, circumference and diameter.',
  example:'A radius of 7 gives an area of about 153.94 and a circumference of about 43.98.',
  fields:[{k:'r',label:'Radius',t:'number',min:0,nonzero:true}],
  compute(i){
    return { results:[
      {label:'Area', value: fmt(Math.PI*i.r*i.r) + ' square units', hl:true},
      {label:'Circumference', value: fmt(2*Math.PI*i.r) + ' units'},
      {label:'Diameter', value: fmt(2*i.r) + ' units'}
    ]};
  }});

defCalc({ slug:'pythagorean-theorem', name:'Pythagorean Theorem Calculator', cat:'math',
  desc:'Find the hypotenuse or a missing leg of a right triangle.',
  kw:'pythagorean,hypotenuse,right triangle,a squared plus b squared',
  formula:'c = √(a² + b²)',
  expl:'Enter the two legs (a and b) of a right triangle to find the hypotenuse c.',
  example:'Legs of 3 and 4 give a hypotenuse of 5.',
  fields:[{k:'a',label:'Leg a',t:'number',min:0,nonzero:true},{k:'b',label:'Leg b',t:'number',min:0,nonzero:true}],
  compute(i){
    const c = Math.sqrt(i.a*i.a + i.b*i.b);
    return { results:[
      {label:'Hypotenuse (c)', value: fmt(c) + ' units', hl:true},
      {label:'Perimeter', value: fmt(i.a + i.b + c) + ' units'},
      {label:'Area', value: fmt(i.a*i.b/2) + ' square units'}
    ]};
  }});
