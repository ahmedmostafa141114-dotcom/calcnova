/* ============ CalcNova — Financial calculators (non-interest / Sharia-aware edition) ============ */
'use strict';

/* ---------- shared helpers (also used by calcs-rest.js real-estate tools — do not remove) ---------- */
function pmt(principal, monthlyRate, n){
  if (monthlyRate === 0) return principal / n;
  return principal * monthlyRate / (1 - Math.pow(1 + monthlyRate, -n));
}
function monthsFromYears(y){ return Math.round(y * 12); }
const F_DISCLAIMER = 'This calculator provides estimates for informational purposes only and is not personalized financial advice. Actual rates, fees and terms vary by lender.';

/* ---------- zakat helpers ---------- */
function zakatCore(totalAssets, deductions, pricePerGram, weightGrams, ratePct){
  const eligible = Math.max(0, totalAssets - (deductions || 0));
  const nisab = Math.max(0, pricePerGram) * Math.max(0, weightGrams);
  const met = eligible >= nisab && nisab > 0;
  return { eligible: eligible, nisab: nisab, met: met, zakat: met ? eligible * ratePct / 100 : 0 };
}
var ZAKAT_NOTE = 'Zakat calculations can involve scholarly differences regarding assets, deductions, nisab and timing. Verify important religious decisions with a qualified scholar.';
var ISLAMIC_NOTE = 'CalcNova provides mathematical and educational tools. Islamic finance details can vary by contract, circumstances, scholarly interpretation and jurisdiction. This calculator is not a fatwa, legal opinion, or personalized religious advice.';
var NISAB_FIELDS = [
  { k:'basis', label:'Nisab basis', t:'select', def:'gold', opts:[
    { v:'gold', l:'Gold basis (default weight ≈85 g — adjust below)' },
    { v:'silver', l:'Silver basis (default weight ≈595 g — adjust below)' } ] },
  { k:'price', label:'Current price per gram of the nisab metal', t:'number', min:0, hint:'enter today\'s local price' },
  { k:'weight', label:'Nisab weight (grams)', t:'number', def:85, min:0, hint:'≈85 g gold / ≈595 g silver — adjust per your methodology' },
  { k:'rate', label:'Zakat rate (%)', t:'number', def:2.5, min:0, max:100, hint:'default assumption, not a universal ruling' }
];
function zakatRows(z){
  return [
    { label:'Eligible amount after deductions', value: fmtMoney(z.eligible) },
    { label:'Nisab threshold', value: fmtMoney(z.nisab) },
    { label:'Nisab threshold reached?', value: z.met ? 'Yes' : 'No' },
    { label:'Estimated zakat (selected inputs & methodology)', value: fmtMoney(z.zakat), hl:true }
  ];
}
function zakatFAQ(name){
  return [
    { q:'Is this ' + name + ' a religious ruling?', a:'No. CalcNova provides mathematical and educational tools only. This is not a fatwa or individualized religious advice — verify important religious decisions with a qualified scholar.' },
    { q:'Why do I enter the gold or silver price myself?', a:'Gold and silver prices change daily and vary by market. The calculator never hard-codes prices, so your estimate always reflects the current values you enter.' },
    { q:'Do scholars agree on the nisab and deductions?', a:'Nisab methodologies and eligible deductions can differ between scholarly opinions. Use the basis, weight and rate settings that match the methodology you follow.' }
  ];
}

/* ---------- contribution-only savings tools (no interest, no returns) ---------- */
defCalc({ slug:'savings-calculator', name:'Savings Goal Calculator', cat:'finance',
  desc:'Plan a savings goal with contributions only — no interest or investment returns assumed.',
  kw:'savings goal calculator,save money plan,monthly contribution,target savings,no interest',
  formula:'Months needed = remaining amount ÷ monthly contribution',
  expl:'Enter your target, what you have already saved, and a monthly contribution. The calculator shows how long it will take, or what monthly amount is needed for a chosen time frame. It deliberately applies no interest rate, return or growth assumption.',
  example:'Goal $10,000 with $1,000 saved and $300/month: 30 months needed.',
  fields:[
    {k:'target',label:'Target amount ($)',t:'number',min:0,def:10000},
    {k:'cur',label:'Current amount saved ($)',t:'number',min:0,def:1000},
    {k:'pmt',label:'Monthly contribution ($)',t:'number',min:0,def:300},
    {k:'months',label:'Target time frame (months, optional)',t:'number',min:0,optional:true}
  ],
  compute(i){
    const remaining = Math.max(0, i.target - i.cur);
    const rows = [ {label:'Remaining amount', value: fmtMoney(remaining)} ];
    if (i.pmt > 0) rows.push({label:'Months needed at current contribution', value: remaining ? fmt(Math.ceil(remaining / i.pmt), 0) : '0', hl:true});
    if (i.months > 0) rows.push({label:'Required monthly contribution', value: fmtMoney(remaining / i.months), hl:true});
    if (!i.pmt && !i.months) throw new Error('Enter a monthly contribution or a target time frame (months).');
    return { results: rows, note:'Contribution-based planning only — no interest or investment returns are included.' };
  },
  faq:[
    { q:'Does this savings calculator use interest?', a:'No. It is a contribution-only planner. No interest rate or investment return is applied — only your own deposits count toward the goal.' },
    { q:'How is "months needed" calculated?', a:'Months needed = (target − current savings) ÷ monthly contribution, rounded up to the next whole month.' }
  ]});

defCalc({ slug:'retirement-calculator', name:'Retirement Savings Goal Calculator', cat:'finance',
  desc:'Check a retirement fund goal using current savings and monthly contributions only.',
  kw:'retirement savings goal,pension fund plan,retirement contributions calculator',
  formula:'Projected total = current savings + (monthly contribution × 12 × years)',
  expl:'Enter your current savings, the fund you want at retirement, your monthly contribution and the years remaining. The result is based only on contributions and targets — no investment return or interest is assumed.',
  example:'$20,000 saved, $500/month for 25 years → projected $170,000.',
  fields:[
    {k:'cur',label:'Current savings ($)',t:'number',min:0,def:20000},
    {k:'goal',label:'Desired retirement fund ($)',t:'number',min:0,def:300000},
    {k:'pmt',label:'Monthly contribution ($)',t:'number',min:0,def:500},
    {k:'years',label:'Years remaining',t:'number',min:0,def:25}
  ],
  compute(i){
    const contrib = i.pmt * 12 * i.years;
    const proj = i.cur + contrib;
    const gap = i.goal - proj;
    return { results:[
      {label:'Total contributions over ' + i.years + ' years', value: fmtMoney(contrib)},
      {label:'Projected total (no growth assumed)', value: fmtMoney(proj), hl:true},
      {label: gap > 0 ? 'Shortfall vs goal' : 'Surplus vs goal', value: fmtMoney(Math.abs(gap))}
    ], note:'Based only on your contributions and targets — no investment return or interest is assumed.' };
  },
  faq:[
    { q:'Does this calculator assume investment growth?', a:'No. It intentionally uses contributions only, so you can see the raw savings effort required for your goal.' },
    { q:'Is this personalized financial advice?', a:'No. It is an educational mathematical tool. For retirement planning decisions, consult a qualified financial professional.' }
  ]});

defCalc({ slug:'401k-calculator', name:'Long-Term Savings Planner', cat:'finance',
  desc:'A generic long-term savings planner based on regular contributions. No interest or return math.',
  kw:'long term savings planner,regular contribution plan,debt free saving',
  formula:'Ending amount = current savings + (monthly contribution × 12 × years)',
  expl:'Enter what you have saved, what you can contribute each month, and for how long. The planner totals your contributions — it applies no interest rate or investment return and does not promote any financial product.',
  example:'$5,000 saved plus $400/month for 20 years → $101,000.',
  fields:[
    {k:'cur',label:'Current savings ($)',t:'number',min:0,def:5000},
    {k:'pmt',label:'Monthly contribution ($)',t:'number',min:0,def:400},
    {k:'years',label:'Years',t:'number',min:0,def:20}
  ],
  compute(i){
    const contrib = i.pmt * 12 * i.years;
    return { results:[
      {label:'Total you contribute', value: fmtMoney(contrib)},
      {label:'Ending amount (contributions only)', value: fmtMoney(i.cur + contrib), hl:true}
    ], note:'A generic contribution planner — no interest rate or investment return is applied.' };
  },
  faq:[
    { q:'Is this tied to a specific retirement account?', a:'No. It is a generic long-term savings planner and does not promote or model any specific financial product.' },
    { q:'Are returns included?', a:'No. Only your own contributions are counted, so the result is a conservative baseline.' }
  ]});

defCalc({ slug:'investment-calculator', name:'Halal Business Profit Planning Calculator', cat:['finance','business'],
  desc:'Plan business profit from cost and expected revenue — educational, Sharia-aware trade arithmetic.',
  kw:'halal business profit planning,islamic trade profit calculator,business revenue cost',
  formula:'Profit = revenue − cost · Margin = profit ÷ revenue × 100',
  expl:'Enter the total cost of a business venture and the revenue you expect from trade. The tool shows profit, margin and markup. It involves no loan or interest calculation.',
  note:'This calculator does not certify that any business or transaction is halal, and it does not guarantee investment returns. ' + ISLAMIC_NOTE,
  example:'Cost $5,000 and expected revenue $7,000 → profit $2,000, margin 28.6%.',
  fields:[
    {k:'cost',label:'Total cost ($)',t:'number',min:0,def:5000},
    {k:'rev',label:'Expected revenue ($)',t:'number',min:0,def:7000}
  ],
  compute(i){
    const profit = i.rev - i.cost;
    return { results:[
      {label:'Profit', value: fmtMoney(profit), hl:true},
      {label:'Profit margin', value: fmt(i.rev ? profit / i.rev * 100 : 0) + '%'},
      {label:'Markup', value: fmt(i.cost ? profit / i.cost * 100 : 0) + '%'}
    ] };
  },
  faq:[
    { q:'Does this calculator guarantee halal returns?', a:'No. It performs simple profit arithmetic on cost and revenue. It does not certify any investment as halal and does not guarantee returns of any kind.' },
    { q:'What does "Sharia-aware" mean here?', a:'It means the tool is designed to avoid conventional interest calculations. It is an educational calculator, not a religious certification.' }
  ]});

/* ---------- zakat & Sharia-aware tools (educational mathematical calculators) ---------- */
defCalc({ slug:'zakat-calculator', name:'Zakat Calculator', cat:'finance',
  desc:'Estimate zakat on cash, gold, silver and eligible business assets with a configurable nisab and rate.',
  kw:'zakat calculator,zakat calculator online,nisab calculator,zakat on savings and gold',
  expl:'Enter the current value of each asset type, any deductions your methodology allows, and your nisab settings. The tool compares your eligible amount against the nisab threshold and applies the configurable rate. Gold and silver prices must be entered manually because they change daily.',
  note: ZAKAT_NOTE + ' ' + ISLAMIC_NOTE,
  related:['nisab-calculator','zakat-gold-calculator','cash-zakat-calculator','business-zakat-calculator','zakat-fitrah-calculator','charity-calculator'],
  faq: zakatFAQ('zakat calculator'),
  fields:[
    {k:'cash',label:'Cash in hand ($)',t:'number',min:0,optional:true},
    {k:'bank',label:'Bank / savings balance ($)',t:'number',min:0,optional:true},
    {k:'gold',label:'Gold value at current price ($)',t:'number',min:0,optional:true,hint:'enter current market value yourself'},
    {k:'silver',label:'Silver value at current price ($)',t:'number',min:0,optional:true},
    {k:'biz',label:'Business inventory / eligible business assets ($)',t:'number',min:0,optional:true},
    {k:'other',label:'Other eligible zakatable assets ($)',t:'number',min:0,optional:true},
    {k:'ded',label:'Applicable deductions / liabilities ($)',t:'number',min:0,optional:true,hint:'only where your methodology allows'}
  ].concat(NISAB_FIELDS),
  compute(i){
    const assets = (i.cash||0) + (i.bank||0) + (i.gold||0) + (i.silver||0) + (i.biz||0) + (i.other||0);
    if (assets === 0 && !(i.ded||0)) throw new Error('Please enter at least one asset value.');
    const z = zakatCore(assets, i.ded||0, i.price||0, i.weight, i.rate);
    return { results:[ {label:'Total entered assets', value: fmtMoney(assets)} ].concat(zakatRows(z)),
      note:'Estimated zakat based on the selected inputs and methodology. ' + ZAKAT_NOTE };
  }});

defCalc({ slug:'zakat-gold-calculator', name:'Gold Zakat Calculator', cat:'finance',
  desc:'Estimate zakat on gold using weight, purity and the current price per gram you enter.',
  kw:'gold zakat calculator,zakat on gold grams,gold nisab calculator',
  expl:'Enter the gold weight, its purity, and today\'s price per gram. Fine gold value = weight × purity × price. The tool compares the total against your chosen nisab method and applies the configurable rate.',
  note: ZAKAT_NOTE + ' ' + ISLAMIC_NOTE,
  related:['zakat-calculator','zakat-silver-calculator','nisab-calculator'],
  faq: zakatFAQ('gold zakat calculator'),
  fields:[
    {k:'w',label:'Gold weight (grams)',t:'number',min:0,def:100},
    {k:'purity',label:'Purity (% gold content)',t:'number',min:0,max:100,def:99.9,hint:'24k ≈ 99.9%, 22k ≈ 91.7%, 18k ≈ 75%'},
    {k:'price',label:'Current gold price per gram ($)',t:'number',min:0,hint:'enter today\'s local price'},
    {k:'other',label:'Other zakatable gold value ($)',t:'number',min:0,optional:true},
    {k:'basis',label:'Nisab method',t:'select',def:'gold',opts:[
      {v:'gold',l:'Gold nisab (default 85 g at gold price)'},
      {v:'silver',l:'Silver nisab (default 595 g at silver price)'}]},
    {k:'silverPrice',label:'Current silver price per gram (for silver nisab)',t:'number',min:0,optional:true},
    {k:'nw',label:'Nisab weight (grams)',t:'number',def:85,min:0},
    {k:'rate',label:'Zakat rate (%)',t:'number',def:2.5,min:0,max:100,hint:'default assumption'}
  ],
  compute(i){
    const fineValue = i.w * (i.purity/100) * i.price;
    const zakatable = fineValue + (i.other||0);
    const nisabPrice = i.basis === 'silver' ? (i.silverPrice||0) : i.price;
    const z = zakatCore(zakatable, 0, nisabPrice, i.nw, i.rate);
    return { results:[
      {label:'Calculated gold value', value: fmtMoney(fineValue)},
      {label:'Total zakatable gold value', value: fmtMoney(zakatable)}
    ].concat(zakatRows(z)), note:'Estimated zakat based on the selected inputs and methodology. ' + ZAKAT_NOTE };
  }});

defCalc({ slug:'zakat-silver-calculator', name:'Silver Zakat Calculator', cat:'finance',
  desc:'Estimate zakat on silver using weight, purity and the current price you enter.',
  kw:'silver zakat calculator,zakat on silver grams,silver nisab calculator',
  expl:'Enter the silver weight, its purity, and today\'s price per gram. The tool compares the fine silver value against your chosen nisab method and applies the configurable rate.',
  note: ZAKAT_NOTE + ' ' + ISLAMIC_NOTE,
  related:['zakat-calculator','zakat-gold-calculator','nisab-calculator'],
  faq: zakatFAQ('silver zakat calculator'),
  fields:[
    {k:'w',label:'Silver weight (grams)',t:'number',min:0,def:500},
    {k:'purity',label:'Purity (% silver content)',t:'number',min:0,max:100,def:99.9},
    {k:'price',label:'Current silver price per gram ($)',t:'number',min:0,hint:'enter today\'s local price'},
    {k:'basis',label:'Nisab method',t:'select',def:'silver',opts:[
      {v:'silver',l:'Silver nisab (default 595 g at silver price)'},
      {v:'gold',l:'Gold nisab (default 85 g at gold price)'}]},
    {k:'goldPrice',label:'Current gold price per gram (for gold nisab)',t:'number',min:0,optional:true},
    {k:'nw',label:'Nisab weight (grams)',t:'number',def:595,min:0},
    {k:'rate',label:'Zakat rate (%)',t:'number',def:2.5,min:0,max:100,hint:'default assumption'}
  ],
  compute(i){
    const fineValue = i.w * (i.purity/100) * i.price;
    const nisabPrice = i.basis === 'gold' ? (i.goldPrice||0) : i.price;
    const z = zakatCore(fineValue, 0, nisabPrice, i.nw, i.rate);
    return { results:[
      {label:'Calculated silver value', value: fmtMoney(fineValue)}
    ].concat(zakatRows(z)), note:'Estimated zakat based on the selected inputs and methodology. ' + ZAKAT_NOTE };
  }});

defCalc({ slug:'cash-zakat-calculator', name:'Cash & Savings Zakat Calculator', cat:'finance',
  desc:'Estimate zakat on cash, bank balances, savings and other monetary holdings.',
  kw:'cash zakat calculator,zakat on savings,savings zakat calculator,money zakat',
  expl:'Enter your cash, bank balances, savings and other eligible monetary holdings, minus any deductions your methodology allows, and compare against your nisab settings.',
  note: ZAKAT_NOTE + ' ' + ISLAMIC_NOTE,
  related:['zakat-calculator','business-zakat-calculator','nisab-calculator'],
  faq: zakatFAQ('cash zakat calculator'),
  fields:[
    {k:'cash',label:'Cash in hand ($)',t:'number',min:0,optional:true},
    {k:'bank',label:'Bank balance ($)',t:'number',min:0,optional:true},
    {k:'sav',label:'Savings ($)',t:'number',min:0,optional:true},
    {k:'other',label:'Other eligible monetary holdings ($)',t:'number',min:0,optional:true},
    {k:'ded',label:'Deductions (where applicable)',t:'number',min:0,optional:true}
  ].concat(NISAB_FIELDS),
  compute(i){
    const assets = (i.cash||0) + (i.bank||0) + (i.sav||0) + (i.other||0);
    if (!assets) throw new Error('Please enter at least one monetary value.');
    const z = zakatCore(assets, i.ded||0, i.price||0, i.weight, i.rate);
    return { results: zakatRows(z), note:'Estimated zakat based on the selected inputs and methodology. ' + ZAKAT_NOTE };
  }});

defCalc({ slug:'business-zakat-calculator', name:'Business Zakat Calculator', cat:['finance','business'],
  desc:'Estimate zakat on business cash, inventory and eligible assets minus allowed liabilities.',
  kw:'business zakat calculator,zakat on inventory,trade zakat calculator',
  expl:'Enter business cash, goods held for sale, eligible receivables and other eligible assets, minus liabilities your methodology allows. The treatment of receivables and liabilities varies between methodologies.',
  note: ZAKAT_NOTE + ' ' + ISLAMIC_NOTE,
  related:['zakat-calculator','cash-zakat-calculator','halal-profit-margin-calculator'],
  faq: zakatFAQ('business zakat calculator'),
  fields:[
    {k:'cash',label:'Business cash ($)',t:'number',min:0,optional:true},
    {k:'inv',label:'Inventory / goods held for sale ($)',t:'number',min:0,optional:true},
    {k:'rec',label:'Eligible receivables (where applicable)',t:'number',min:0,optional:true},
    {k:'other',label:'Other eligible business assets ($)',t:'number',min:0,optional:true},
    {k:'liab',label:'Applicable liabilities / deductions ($)',t:'number',min:0,optional:true}
  ].concat(NISAB_FIELDS),
  compute(i){
    const assets = (i.cash||0) + (i.inv||0) + (i.rec||0) + (i.other||0);
    if (!assets) throw new Error('Please enter at least one business asset value.');
    const z = zakatCore(assets, i.liab||0, i.price||0, i.weight, i.rate);
    return { results:[ {label:'Estimated zakatable business amount', value: fmtMoney(z.eligible)} ].concat(zakatRows(z).slice(1)),
      note:'Treatment of receivables and liabilities varies between methodologies. Estimated zakat based on the selected inputs and methodology. ' + ZAKAT_NOTE };
  }});

defCalc({ slug:'nisab-calculator', name:'Nisab Calculator', cat:'finance',
  desc:'Calculate the nisab threshold from a gold or silver basis, the current price you enter, and a reference weight.',
  kw:'nisab calculator,gold nisab,silver nisab,zakat minimum threshold',
  formula:'Nisab threshold = current price per gram × reference weight',
  expl:'Methodology: nisab threshold = current price per gram × reference weight for the selected basis. Commonly referenced weights are approximately 85 g for gold and 595 g for silver, but standards differ — adjust the weight to the methodology you follow and enter today\'s local price.',
  note:'Nisab standards and scholarly methodologies differ. ' + ZAKAT_NOTE + ' ' + ISLAMIC_NOTE,
  related:['zakat-calculator','zakat-gold-calculator','zakat-silver-calculator'],
  faq:[
    { q:'What is the nisab?', a:'The nisab is the minimum amount of wealth above which zakat becomes due. It is defined in terms of gold or silver weight, converted to money using current prices.' },
    { q:'Which weight should I use?', a:'Commonly referenced weights are about 85 g for gold and 595 g for silver, but scholarly methodologies differ. Enter the weight used by the methodology you follow.' }
  ],
  fields:[
    {k:'basis',label:'Basis',t:'select',def:'gold',opts:[
      {v:'gold',l:'Gold (default weight 85 g)'},
      {v:'silver',l:'Silver (default weight 595 g)'}]},
    {k:'price',label:'Current price per gram ($)',t:'number',min:0,hint:'enter today\'s local price'},
    {k:'weight',label:'Reference weight (grams)',t:'number',def:85,min:0},
    {k:'rate',label:'Zakat rate (%)',t:'number',def:2.5,min:0,max:100,hint:'default assumption'}
  ],
  compute(i){
    const nisab = i.price * i.weight;
    return { results:[
      {label:'Nisab basis used', value: i.basis === 'gold' ? 'Gold' : 'Silver'},
      {label:'Nisab threshold', value: fmtMoney(nisab), hl:true},
      {label:'Zakat on exactly the nisab amount', value: fmtMoney(nisab * i.rate / 100)}
    ], note:'Threshold = price per gram × reference weight. Keep the basis, weight and price consistent with the settings in your zakat calculation.' };
  }});

defCalc({ slug:'zakat-fitrah-calculator', name:'Zakat Fitrah Calculator', cat:'finance',
  desc:'Calculate the total fitrah amount for your household using your local per-person rate.',
  kw:'zakat fitrah calculator,fitr charity,ramadan zakat per person',
  formula:'Total = number of people × local amount per person',
  expl:'Zakat al-Fitr is a fixed per-person amount set locally, usually a staple food quantity or its cash value. Enter the number of people in your household and the local amount per person — no universal amount or currency is assumed.',
  note:'The per-person amount is set locally and varies by region and food prices. Verify the local rate with your local mosque or authority.',
  fields:[
    {k:'people',label:'Number of people',t:'number',min:1,def:4},
    {k:'amount',label:'Local amount per person ($)',t:'number',min:0,hint:'set locally — enter your local rate'}
  ],
  compute(i){
    return { results:[ {label:'Total fitrah amount', value: fmtMoney(i.people * i.amount), hl:true} ],
      note:'The per-person amount is set locally and varies — enter your local figure.' };
  },
  faq:[
    { q:'Is there a universal fitrah amount?', a:'No. The amount is defined locally (traditionally a staple food measure) and varies by region and prices. Enter the rate set in your locality.' },
    { q:'Who must pay fitrah?', a:'Common guidance is one payment per household member, due before the Eid prayer. Details can vary — confirm with a qualified scholar or local authority.' }
  ]});

defCalc({ slug:'charity-calculator', name:'Sadaqah / Charity Planner', cat:'finance',
  desc:'Plan voluntary charity (sadaqah) over months or a year. Not a zakat calculator.',
  kw:'charity calculator,sadaqah planner,donation planner,voluntary giving',
  formula:'Total = monthly amount × months (+ optional annual amount)',
  expl:'Enter a monthly giving amount and how many months you plan to give. Voluntary charity (sadaqah) is not the same as obligatory zakat — this planner tracks voluntary giving only.',
  note:'Voluntary charity (sadaqah) is not the same as obligatory zakat.',
  related:['zakat-calculator','zakat-fitrah-calculator','personal-budget-calculator'],
  fields:[
    {k:'monthly',label:'Monthly charity amount ($)',t:'number',min:0,def:50},
    {k:'months',label:'Number of months',t:'number',min:0,def:12},
    {k:'annual',label:'Additional annual amount (optional)',t:'number',min:0,optional:true}
  ],
  compute(i){
    const yearly = i.monthly * 12 + (i.annual||0);
    return { results:[
      {label:'Monthly amount', value: fmtMoney(i.monthly)},
      {label:'Total over ' + i.months + ' months', value: fmtMoney(i.monthly * i.months), hl:true},
      {label:'Annual total (incl. optional amount)', value: fmtMoney(yearly)}
    ], note:'Voluntary charity (sadaqah) is not the same as obligatory zakat.' };
  },
  faq:[
    { q:'Is sadaqah the same as zakat?', a:'No. Zakat is an obligatory payment on qualifying wealth; sadaqah is voluntary charity. This tool plans voluntary giving only.' },
    { q:'Is zakat calculated here?', a:'No — use the Zakat Calculator for obligatory zakat estimates.' }
  ]});

defCalc({ slug:'halal-profit-margin-calculator', name:'Halal Profit Margin Calculator', cat:['finance','business'],
  desc:'Profit, margin and markup from cost and selling price — simple trade arithmetic with no interest.',
  kw:'halal profit margin calculator,islamic trade pricing,profit margin no interest',
  formula:'Profit = selling price − cost · Margin = profit ÷ price × 100 · Markup = profit ÷ cost × 100',
  expl:'Enter your cost and selling price. The tool shows profit, profit margin and markup — ordinary trade arithmetic with no loan or interest element.',
  note:'"Sharia-aware" describes the calculator\'s design, not a certification of any transaction. ' + ISLAMIC_NOTE,
  related:['profit-margin-calculator','investment-calculator','business-zakat-calculator'],
  fields:[
    {k:'cost',label:'Cost ($)',t:'number',min:0,def:40},
    {k:'price',label:'Selling price ($)',t:'number',min:0,def:60}
  ],
  compute(i){
    const profit = i.price - i.cost;
    return { results:[
      {label:'Profit', value: fmtMoney(profit), hl:true},
      {label:'Profit margin', value: fmt(i.price ? profit / i.price * 100 : 0) + '%'},
      {label:'Markup', value: fmt(i.cost ? profit / i.cost * 100 : 0) + '%'}
    ], note:'Simple trade arithmetic — no loan or interest element is involved.' };
  },
  faq:[
    { q:'Is this a religious certification?', a:'No. "Sharia-aware" means the calculator avoids conventional interest calculations. It is an educational tool, not a certification of any transaction.' },
    { q:'What is the difference between margin and markup?', a:'Margin is profit as a share of the selling price; markup is profit as a share of cost. Both are shown.' }
  ]});

defCalc({ slug:'personal-budget-calculator', name:'Personal Budget Calculator', cat:'finance',
  desc:'Track income against housing, food, transport, family, bills, savings, charity and other expenses.',
  kw:'personal budget calculator,islamic budgeting calculator,household budget planner',
  formula:'Remaining = income − total expenses',
  expl:'Enter your monthly income and your expenses by category. The calculator shows total expenses, the remaining balance, and each category\'s share of income.',
  related:['savings-calculator','charity-calculator','net-worth-calculator'],
  fields:[
    {k:'income',label:'Monthly income ($)',t:'number',min:0,nonzero:true,def:3000},
    {k:'housing',label:'Housing ($)',t:'number',min:0,optional:true},
    {k:'food',label:'Food ($)',t:'number',min:0,optional:true},
    {k:'transport',label:'Transport ($)',t:'number',min:0,optional:true},
    {k:'education',label:'Education ($)',t:'number',min:0,optional:true},
    {k:'family',label:'Family ($)',t:'number',min:0,optional:true},
    {k:'bills',label:'Bills ($)',t:'number',min:0,optional:true},
    {k:'savings',label:'Savings ($)',t:'number',min:0,optional:true},
    {k:'charity',label:'Charity ($)',t:'number',min:0,optional:true},
    {k:'other',label:'Other expenses ($)',t:'number',min:0,optional:true}
  ],
  compute(i){
    const cats = [['Housing',i.housing],['Food',i.food],['Transport',i.transport],['Education',i.education],['Family',i.family],['Bills',i.bills],['Savings',i.savings],['Charity',i.charity],['Other',i.other]];
    const total = cats.reduce(function(s,c){ return s + (c[1]||0); }, 0);
    const remaining = i.income - total;
    const note = cats.filter(function(c){ return c[1]; }).map(function(c){ return c[0] + ': ' + fmt(c[1]/i.income*100) + '% of income'; }).join(' · ');
    return { results:[
      {label:'Total expenses', value: fmtMoney(total)},
      {label:'Remaining balance', value: fmtMoney(remaining), hl:true},
      {label:'Savings rate', value: fmt((i.savings||0)/i.income*100) + '%'}
    ], note: note || 'No expenses entered.' };
  },
  faq:[
    { q:'What if my expenses exceed my income?', a:'The remaining balance turns negative, showing the monthly shortfall you need to close by adjusting spending or income.' },
    { q:'Does the budget include charity and savings?', a:'Yes — savings and charity are their own categories, so you can plan them alongside essential expenses.' }
  ]});

defCalc({ slug:'debt-free-savings-goal-calculator', name:'Debt-Free Savings Goal Calculator', cat:'finance',
  desc:'Reach a savings target with plain contributions — no interest, no loan amortization.',
  kw:'debt free savings goal,savings without interest,contribution goal calculator',
  formula:'Months needed = (target − current) ÷ monthly amount',
  expl:'Enter your target, what you have, and a monthly amount. The calculator shows how many months it takes — or the monthly amount needed for a chosen time frame. Pure contribution math with no borrowing.',
  fields:[
    {k:'target',label:'Target amount ($)',t:'number',min:0,def:5000},
    {k:'cur',label:'Current amount ($)',t:'number',min:0,def:500},
    {k:'pmt',label:'Monthly amount ($)',t:'number',min:0,def:250},
    {k:'months',label:'Target time frame (months, optional)',t:'number',min:0,optional:true}
  ],
  compute(i){
    const remaining = Math.max(0, i.target - i.cur);
    const rows = [ {label:'Remaining amount', value: fmtMoney(remaining)} ];
    if (i.pmt > 0) rows.push({label:'Months needed', value: remaining ? fmt(Math.ceil(remaining / i.pmt), 0) : '0', hl:true});
    if (i.months > 0) rows.push({label:'Required monthly amount', value: fmtMoney(remaining / i.months), hl:true});
    if (!i.pmt && !i.months) throw new Error('Enter a monthly amount or a target time frame (months).');
    return { results: rows, note:'Pure contribution math — no interest, no borrowing, no amortization.' };
  },
  faq:[
    { q:'Does this use any interest calculation?', a:'No. It is contribution-only arithmetic: target minus current savings, divided by what you add each month.' },
    { q:'Can I plan backwards from a deadline?', a:'Yes — enter a target time frame in months and the calculator shows the monthly amount required.' }
  ]});

/* ---------- retained finance tools (neutral math, verified interest-free) ---------- */
defCalc({ slug:'roi-calculator', name:'ROI Calculator', cat:['business','investment','finance'],
  desc:'Calculate return on investment as a percentage and annualized.',
  kw:'ROI,return on investment,annualized return,profit percentage',
  formula:'ROI = ((final − initial) ÷ initial) × 100',
  note: F_DISCLAIMER,
  expl:'Enter the amount you invested and the amount you got back. ROI is total return; annualized ROI spreads it evenly across the holding period.',
  example:'Invest $1,000, get back $1,200 in 2 years: ROI = 20%, annualized ≈ 9.54%.',
  fields:[
    {k:'inv',label:'Amount invested ($)',t:'number',min:0,nonzero:true},
    {k:'fin',label:'Amount returned ($)',t:'number',min:0},
    {k:'years',label:'Holding period (years)',t:'number',min:0,optional:true,def:1}
  ],
  compute(i){
    const roi = (i.fin - i.inv)/i.inv*100;
    const out = [
      {label:'Net profit / loss', value: fmtMoney(i.fin - i.inv)},
      {label:'ROI', value: fmt(roi) + '%', hl:true}
    ];
    if (i.years && i.years > 0 && i.fin > 0){
      out.push({label:'Annualized ROI', value: fmt((Math.pow(i.fin/i.inv, 1/i.years) - 1)*100) + '%'});
    }
    return { results: out };
  }});

defCalc({ slug:'inflation-calculator', name:'Inflation Calculator', cat:'finance',
  desc:'See how inflation erodes purchasing power over time.',
  kw:'inflation,purchasing power,cost of living,real value',
  formula:'future cost = today\'s cost × (1 + inflation rate)^years',
  note: 'Estimates are based on a constant inflation rate assumption; actual inflation varies.',
  expl:'Enter an amount in today\'s money, an average annual inflation rate and a number of years to see what the same purchasing power will cost in the future.',
  example:'$100 today at 3% inflation for 20 years will buy what costs about $180.61 in 20 years.',
  fields:[
    {k:'amt',label:'Amount in today\'s dollars ($)',t:'number',min:0},
    {k:'r',label:'Annual inflation rate (%)',t:'number',min:0},
    {k:'t',label:'Years in the future',t:'number',min:0}
  ],
  compute(i){
    const fut = i.amt * Math.pow(1 + i.r/100, i.t);
    return { results:[
      {label:'Equivalent future cost', value: fmtMoney(fut), hl:true},
      {label:'Loss of purchasing power', value: fmt((1 - i.amt/fut)*100) + '%'}
    ]};
  }});

defCalc({ slug:'salary-calculator', name:'Salary Calculator', cat:'finance',
  desc:'Convert an hourly wage to annual, monthly and weekly salary.',
  kw:'hourly to annual,salary converter,wage,annual income',
  formula:'annual = hourly × hours per week × weeks per year',
  expl:'Enter your hourly rate, hours worked per week and weeks worked per year (52 for full-time with no unpaid leave).',
  example:'$25/hour × 40 hours × 52 weeks = $52,000 per year.',
  fields:[
    {k:'hr',label:'Hourly rate ($)',t:'number',min:0},
    {k:'hpw',label:'Hours per week',t:'number',min:0,max:100,def:40},
    {k:'wpy',label:'Weeks per year',t:'number',min:0,max:52,def:52}
  ],
  compute(i){
    const yr = i.hr*i.hpw*i.wpy;
    return { results:[
      {label:'Annual salary', value: fmtMoney(yr), hl:true},
      {label:'Monthly (÷ 12)', value: fmtMoney(yr/12)},
      {label:'Weekly', value: fmtMoney(yr/i.wpy)},
      {label:'Daily (8-hour day)', value: fmtMoney(i.hr*8)}
    ]};
  }});

defCalc({ slug:'hourly-to-salary', name:'Hourly to Salary Calculator', cat:'finance',
  desc:'Convert an annual salary to its hourly, daily, weekly and monthly equivalent.',
  kw:'salary to hourly,annual to hourly,per hour rate',
  formula:'hourly = annual ÷ (hours per week × weeks per year)',
  expl:'Enter your annual salary. The default assumes a 40-hour week and 52 paid weeks.',
  example:'$60,000 per year ≈ $28.85 per hour.',
  fields:[
    {k:'yr',label:'Annual salary ($)',t:'number',min:0},
    {k:'hpw',label:'Hours per week',t:'number',min:0,max:100,def:40},
    {k:'wpy',label:'Weeks per year',t:'number',min:0,max:52,def:52}
  ],
  compute(i){
    const hr = i.yr/(i.hpw*i.wpy);
    return { results:[
      {label:'Hourly rate', value: fmtMoney(hr), hl:true},
      {label:'Daily (8-hour day)', value: fmtMoney(hr*8)},
      {label:'Weekly', value: fmtMoney(i.yr/i.wpy)},
      {label:'Monthly (÷ 12)', value: fmtMoney(i.yr/12)}
    ]};
  }});

defCalc({ slug:'tip-calculator', name:'Tip Calculator', cat:'finance',
  desc:'Calculate the tip, total bill and per-person share for any group size.',
  kw:'tip,gratuity,restaurant bill,split bill',
  formula:'tip = bill × tip% · total = bill + tip · per person = total ÷ split',
  expl:'Enter the bill amount, tip percentage and how many people are splitting.',
  example:'A $80 bill with 18% tip split 2 ways: $14.40 tip, $94.40 total, $47.20 each.',
  fields:[
    {k:'bill',label:'Bill amount ($)',t:'number',min:0},
    {k:'tip',label:'Tip (%)',t:'number',min:0,max:100,def:18},
    {k:'split',label:'Split between how many people',t:'number',min:1,def:1}
  ],
  compute(i){
    const tip = i.bill*i.tip/100, total = i.bill + tip;
    return { results:[
      {label:'Tip amount', value: fmtMoney(tip)},
      {label:'Total with tip', value: fmtMoney(total), hl:true},
      {label:'Per person', value: fmtMoney(total/i.split), hl:true}
    ]};
  }});

defCalc({ slug:'discount-calculator', name:'Discount Calculator', cat:'finance',
  desc:'Find the sale price, amount saved and effective price after a percentage discount.',
  kw:'discount,sale price,percent off,save money',
  formula:'savings = price × discount% · final = price − savings',
  expl:'Enter the original price and the discount percentage.',
  example:'A $120 item at 25% off costs $90 — you save $30.',
  fields:[
    {k:'price',label:'Original price ($)',t:'number',min:0},
    {k:'disc',label:'Discount (%)',t:'number',min:0,max:100}
  ],
  compute(i){
    const save = i.price*i.disc/100;
    return { results:[
      {label:'You save', value: fmtMoney(save)},
      {label:'Final price', value: fmtMoney(i.price - save), hl:true}
    ]};
  }});

defCalc({ slug:'sales-tax-calculator', name:'Sales Tax Calculator', cat:'finance',
  desc:'Calculate sales tax and the total price including tax.',
  kw:'sales tax,tax rate,total with tax,pre tax',
  formula:'tax = price × rate% · total = price + tax',
  expl:'Enter the pre-tax price and the tax rate. Use "remove tax" mode to find the pre-tax price from a tax-inclusive total.',
  example:'$50 at 8.25% tax: $4.13 tax, $54.13 total.',
  fields:[
    {k:'price',label:'Price ($)',t:'number',min:0},
    {k:'rate',label:'Tax rate (%)',t:'number',min:0,max:100},
    {k:'mode',label:'Mode',t:'select',def:'add',opts:[{v:'add',l:'Add tax to price'},{v:'remove',l:'Remove tax from total'}]}
  ],
  compute(i){
    if (i.mode === 'add'){
      const tax = i.price*i.rate/100;
      return { results:[{label:'Sales tax', value: fmtMoney(tax)},{label:'Total with tax', value: fmtMoney(i.price+tax), hl:true}]};
    }
    const pre = i.price/(1 + i.rate/100);
    return { results:[{label:'Pre-tax price', value: fmtMoney(pre), hl:true},{label:'Tax included', value: fmtMoney(i.price - pre)}]};
  }});

defCalc({ slug:'profit-margin-calculator', name:'Profit Margin Calculator', cat:['business','finance'],
  desc:'Calculate profit, margin percentage and markup from cost and revenue.',
  kw:'profit margin,markup,gross margin,net profit',
  formula:'margin = (revenue − cost) ÷ revenue × 100 · markup = (revenue − cost) ÷ cost × 100',
  expl:'Enter your cost and the selling price (revenue). Margin is profit as a share of revenue; markup is profit as a share of cost.',
  example:'Cost $60, sold for $100: profit $40, margin 40%, markup 66.7%.',
  fields:[
    {k:'cost',label:'Cost ($)',t:'number',min:0},
    {k:'rev',label:'Revenue / selling price ($)',t:'number',min:0,nonzero:true}
  ],
  compute(i){
    const profit = i.rev - i.cost;
    return { results:[
      {label:'Profit', value: fmtMoney(profit), hl:true},
      {label:'Profit margin', value: fmt(profit/i.rev*100) + '%'},
      {label:'Markup', value: fmt(i.cost === 0 ? 0 : profit/i.cost*100) + '%'}
    ]};
  }});

defCalc({ slug:'revenue-calculator', name:'Revenue Calculator', cat:'business',
  desc:'Calculate total revenue from units sold and price per unit.',
  kw:'revenue,sales revenue,units sold,total sales',
  formula:'revenue = price × quantity',
  expl:'Enter the selling price per unit and the number of units sold.',
  example:'500 units at $12 each = $6,000 revenue.',
  fields:[
    {k:'price',label:'Price per unit ($)',t:'number',min:0},
    {k:'qty',label:'Units sold',t:'number',min:0}
  ],
  compute(i){
    return { results:[{label:'Total revenue', value: fmtMoney(i.price*i.qty), hl:true}] };
  }});

defCalc({ slug:'profit-calculator', name:'Profit Calculator', cat:'business',
  desc:'Calculate net profit from total revenue and total costs.',
  kw:'profit,net income,revenue minus costs,business profit',
  formula:'profit = revenue − total costs',
  expl:'Enter your total revenue and all costs (COGS + operating expenses).',
  example:'Revenue $20,000 with $14,500 costs = $5,500 profit.',
  fields:[
    {k:'rev',label:'Total revenue ($)',t:'number',min:0},
    {k:'cost',label:'Total costs ($)',t:'number',min:0}
  ],
  compute(i){
    const p = i.rev - i.cost;
    return { results:[
      {label:'Net profit', value: fmtMoney(p), hl:true},
      {label:'Status', value: p >= 0 ? 'Profit' : 'Loss'}
    ]};
  }});

defCalc({ slug:'markup-calculator', name:'Markup Calculator', cat:'business',
  desc:'Set a selling price from cost and desired markup percentage.',
  kw:'markup,pricing,selling price,cost plus',
  formula:'price = cost × (1 + markup%)',
  expl:'Enter your cost and the markup you want to apply. You also see the equivalent profit margin.',
  example:'$50 cost with 40% markup sells for $70 (a 28.6% margin).',
  fields:[
    {k:'cost',label:'Cost ($)',t:'number',min:0},
    {k:'markup',label:'Markup (%)',t:'number',min:0}
  ],
  compute(i){
    const price = i.cost*(1 + i.markup/100);
    return { results:[
      {label:'Selling price', value: fmtMoney(price), hl:true},
      {label:'Profit per unit', value: fmtMoney(price - i.cost)},
      {label:'Equivalent margin', value: fmt((price - i.cost)/price*100) + '%'}
    ]};
  }});

defCalc({ slug:'break-even-calculator', name:'Break-Even Calculator', cat:['business','finance'],
  desc:'Find how many units you must sell to cover all fixed and variable costs.',
  kw:'break even,breakeven point,fixed costs,contribution margin',
  formula:'BEP (units) = fixed costs ÷ (price per unit − variable cost per unit)',
  expl:'Enter your fixed costs, the selling price per unit and the variable cost per unit. Below the break-even point you lose money; above it you profit.',
  example:'Fixed costs $10,000, price $50, variable cost $30 → break-even at 500 units.',
  fields:[
    {k:'fixed',label:'Fixed costs ($)',t:'number',min:0},
    {k:'price',label:'Price per unit ($)',t:'number',min:0},
    {k:'var',label:'Variable cost per unit ($)',t:'number',min:0}
  ],
  compute(i){
    const cm = i.price - i.var;
    if (cm <= 0) throw new Error('Price must be greater than variable cost per unit, or every sale loses money.');
    const units = i.fixed/cm;
    return { results:[
      {label:'Break-even point (units)', value: fmt(Math.ceil(units), 0), hl:true},
      {label:'Break-even revenue', value: fmtMoney(Math.ceil(units)*i.price)},
      {label:'Contribution margin per unit', value: fmtMoney(cm)}
    ]};
  }});

defCalc({ slug:'commission-calculator', name:'Commission Calculator', cat:'business',
  desc:'Calculate sales commission from total sales and commission rate.',
  kw:'commission,sales commission,agent fee,percentage commission',
  formula:'commission = sales × rate%',
  expl:'Enter the total sales amount and your commission percentage.',
  example:'$40,000 in sales at 5% commission = $2,000.',
  fields:[
    {k:'sales',label:'Total sales ($)',t:'number',min:0},
    {k:'rate',label:'Commission rate (%)',t:'number',min:0}
  ],
  compute(i){
    const c = i.sales*i.rate/100;
    return { results:[{label:'Commission earned', value: fmtMoney(c), hl:true},{label:'Your share after commission (if you keep sales)', value: fmtMoney(i.sales - c)}] };
  }});

defCalc({ slug:'cagr-calculator', name:'CAGR Calculator', cat:['investment','business'],
  desc:'Calculate the compound annual growth rate of an investment.',
  kw:'CAGR,compound annual growth rate,annualized growth',
  formula:'CAGR = (ending ÷ beginning)^(1/years) − 1',
  note: F_DISCLAIMER,
  expl:'Enter the starting value, ending value and number of years. CAGR smooths returns into a single annual growth rate.',
  example:'$10,000 growing to $19,487 in 7 years = 10% CAGR.',
  fields:[
    {k:'begin',label:'Beginning value ($)',t:'number',min:0,nonzero:true},
    {k:'end',label:'Ending value ($)',t:'number',min:0},
    {k:'years',label:'Years',t:'number',min:0,nonzero:true}
  ],
  compute(i){
    const c = (Math.pow(i.end/i.begin, 1/i.years) - 1)*100;
    return { results:[
      {label:'CAGR', value: fmt(c) + '%', hl:true},
      {label:'Total growth', value: fmt((i.end/i.begin - 1)*100) + '%'}
    ]};
  }});

defCalc({ slug:'employee-cost-calculator', name:'Employee Cost Calculator', cat:'business',
  desc:'Estimate the true annual cost of an employee including benefits and overhead.',
  kw:'employee cost,fully loaded cost,benefits,overhead,employer costs',
  formula:'total = salary × (1 + benefits% + overhead%)',
  expl:'Enter the base salary plus benefit and overhead percentages (payroll taxes, insurance, equipment, office space, etc.).',
  example:'$70,000 salary with 30% benefits and 20% overhead = $105,000 true annual cost.',
  fields:[
    {k:'sal',label:'Base salary ($)',t:'number',min:0},
    {k:'ben',label:'Benefits & payroll taxes (%)',t:'number',min:0,def:30},
    {k:'ovh',label:'Overhead (%)',t:'number',min:0,def:20}
  ],
  compute(i){
    const total = i.sal*(1 + (i.ben + i.ovh)/100);
    return { results:[
      {label:'True annual cost', value: fmtMoney(total), hl:true},
      {label:'Cost above salary', value: fmtMoney(total - i.sal)},
      {label:'Monthly cost', value: fmtMoney(total/12)}
    ]};
  }});

defCalc({ slug:'payroll-calculator', name:'Payroll Calculator', cat:'business',
  desc:'Convert an annual salary into gross pay per period with a simple tax estimate.',
  kw:'payroll,gross pay,net pay,pay periods,salary per period',
  formula:'gross per period = annual ÷ periods · net ≈ gross × (1 − tax rate)',
  note: 'Taxes are estimated with a single flat rate for illustration only; real withholding depends on jurisdiction and personal situation.',
  expl:'Enter the annual salary, pay frequency and an estimated flat tax rate to see gross and approximate net pay per period.',
  example:'$78,000 paid bi-weekly with 25% tax: $3,000 gross, about $2,250 net per period.',
  fields:[
    {k:'sal',label:'Annual salary ($)',t:'number',min:0},
    {k:'freq',label:'Pay frequency',t:'select',def:'26',opts:[{v:'52',l:'Weekly (52)'},{v:'26',l:'Bi-weekly (26)'},{v:'24',l:'Semi-monthly (24)'},{v:'12',l:'Monthly (12)'}]},
    {k:'tax',label:'Estimated flat tax rate (%)',t:'number',min:0,max:100,def:25}
  ],
  compute(i){
    const f = parseInt(i.freq, 10);
    const gross = i.sal/f, net = gross*(1 - i.tax/100);
    return { results:[
      {label:'Gross pay per period', value: fmtMoney(gross), hl:true},
      {label:'Estimated net per period', value: fmtMoney(net), hl:true},
      {label:'Periods per year', value: fmt(f, 0)}
    ]};
  }});

defCalc({ slug:'net-worth-calculator', name:'Net Worth Calculator', cat:'finance',
  desc:'Calculate your net worth as total assets minus total liabilities.',
  kw:'net worth,assets minus liabilities,wealth',
  formula:'net worth = total assets − total liabilities',
  expl:'Add up everything you own (cash, investments, property) and everything you owe (mortgage, loans, cards).',
  example:'Assets of $250,000 minus liabilities of $140,000 = net worth of $110,000.',
  fields:[
    {k:'assets',label:'Total assets ($)',t:'number',min:0},
    {k:'liab',label:'Total liabilities ($)',t:'number',min:0}
  ],
  compute(i){
    const nw = i.assets - i.liab;
    return { results:[
      {label:'Net worth', value: fmtMoney(nw), hl:true},
      {label:'Status', value: nw >= 0 ? 'Positive net worth' : 'Negative net worth'}
    ]};
  }});

