/* ============ CalcNova core: helpers, registry, evaluator ============ */
'use strict';

/* ---------- tiny DOM helpers ---------- */
const $  = (s, r) => (r || document).querySelector(s);
const $$ = (s, r) => Array.prototype.slice.call((r || document).querySelectorAll(s));

/* ---------- number / formatting ---------- */
function pnum(v){
  if (v === null || v === undefined) return null;
  const t = String(v).trim().replace(/,/g, '');
  if (t === '') return null;
  const n = Number(t);
  return (isFinite(n) && Math.abs(n) <= 1e15) ? n : null;
}
function fmt(n, dec){
  if (typeof n !== 'number' || !isFinite(n)) return '—';
  n = parseFloat(n.toPrecision(12)); /* FIX: strip binary float noise (0.1+0.2 -> 0.3) at display time only */
  if (dec === undefined) dec = (Math.abs(n) < 1 && n !== 0) ? 4 : 2;
  if (Math.abs(n) >= 1e12) return n.toExponential(4);
  return n.toLocaleString(undefined, { maximumFractionDigits: dec });
}
function fmtMoney(n){
  if (!isFinite(n)) return '—';
  const abs = Math.abs(n);
  const dec = abs >= 10000 ? 0 : 2;
  return (n < 0 ? '-$' : '$') + Math.abs(n).toLocaleString(undefined, { minimumFractionDigits: dec, maximumFractionDigits: dec });
}
function parseList(str){
  const parts = String(str || '').split(/[\s,;]+/).filter(Boolean);
  if (!parts.length) throw new Error('Please enter at least one number.');
  if (parts.length > 10000) throw new Error('Please enter at most 10,000 numbers.');
  return parts.map(function(p){
    const n = pnum(p);
    if (n === null) throw new Error('"' + p + '" is not a valid number.');
    return n;
  });
}
function gcd2(a, b){ a = Math.abs(a); b = Math.abs(b); while (b) { const t = a % b; a = b; b = t; } return a || 1; }
function gcdList(arr){ return arr.reduce(gcd2, 0); }
function lcm2(a, b){ if (!a || !b) return 0; return Math.abs(a * b) / gcd2(a, b); }
function lcmList(arr){ return arr.reduce(lcm2, 1); }
function factorial(n){
  if (n < 0 || n % 1 !== 0) throw new Error('Factorial requires a non-negative whole number.');
  if (n > 170) throw new Error('Number too large (maximum 170).');
  let r = 1; for (let i = 2; i <= n; i++) r *= i; return r;
}
function erf(x){
  const sign = x < 0 ? -1 : 1; x = Math.abs(x);
  const t = 1 / (1 + 0.3275911 * x);
  const y = 1 - (((((1.061405429 * t - 1.453152027) * t) + 1.421413741) * t - 0.284496736) * t + 0.254829592) * t * Math.exp(-x * x);
  return sign * y;
}
function round2(n){ return Math.round(n * 100) / 100; }

/* ---------- safe expression evaluator (tokenizer + shunting-yard) ---------- */
function evalExpr(src){
  const FUNCS = { sin:1, cos:1, tan:1, asin:1, acos:1, atan:1, ln:1, log:1, sqrt:1, abs:1, exp:1 };
  const CONSTS = { pi: Math.PI, e: Math.E };
  const toks = [];
  let i = 0;
  const s = String(src).toLowerCase().replace(/×/g, '*').replace(/÷/g, '/').replace(/−/g, '-').replace(/\s+/g, '');
  while (i < s.length){
    const c = s[i];
    if (/[0-9.]/.test(c)){
      let j = i, dot = 0, num = '';
      while (j < s.length && /[0-9.]/.test(s[j])) { if (s[j] === '.') dot++; num += s[j]; j++; }
      if (dot > 1) throw new Error('Invalid number "' + num + '".');
      const v = Number(num);
      if (!isFinite(v)) throw new Error('Invalid number.');
      toks.push({ t: 'num', v: v }); i = j;
    } else if (/[a-z]/.test(c)){
      let j = i, name = '';
      while (j < s.length && /[a-z]/.test(s[j])) { name += s[j]; j++; }
      if (FUNCS[name]) toks.push({ t: 'fn', v: name });
      else if (name in CONSTS) toks.push({ t: 'num', v: CONSTS[name] });
      else throw new Error('Unknown symbol "' + name + '".');
      i = j;
    } else if ('+-*/%^!(),'.indexOf(c) >= 0){ toks.push({ t: 'op', v: c }); i++; }
    else throw new Error('Invalid character "' + c + '".');
  }
  const out = [], ops = [];
  let prev = null;
  const prec = { '+': 1, '-': 1, '*': 2, '/': 2, '%': 2, '^': 4, 'u-': 3, 'u+': 3, '!': 5 };
  const rightAssoc = { '^': true, 'u-': true, 'u+': true };
  for (let k = 0; k < toks.length; k++){
    const tk = toks[k];
    const isUnarySpot = !prev || ((prev.t === 'op') && prev.v !== ')' && prev.v !== '!') || prev.t === 'fn';
    if (tk.t === 'num') out.push(tk);
    else if (tk.t === 'fn') ops.push(tk);
    else if (tk.t === 'op'){
      if (tk.v === '(') ops.push(tk);
      else if (tk.v === ')'){
        while (ops.length && ops[ops.length-1].v !== '(') out.push(ops.pop());
        if (!ops.length) throw new Error('Mismatched parentheses.');
        ops.pop();
        if (ops.length && ops[ops.length-1].t === 'fn') out.push(ops.pop());
      } else if (tk.v === ','){
        while (ops.length && ops[ops.length-1].v !== '(') out.push(ops.pop());
      } else if (tk.v === '!' || (tk.v === '-' && isUnarySpot && (tk.v === '-'))) {
        if (tk.v === '!') {
          if (!prev || (prev.t === 'op' && prev.v !== ')' && prev.v !== '!')) throw new Error('Missing value before "!".');
          out.push({ t: 'op', v: '!' });
        } else ops.push({ t: 'op', v: 'u-' });
      } else if ((tk.v === '+' && isUnarySpot)) { /* unary plus: skip */ }
      else {
        while (ops.length){
          const top = ops[ops.length-1];
          if (top.t === 'fn' || (top.t === 'op' && (top.v === 'u-' || top.v === 'u+') && prec[tk.v] <= 3 && !rightAssoc[tk.v])) { out.push(ops.pop()); continue; }
          if (top.t === 'op' && top.v !== '(' && (prec[top.v] > prec[tk.v] || (prec[top.v] === prec[tk.v] && !rightAssoc[tk.v]))) { out.push(ops.pop()); continue; }
          break;
        }
        ops.push(tk);
      }
    }
    if (tk.t === 'num' || tk.v === ')' || tk.v === '!') prev = tk;
    else if (!(tk.v === '-' && isUnarySpot) && tk.v !== '+') prev = tk;
  }
  while (ops.length){ const o = ops.pop(); if (o.v === '(') throw new Error('Mismatched parentheses.'); out.push(o); }
  const st = [];
  const ap = fn => { const x = st.pop(); if (x === undefined) throw new Error('Missing value.'); st.push(fn(x)); };
  for (const tk of out){
    if (tk.t === 'num') st.push(tk.v);
    else if (tk.t === 'fn'){
      if (tk.v === 'ln') ap(x => { if (x <= 0) throw new Error('ln requires a positive number.'); return Math.log(x); });
      else if (tk.v === 'log') ap(x => { if (x <= 0) throw new Error('log requires a positive number.'); return Math.log10(x); });
      else if (tk.v === 'sqrt') ap(x => { if (x < 0) throw new Error('Square root of a negative number.'); return Math.sqrt(x); });
      else if (FUNCS[tk.v]) ap(x => Math[tk.v](x));
    } else {
      if (tk.v === 'u-') ap(x => -x);
      else if (tk.v === 'u+') ap(x => x);
      else if (tk.v === '!') ap(x => factorial(Math.round(x)));
      else {
        const b = st.pop(), a = st.pop();
        if (a === undefined || b === undefined) throw new Error('Missing operand.');
        if (tk.v === '+') st.push(a + b);
        else if (tk.v === '-') st.push(a - b);
        else if (tk.v === '*') st.push(a * b);
        else if (tk.v === '/') { if (b === 0) throw new Error('Division by zero.'); st.push(a / b); }
        else if (tk.v === '%') { if (b === 0) throw new Error('Division by zero.'); st.push(a % b); }
        else if (tk.v === '^') st.push(Math.pow(a, b));
      }
    }
    if (st.length && !isFinite(st[st.length-1])) throw new Error('Result is not a finite number.');
  }
  if (st.length !== 1) throw new Error('Invalid expression.');
  return st[0];
}

/* ---------- categories ---------- */
const CATS = [
  { slug: 'math',        name: 'Math Calculators',        icon: '∑', desc: 'Arithmetic, algebra, geometry, percentages, fractions and number theory tools.' },
  { slug: 'finance',     name: 'Financial Calculators',   icon: '💰', desc: 'Zakat, budgeting, business profit, salary, tax, pricing and other practical financial tools.' },
  { slug: 'health',      name: 'Health & Fitness',        icon: '❤', desc: 'BMI, BMR, calories, macros, pace and wellness calculators.' },
  { slug: 'time',        name: 'Time & Date',             icon: '🕒', desc: 'Age, date differences, durations, workdays and countdowns.' },
  { slug: 'conversion',  name: 'Conversion Calculators',  icon: '⇄', desc: 'Convert length, weight, temperature, area, volume, speed and data.' },
  { slug: 'business',    name: 'Business Calculators',    icon: '📈', desc: 'Revenue, profit, margin, markup, break-even, payroll and ROI.' },
  { slug: 'investment',  name: 'Investment Calculators',  icon: '📊', desc: 'Returns, compound growth, CAGR and periodic investing tools.' },
  { slug: 'real-estate', name: 'Real Estate Calculators', icon: '🏠', desc: 'Mortgage, affordability, rental yield, down payment and closing costs.' },
  { slug: 'statistics',  name: 'Statistics Calculators',  icon: 'σ', desc: 'Mean, median, mode, standard deviation, probability and z-scores.' },
  { slug: 'education',   name: 'Education Calculators',   icon: '🎓', desc: 'GPA, grades, finals and exam score tools for students.' },
  { slug: 'technology',  name: 'Technology Calculators',  icon: '⚙', desc: 'Data storage, transfer times, internet speed and binary conversions.' }
];
function getCat(slug){ return CATS.find(c => c.slug === slug); }

/* ---------- calculator registry ---------- */
const CALCS = [];
function defCalc(o){
  o.cats = Array.isArray(o.cat) ? o.cat : [o.cat];
  o.related = o.related || [];
  CALCS.push(o);
  return o;
}
function getCalc(slug){ return CALCS.find(c => c.slug === slug); }
function calcsByCat(slug){ return CALCS.filter(c => c.cats.indexOf(slug) >= 0); }
function relatedFor(c){
  if (c.related.length) return c.related.map(getCalc).filter(Boolean);
  const same = CALCS.filter(x => x !== c && x.cats.some(k => c.cats.indexOf(k) >= 0));
  return same.slice(0, 6);
}

/* ---------- unit converter factory ---------- */
function converter(o){
  const keys = Object.keys(o.units);
  const opts = keys.map(k => ({ v: k, l: o.units[k].l }));
  return defCalc({
    slug: o.slug, name: o.name, cat: o.cat, custom: o.custom,
    desc: o.desc, kw: o.kw,
    fields: [
      { k: 'v', label: 'Value', t: 'number', def: 1 },
      { k: 'from', label: 'From', t: 'select', opts: opts, def: o.from },
      { k: 'to', label: 'To', t: 'select', opts: opts, def: o.to }
    ],
    formula: o.formula || 'result = value × (conversion factor of "from" unit) ÷ (conversion factor of "to" unit)',
    expl: o.expl, example: o.example,
    compute(inp){
      if (o.temp){
        const celsius = o.units[inp.from].toC(inp.v);
        const r = o.units[inp.to].fromC(celsius);
        return { results: [{ label: 'Result', value: fmt(r) + ' ' + inp.to }], note: fmt(inp.v) + ' ' + inp.from + ' = ' + fmt(r) + ' ' + inp.to };
      }
      const f = o.units[inp.from].f, t = o.units[inp.to].f;
      const r = inp.v * f / t;
      return { results: [{ label: o.units[inp.to].l, value: fmt(r) }], note: '1 ' + o.units[inp.from].l.toLowerCase() + ' = ' + fmt(f / t, 8) + ' ' + o.units[inp.to].l.toLowerCase() };
    }
  });
}
